import { Router } from "express";
import { db } from "@workspace/db";
import { jobsTable, schemesTable, blogsTable, trendingTable } from "@workspace/db";
import { sql, desc } from "drizzle-orm";

const router = Router();

router.get("/summary", async (req, res) => {
  try {
    const [
      jobCountResult,
      schemeCountResult,
      blogCountResult,
      latestJobs,
      latestSchemes,
      trendingNow,
    ] = await Promise.all([
      db.select({ count: sql<number>`count(*)::int` }).from(jobsTable),
      db.select({ count: sql<number>`count(*)::int` }).from(schemesTable),
      db.select({ count: sql<number>`count(*)::int` }).from(blogsTable),
      db.select().from(jobsTable).orderBy(desc(jobsTable.createdAt)).limit(6),
      db.select().from(schemesTable).orderBy(desc(schemesTable.createdAt)).limit(4),
      db.select().from(trendingTable).orderBy(desc(trendingTable.viewCount)).limit(10),
    ]);

    const SEO_PAGES_COUNT = 27;
    const SEO_SLUGS = [
      "latest-govt-jobs-2026","10th-pass-govt-jobs","12th-pass-govt-jobs",
      "graduate-govt-jobs","railway-jobs-2026","bank-jobs-2026","ssc-jobs-2026",
      "maharashtra-govt-jobs","up-govt-jobs","bihar-govt-jobs","punjab-govt-jobs",
      "rajasthan-govt-jobs","gujarat-govt-jobs","tamilnadu-govt-jobs",
      "karnataka-govt-jobs","delhi-govt-jobs","pm-kisan-yojana","pm-kisan-status-check",
      "tractor-subsidy-scheme","crop-insurance-scheme","kisan-credit-card",
      "pm-yojana-list","women-schemes-india","farmer-schemes-india",
      "emi-calculator","age-calculator","image-compressor"
    ];

    res.json({
      totalJobs: jobCountResult[0]?.count ?? 0,
      totalSchemes: schemeCountResult[0]?.count ?? 0,
      totalBlogs: blogCountResult[0]?.count ?? 0,
      totalSeoPages: SEO_PAGES_COUNT,
      seoSlugs: SEO_SLUGS,
      latestJobs,
      latestSchemes,
      trendingNow,
    });
  } catch (err) {
    req.log.error({ err }, "Error fetching dashboard summary");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
