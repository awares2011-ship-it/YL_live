import { Router, type IRouter } from "express";
import healthRouter from "./health";
import jobsRouter from "./jobs";
import schemesRouter from "./schemes";
import blogsRouter from "./blogs";
import trendingRouter from "./trending";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/jobs", jobsRouter);
router.use("/schemes", schemesRouter);
router.use("/blogs", blogsRouter);
router.use(trendingRouter);

export default router;
