/**
 * India GovHub – Blog Content Engine
 * Generates SEO-optimized daily blog posts
 * Run: node blogGenerator.js
 * Store output in /blogs directory as JSON
 */

const BLOG_TOPICS = [
  // Govt Jobs Topics
  {
    category: "govt-jobs",
    slug: "top-govt-jobs-today-2026",
    title: "🔥 Top 10 Government Jobs Today 2026 – Apply Before Last Date",
    metaDesc: "Today's top government job notifications 2026: Railway, SSC, Bank, Army, Police. Fresh vacancies with last dates. Apply online now!",
    keywords: ["govt jobs today", "sarkari naukri 2026", "latest government jobs apply online"],
    tags: ["railway", "ssc", "bank", "police"],
  },
  {
    category: "kisan",
    slug: "pm-kisan-latest-update-2026",
    title: "🌾 PM Kisan Latest Update 2026 – Next Installment Date & Status Check",
    metaDesc: "PM Kisan Samman Nidhi latest update 2026: When is next installment? How to check status, eKYC, and resolve payment issues.",
    keywords: ["pm kisan latest news", "pm kisan next installment 2026", "pm kisan status check"],
    tags: ["pm-kisan", "kisan", "yojana"],
  },
  {
    category: "schemes",
    slug: "new-government-scheme-launched-2026",
    title: "📋 New Government Scheme Launched 2026 – Apply Now & Get Benefits",
    metaDesc: "New PM yojana launched in 2026. Complete details: eligibility, how to apply, benefits, documents required. Apply online today.",
    keywords: ["new government scheme 2026", "new pm yojana 2026", "new scheme launched today"],
    tags: ["schemes", "yojana", "government"],
  },
  {
    category: "results",
    slug: "govt-exam-results-today",
    title: "📊 Government Exam Results Today 2026 – SSC, Railway, Bank Results",
    metaDesc: "Today's government exam results 2026: SSC CGL, Railway RRB, IBPS, UP Police, Bihar Police results. Direct link to check your result.",
    keywords: ["govt exam result today 2026", "ssc result 2026", "railway result 2026"],
    tags: ["results", "ssc", "railway"],
  },
  {
    category: "admit-card",
    slug: "admit-card-download-2026",
    title: "🎫 Government Exam Admit Card 2026 – Download Hall Ticket Today",
    metaDesc: "Download admit card 2026 for SSC, Railway, Bank, UP Police, Bihar Police, IBPS exams. Direct link with step-by-step guide.",
    keywords: ["admit card 2026", "hall ticket download 2026", "admit card ssc railway"],
    tags: ["admit-card", "exam", "download"],
  },
  {
    category: "kisan",
    slug: "kisan-credit-card-apply-guide",
    title: "💳 Kisan Credit Card Apply Online 2026 – Step by Step Complete Guide",
    metaDesc: "How to apply for Kisan Credit Card (KCC) 2026 at SBI, PNB, BOB. Get Rs3 lakh at 4% interest. Documents, eligibility, benefits.",
    keywords: ["kisan credit card apply online", "kcc apply 2026", "kisan credit card documents"],
    tags: ["kcc", "kisan", "credit"],
  },
  {
    category: "govt-jobs",
    slug: "railway-recruitment-2026-apply",
    title: "🚆 Railway Recruitment 2026 – 1 Lakh+ Vacancies Apply Online",
    metaDesc: "Indian Railway recruitment 2026: RRB Group D 1 lakh+ vacancies, NTPC, ALP. 10th/12th pass eligible. Apply at indianrailways.gov.in",
    keywords: ["railway recruitment 2026", "rrb group d 2026 apply", "railway jobs apply online"],
    tags: ["railway", "rrb", "recruitment"],
  },
  {
    category: "schemes",
    slug: "pm-awas-yojana-2026-apply",
    title: "🏠 PM Awas Yojana 2026 – Apply Online, Check Status, List",
    metaDesc: "PM Awas Yojana 2026: How to apply for free house. Eligibility, documents, beneficiary list check, application status. PMAY-G and PMAY-U.",
    keywords: ["pm awas yojana 2026 apply", "pmay beneficiary list", "pm awas yojana status check"],
    tags: ["pmay", "housing", "yojana"],
  },
  {
    category: "govt-jobs",
    slug: "ssc-cgl-2026-complete-guide",
    title: "📝 SSC CGL 2026 – Notification, Exam Date, Syllabus, Preparation",
    metaDesc: "SSC CGL 2026 complete guide: 17,727 vacancies, exam dates, syllabus, selection process, best books, preparation strategy.",
    keywords: ["ssc cgl 2026", "ssc cgl notification 2026", "ssc cgl preparation"],
    tags: ["ssc", "cgl", "exam"],
  },
  {
    category: "kisan",
    slug: "fasal-bima-claim-2026",
    title: "🌾 PM Fasal Bima Claim 2026 – How to Claim Crop Insurance",
    metaDesc: "How to claim PM Fasal Bima Yojana 2026 after crop damage. Report damage, documents, claim process, helpline 14447.",
    keywords: ["fasal bima claim 2026", "pmfby claim process", "crop insurance claim"],
    tags: ["pmfby", "crop-insurance", "claim"],
  },
];

/**
 * SAMPLE BLOG CONTENT TEMPLATE
 * Each blog entry follows this structure
 */
const BLOG_TEMPLATE = {
  id: "auto-generated",
  slug: "slug-from-topic",
  title: "Title with emoji",
  metaDesc: "SEO meta description 150-160 chars",
  category: "govt-jobs | kisan | schemes | results",
  tags: ["tag1", "tag2"],
  publishedAt: new Date().toISOString(),
  readTime: "5 min read",
  isNew: true,
  isTrending: false,
  viewCount: 0,
  sections: [
    {
      type: "intro",
      content: "800-1000 word introduction paragraph",
    },
    {
      type: "latest-updates",
      title: "Latest Updates",
      items: ["Update 1", "Update 2"],
    },
    {
      type: "step-guide",
      title: "Step-by-Step Guide",
      steps: ["Step 1", "Step 2"],
    },
    {
      type: "faq",
      title: "Frequently Asked Questions",
      faqs: [
        { q: "Question?", a: "Answer." },
      ],
    },
    {
      type: "internal-links",
      links: [
        { label: "Related Page", href: "/seo/related-slug" },
      ],
    },
  ],
  schemaMarkup: {
    "@type": "Article",
    headline: "Blog Title",
    datePublished: new Date().toISOString(),
    author: { "@type": "Organization", name: "India GovHub" },
  },
};

// KEYWORD TARGETS for each category
const KEYWORD_TARGETS = {
  "govt-jobs": [
    "latest govt jobs 2026 apply online",
    "sarkari naukri 2026",
    "government jobs today",
    "10th pass govt jobs today",
    "12th pass government jobs 2026",
    "graduate government jobs 2026",
  ],
  "kisan": [
    "pm kisan status check online",
    "pm kisan next installment 2026",
    "kisan credit card apply",
    "fasal bima yojana apply",
    "tractor subsidy apply online",
  ],
  "schemes": [
    "new government scheme 2026",
    "pm yojana list 2026",
    "ayushman bharat apply online",
    "pm awas yojana apply online",
    "women scheme india 2026",
  ],
};

// BLOG GENERATION SCHEDULE
// Run this script daily at 6 AM IST via Cloud Functions / cron
const DAILY_SCHEDULE = {
  morning: BLOG_TOPICS[new Date().getDate() % BLOG_TOPICS.length],
  evening: BLOG_TOPICS[(new Date().getDate() + 5) % BLOG_TOPICS.length],
};

console.log("Daily Blog Topics for Today:");
console.log("Morning:", DAILY_SCHEDULE.morning.title);
console.log("Evening:", DAILY_SCHEDULE.evening.title);
console.log("\nKeyword Targets:", Object.keys(KEYWORD_TARGETS).length, "categories");
console.log("Total Blog Templates:", BLOG_TOPICS.length);

module.exports = { BLOG_TOPICS, KEYWORD_TARGETS, DAILY_SCHEDULE, BLOG_TEMPLATE };
