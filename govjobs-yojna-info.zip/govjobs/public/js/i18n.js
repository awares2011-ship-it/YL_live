/**
 * GovJobs & Yojna Info — i18n.js
 * Multi-language support (10 languages)
 * Developed by Breakout Trade
 */

const SUPPORTED_LANGS = ['en','hi','mr','gu','ta','te','kn','bn','pa','ml'];
const LANG_NAMES = {
  en: '🇬🇧 English', hi: '🇮🇳 हिंदी', mr: '🇮🇳 मराठी',
  gu: '🇮🇳 ગુજરાતી', ta: '🇮🇳 தமிழ்', te: '🇮🇳 తెలుగు',
  kn: '🇮🇳 ಕನ್ನಡ', bn: '🇮🇳 বাংলা', pa: '🇮🇳 ਪੰਜਾਬੀ', ml: '🇮🇳 മലയാളം'
};
const NOTO_FONTS = {
  hi: 'Noto+Sans+Devanagari',
  mr: 'Noto+Sans+Devanagari',
  gu: 'Noto+Sans+Gujarati',
  ta: 'Noto+Sans+Tamil',
  te: 'Noto+Sans+Telugu',
  kn: 'Noto+Sans+Kannada',
  bn: 'Noto+Sans+Bengali',
  pa: 'Noto+Sans+Gurmukhi',
  ml: 'Noto+Sans+Malayalam'
};

let translations = {};
let currentLang = 'en';

document.addEventListener('DOMContentLoaded', async () => {
  // Detect language from URL path or localStorage
  const pathLang = detectLangFromPath();
  currentLang = pathLang || localStorage.getItem('gj_lang') || 'en';
  if (!SUPPORTED_LANGS.includes(currentLang)) currentLang = 'en';

  window.GovApp = window.GovApp || {};
  GovApp.currentLang = currentLang;

  await loadTranslations(currentLang);
  applyTranslations();
  setHtmlLang(currentLang);
  loadLangFont(currentLang);
  populateLangSelector();
  addHreflangTags();
});

function detectLangFromPath() {
  const parts = window.location.pathname.split('/').filter(Boolean);
  if (parts.length > 0 && SUPPORTED_LANGS.includes(parts[0])) return parts[0];
  return null;
}

async function loadTranslations(lang) {
  if (lang === 'en') {
    // inline English (no fetch needed)
    translations = getEnglishTranslations();
    return;
  }
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5000);
    const res = await fetch(`/translations/${lang}.json`, { signal: controller.signal });
    clearTimeout(timeout);
    if (!res.ok) throw new Error('Not found');
    translations = await res.json();
  } catch (e) {
    // Fallback to English
    translations = getEnglishTranslations();
  }
}

function applyTranslations() {
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.dataset.i18n;
    const val = t(key);
    if (val) el.textContent = val;
  });
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
    const key = el.dataset.i18nPlaceholder;
    const val = t(key);
    if (val) el.placeholder = val;
  });
}

function t(key) {
  if (!key) return '';
  return translations[key] || key.split('.').reduce((o, k) => (o && o[k] !== undefined ? o[k] : null), translations) || key;
}

function setHtmlLang(lang) {
  document.documentElement.lang = lang;
}

function loadLangFont(lang) {
  if (!lang || lang === 'en') return;
  const fontName = NOTO_FONTS[lang];
  if (!fontName) return;
  const link = document.createElement('link');
  link.rel = 'stylesheet';
  link.href = `https://fonts.googleapis.com/css2?family=${fontName}:wght@400;500;600;700&display=swap`;
  document.head.appendChild(link);
}

function populateLangSelector() {
  document.querySelectorAll('.lang-select').forEach(sel => {
    sel.innerHTML = SUPPORTED_LANGS.map(l =>
      `<option value="${l}" ${l === currentLang ? 'selected' : ''}>${LANG_NAMES[l]}</option>`
    ).join('');
    sel.addEventListener('change', (e) => {
      switchLanguage(e.target.value);
    });
  });
}

function switchLanguage(lang) {
  if (!SUPPORTED_LANGS.includes(lang)) return;
  const prev = currentLang;
  localStorage.setItem('gj_lang', lang);
  if (typeof gtag !== 'undefined') {
    gtag('event', 'language_changed', { from: prev, to: lang });
  }
  // For language URL prefixes, redirect
  const currentPath = window.location.pathname;
  const strippedPath = currentPath.replace(/^\/(en|hi|mr|gu|ta|te|kn|bn|pa|ml)\//, '/');
  if (lang === 'en') {
    window.location.href = strippedPath || '/';
  } else {
    window.location.href = `/${lang}${strippedPath}`;
  }
}

function addHreflangTags() {
  const base = 'https://govjobsyojnainfo.in';
  const path = window.location.pathname.replace(/^\/(en|hi|mr|gu|ta|te|kn|bn|pa|ml)\//, '/');

  // Remove existing hreflang tags
  document.querySelectorAll('link[hreflang]').forEach(l => l.remove());

  const head = document.head;

  // x-default
  const xdef = document.createElement('link');
  xdef.rel = 'alternate';
  xdef.hreflang = 'x-default';
  xdef.href = `${base}${path}`;
  head.appendChild(xdef);

  // en
  const enLink = document.createElement('link');
  enLink.rel = 'alternate';
  enLink.hreflang = 'en-IN';
  enLink.href = `${base}${path}`;
  head.appendChild(enLink);

  // Other languages
  ['hi','mr','gu','ta','te','kn','bn','pa','ml'].forEach(l => {
    const link = document.createElement('link');
    link.rel = 'alternate';
    link.hreflang = l;
    link.href = `${base}/${l}${path}`;
    head.appendChild(link);
  });
}

function getEnglishTranslations() {
  return {
    site_name: "GovJobs & Yojna Info",
    tagline: "Sarkari Naukri & Yojana — Real Data Daily",
    latest_updates: "LATEST UPDATES",
    search_placeholder: "Search jobs, yojana...",
    all: "All",
    jobs: "Govt Jobs",
    yojana: "Yojana",
    news: "State News",
    blog: "Blog",
    about: "About",
    contact: "Contact",
    view_all: "View All",
    view_official: "View Official Site →",
    share: "Share",
    new: "NEW",
    read_more: "Read More",
    disclaimer_text: "This website is NOT an official government website. Information is for reference only.",
    developed_by: "Developed by Breakout Trade",
    filter_all: "All States",
    filter_central: "Central",
    loading: "Loading...",
    no_results: "No results found",
    error_loading: "Failed to load. Please try again.",
    subscribe: "Subscribe",
    email_placeholder: "Enter your email",
    newsletter_heading: "Weekly Job Digest",
    newsletter_desc: "Get top 10 jobs & yojana in your inbox every week",
    total_jobs: "Total Jobs",
    total_yojanas: "Total Yojanas",
    total_news: "Total News",
    states_covered: "States Covered",
    page: "Page",
    of: "of",
    prev: "Previous",
    next: "Next",
    home: "Home",
    select_state: "Select State",
    quick_links: "Quick Links",
    popular_states: "Popular States",
    recent_blogs: "Recent Blogs",
    send_message: "Send Message",
    your_name: "Your Name",
    your_email: "Your Email",
    subject: "Subject",
    message: "Message"
  };
}

window.t = t;
window.switchLanguage = switchLanguage;
window.GovApp = window.GovApp || {};
