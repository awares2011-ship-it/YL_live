import { pgTable, serial, text, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const schemesTable = pgTable("schemes", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  ministry: text("ministry").notNull(),
  category: text("category").notNull(),
  beneficiaries: text("beneficiaries").notNull(),
  benefit: text("benefit").notNull(),
  content: text("content").notNull(),
  applyUrl: text("apply_url"),
  isTrending: boolean("is_trending").notNull().default(false),
  isNew: boolean("is_new").notNull().default(true),
  viewCount: integer("view_count").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertSchemeSchema = createInsertSchema(schemesTable).omit({ id: true, createdAt: true });
export type InsertScheme = z.infer<typeof insertSchemeSchema>;
export type Scheme = typeof schemesTable.$inferSelect;
