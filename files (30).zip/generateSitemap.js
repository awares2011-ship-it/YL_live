/**
 * India GovHub – Auto Sitemap Generator
 * Generates XML sitemap for all SEO pages, blogs, jobs, schemes
 * Run via: node generateSitemap.js > public/sitemap.xml
 */

const SITE_URL = "https://india-govhub.web.app";
const TODAY = new Date().toISOString().split("T")[0];

const SEO_SLUGS = [
  // Govt Jobs
  "latest-govt-jobs-2026",
  "10th-pass-govt-jobs",
  "12th-pass-govt-jobs",
  "graduate-govt-jobs",
  "railway-jobs-2026",
  "bank-jobs-2026",
  "ssc-jobs-2026",
  // State Jobs
  "maharashtra-govt-jobs",
  "up-govt-jobs",
  "bihar-govt-jobs",
  // Kisan
  "pm-kisan-yojana",
  "pm-kisan-status-check",
  "tractor-subsidy-scheme",
  "crop-insurance-scheme",
  "kisan-credit-card",
  // Schemes
  "pm-yojana-list",
  "women-schemes-india",
  "farmer-schemes-india",
  // Tools
  "emi-calculator",
  "age-calculator",
  "image-compressor",
];

const STATIC_PAGES = [
  { url: "/", priority: "1.0", changefreq: "daily" },
  { url: "/jobs", priority: "0.9", changefreq: "daily" },
  { url: "/schemes", priority: "0.9", changefreq: "weekly" },
  { url: "/blogs", priority: "0.8", changefreq: "daily" },
  { url: "/trending", priority: "0.8", changefreq: "daily" },
  { url: "/tools/emi-calculator", priority: "0.7", changefreq: "monthly" },
  { url: "/tools/age-calculator", priority: "0.7", changefreq: "monthly" },
];

function generateSitemapXml() {
  const seoUrls = SEO_SLUGS.map(slug => ({
    url: `/seo/${slug}`,
    priority: "0.8",
    changefreq: "weekly",
    lastmod: TODAY,
  }));

  const allUrls = [...STATIC_PAGES.map(p => ({ ...p, lastmod: TODAY })), ...seoUrls];

  const urlEntries = allUrls.map(page => `
  <url>
    <loc>${SITE_URL}${page.url}</loc>
    <lastmod>${page.lastmod}</lastmod>
    <changefreq>${page.changefreq}</changefreq>
    <priority>${page.priority}</priority>
  </url>`).join("");

  return `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:news="http://www.google.com/schemas/sitemap-news/0.9"
        xmlns:xhtml="http://www.w3.org/1999/xhtml">
${urlEntries}
</urlset>`;
}

const sitemap = generateSitemapXml();
console.log(sitemap);

// Also export for use in Firebase Functions
export { generateSitemapXml, SEO_SLUGS, SITE_URL };
