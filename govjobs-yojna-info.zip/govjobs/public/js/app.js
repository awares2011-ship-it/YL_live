/**
 * GovJobs & Yojna Info — app.js
 * Core application logic, Firebase init, shared utilities
 * Developed by Breakout Trade
 */

// ─── Firebase Config (replace with your project values) ───
const FIREBASE_CONFIG = {
  apiKey: "YOUR_FIREBASE_API_KEY",
  authDomain: "YOUR_FIREBASE_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_FIREBASE_PROJECT_ID",
  storageBucket: "YOUR_FIREBASE_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_FIREBASE_APP_ID"
};

const BASE_URL = "https://govjobsyojnainfo.in";
const API_BASE = `${BASE_URL}/api`;
const CACHE_TTL = 2 * 60 * 60 * 1000; // 2 hours in ms

// ─── App State ─────────────────────────────────────────────
window.GovApp = {
  currentLang: localStorage.getItem('gj_lang') || 'en',
  currentRegion: localStorage.getItem('gj_region') || 'all',
  firebase: null,
  db: null
};

// ─── DOM Ready ─────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  initFirebase();
  initDisclaimerBanner();
  initMobileMenu();
  initPushNotificationBanner();
  initFAQ();
  initTabs();
  markActiveNavLink();
});

// ─── Firebase Init ─────────────────────────────────────────
function initFirebase() {
  try {
    if (typeof firebase !== 'undefined' && !firebase.apps?.length) {
      firebase.initializeApp(FIREBASE_CONFIG);
      GovApp.db = firebase.firestore();
    }
  } catch (e) {
    console.warn('Firebase init skipped:', e.message);
  }
}

// ─── Disclaimer Banner ─────────────────────────────────────
function initDisclaimerBanner() {
  const banner = document.getElementById('disclaimer-banner');
  if (!banner) return;
  const dismissed = localStorage.getItem('gj_disclaimer_dismissed');
  if (dismissed) {
    banner.remove();
    return;
  }
  const btn = banner.querySelector('.dismiss-btn');
  btn?.addEventListener('click', () => {
    localStorage.setItem('gj_disclaimer_dismissed', '1');
    banner.style.animation = 'toast-in 0.3s ease reverse';
    setTimeout(() => banner.remove(), 300);
    if (typeof gtag !== 'undefined') {
      gtag('event', 'disclaimer_dismissed');
    }
  });
}

// ─── Mobile Menu ────────────────────────────────────────────
function initMobileMenu() {
  const toggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.header-nav');
  if (!toggle || !nav) return;
  toggle.addEventListener('click', () => {
    nav.classList.toggle('open');
    toggle.setAttribute('aria-expanded', nav.classList.contains('open'));
  });
  document.addEventListener('click', (e) => {
    if (!toggle.contains(e.target) && !nav.contains(e.target)) {
      nav.classList.remove('open');
    }
  });
}

// ─── Push Notification Banner ───────────────────────────────
function initPushNotificationBanner() {
  const banner = document.getElementById('push-banner');
  if (!banner) return;
  const shownBefore = localStorage.getItem('gj_push_shown');
  if (shownBefore) return;

  setTimeout(() => {
    banner.classList.add('visible');
  }, 30000); // show after 30s

  const allowBtn = banner.querySelector('.push-allow');
  const denyBtn = banner.querySelector('.push-deny');
  const closeBtn = banner.querySelector('.push-close');

  allowBtn?.addEventListener('click', async () => {
    localStorage.setItem('gj_push_shown', '1');
    banner.classList.remove('visible');
    try {
      if ('Notification' in window) {
        const perm = await Notification.requestPermission();
        if (perm === 'granted') {
          showToast('✅ Push notifications enabled!', 'success');
        }
      }
    } catch (e) { /* ignore */ }
  });

  denyBtn?.addEventListener('click', () => {
    localStorage.setItem('gj_push_shown', '1');
    banner.classList.remove('visible');
  });

  closeBtn?.addEventListener('click', () => {
    localStorage.setItem('gj_push_shown', '1');
    banner.classList.remove('visible');
  });
}

// ─── FAQ Accordion ──────────────────────────────────────────
function initFAQ() {
  document.querySelectorAll('.faq-question').forEach(q => {
    q.addEventListener('click', () => {
      const answer = q.nextElementSibling;
      const isOpen = q.classList.contains('open');
      // Close all
      document.querySelectorAll('.faq-question.open').forEach(oq => {
        oq.classList.remove('open');
        oq.nextElementSibling?.classList.remove('open');
      });
      // Toggle clicked
      if (!isOpen) {
        q.classList.add('open');
        answer?.classList.add('open');
      }
    });
  });
}

// ─── Tab System ─────────────────────────────────────────────
function initTabs() {
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = btn.dataset.tab;
      const parent = btn.closest('[data-tabs]') || btn.closest('.tabs-container') || document;
      parent.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      parent.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      parent.querySelector(`[data-panel="${target}"]`)?.classList.add('active');
    });
  });
}

// ─── Toast Notifications ────────────────────────────────────
function showToast(message, type = 'default', duration = 3500) {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(300px)';
    toast.style.transition = 'all 0.3s';
    setTimeout(() => toast.remove(), 300);
  }, duration);
}

// ─── Mark Active Nav Link ───────────────────────────────────
function markActiveNavLink() {
  const path = window.location.pathname;
  document.querySelectorAll('.header-nav a').forEach(a => {
    const href = a.getAttribute('href') || '';
    if (href !== '/' && path.includes(href.replace('.html', ''))) {
      a.classList.add('active');
    } else if (href === '/' && (path === '/' || path === '/index.html')) {
      a.classList.add('active');
    }
  });
}

// ─── API Fetch with Cache ────────────────────────────────────
async function apiFetch(endpoint, params = {}, useCache = true) {
  const url = new URL(`${API_BASE}${endpoint}`);
  Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v));
  const cacheKey = `gj_cache_${url.toString()}`;

  if (useCache) {
    try {
      const cached = localStorage.getItem(cacheKey);
      if (cached) {
        const parsed = JSON.parse(cached);
        if (Date.now() < parsed.expiry) return parsed.data;
      }
    } catch (e) { /* ignore cache errors */ }
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8000);
  try {
    const res = await fetch(url.toString(), { signal: controller.signal });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    try {
      localStorage.setItem(cacheKey, JSON.stringify({ data, expiry: Date.now() + CACHE_TTL }));
    } catch (e) { /* storage full, skip */ }
    return data;
  } finally {
    clearTimeout(timeout);
  }
}

// ─── WhatsApp Share ─────────────────────────────────────────
function shareWhatsApp(title, url) {
  const text = encodeURIComponent(`${title}\n${url}\n\nvia GovJobs & Yojna Info by Breakout Trade`);
  window.open(`https://wa.me/?text=${text}`, '_blank', 'noopener');
  if (typeof gtag !== 'undefined') {
    gtag('event', 'whatsapp_shared', { title });
  }
}

// ─── Format Date ─────────────────────────────────────────────
function formatDate(dateStr) {
  if (!dateStr) return '';
  try {
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
  } catch (e) { return dateStr; }
}

// ─── Time Ago ───────────────────────────────────────────────
function timeAgo(dateStr) {
  if (!dateStr) return '';
  try {
    const diff = Date.now() - new Date(dateStr).getTime();
    const mins = Math.floor(diff / 60000);
    const hrs = Math.floor(mins / 60);
    const days = Math.floor(hrs / 24);
    if (days > 0) return `${days}d ago`;
    if (hrs > 0) return `${hrs}h ago`;
    if (mins > 0) return `${mins}m ago`;
    return 'Just now';
  } catch (e) { return ''; }
}

// ─── Debounce ─────────────────────────────────────────────
function debounce(fn, wait) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), wait);
  };
}

// ─── Skeleton Cards ─────────────────────────────────────────
function renderSkeletons(container, count = 5) {
  if (!container) return;
  container.innerHTML = Array.from({ length: count }, () => `
    <div class="skeleton-card">
      <div class="skeleton skeleton-line w-80"></div>
      <div class="skeleton skeleton-line w-60" style="margin-top:10px"></div>
      <div class="skeleton skeleton-line w-40" style="margin-top:6px"></div>
    </div>
  `).join('');
}

// ─── Build Feed Card HTML ─────────────────────────────────────
function buildFeedCard(item) {
  const typeClass = `type-${item.type || 'job'}`;
  const badgeClass = `badge-${item.type || 'job'}`;
  const badgeText = item.type === 'yojana' ? 'Yojana' : item.type === 'news' ? 'News' : 'Job';
  const isNew = item.isNew ? `<span class="badge badge-new">NEW</span>` : '';
  const date = formatDate(item.pubDate);
  const ago = timeAgo(item.pubDate);
  const waUrl = encodeURIComponent(`${item.title}\n${item.link}\n\nvia GovJobs & Yojna Info by Breakout Trade`);

  return `
    <article class="feed-card ${typeClass}" data-id="${item.id || ''}">
      <div class="feed-card-header">
        <h3 class="feed-card-title">
          <a href="${item.link || '#'}" target="_blank" rel="noopener noreferrer"
             onclick="trackLinkClick('${encodeURIComponent(item.title || '')}','${item.type || 'job'}')">
            ${escapeHtml(item.title || 'Untitled')}
          </a>
        </h3>
        <div class="badge-wrap">
          <span class="badge ${badgeClass}">${badgeText}</span>
          ${isNew}
        </div>
      </div>
      <div class="feed-card-meta">
        <span>📅 ${date}</span>
        ${ago ? `<span>🕐 ${ago}</span>` : ''}
        ${item.source ? `<span>📰 ${escapeHtml(item.source)}</span>` : ''}
        ${item.region && item.region !== 'all' ? `<span>📍 ${capitalize(item.region)}</span>` : ''}
      </div>
      ${item.desc ? `<p class="feed-card-desc">${escapeHtml(item.desc)}</p>` : ''}
      <div class="feed-card-actions">
        <a href="${item.link || '#'}" target="_blank" rel="noopener noreferrer"
           class="btn-primary"
           onclick="trackLinkClick('${encodeURIComponent(item.title || '')}','${item.type || 'job'}')">
          View Official Site →
        </a>
        <a href="https://wa.me/?text=${waUrl}"
           target="_blank" rel="noopener noreferrer"
           class="btn-whatsapp"
           onclick="trackShare('${encodeURIComponent(item.title || '')}')">
          📤 Share
        </a>
      </div>
    </article>
  `;
}

// ─── Tracking helpers ──────────────────────────────────────
function trackLinkClick(title, type) {
  try {
    if (typeof gtag !== 'undefined') {
      gtag('event', 'official_link_clicked', { title: decodeURIComponent(title), type });
    }
  } catch(e) {}
}
function trackShare(title) {
  try {
    if (typeof gtag !== 'undefined') {
      gtag('event', 'whatsapp_shared', { title: decodeURIComponent(title) });
    }
  } catch(e) {}
}

// ─── Escape HTML ────────────────────────────────────────────
function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function capitalize(str) {
  if (!str) return '';
  return str.charAt(0).toUpperCase() + str.slice(1);
}

// ─── Newsletter Subscribe ────────────────────────────────────
async function subscribeNewsletter(email) {
  if (!email || !email.includes('@')) {
    showToast('Please enter a valid email address.', 'error');
    return;
  }
  try {
    if (GovApp.db) {
      await GovApp.db.collection('newsletter').add({
        email,
        createdAt: firebase.firestore.FieldValue.serverTimestamp()
      });
    }
    showToast('✅ Subscribed! You\'ll receive weekly updates.', 'success');
    return true;
  } catch (e) {
    showToast('Subscription failed. Please try again.', 'error');
    return false;
  }
}

// ─── Contact Form Submit ─────────────────────────────────────
async function submitContact(name, email, subject, message) {
  try {
    if (GovApp.db) {
      await GovApp.db.collection('contacts').add({
        name, email, subject, message,
        createdAt: firebase.firestore.FieldValue.serverTimestamp()
      });
    }
    showToast('✅ Message sent! We\'ll respond within 48 hours.', 'success');
    return true;
  } catch (e) {
    showToast('Failed to send. Please try again.', 'error');
    return false;
  }
}

// expose globals
window.showToast = showToast;
window.shareWhatsApp = shareWhatsApp;
window.buildFeedCard = buildFeedCard;
window.renderSkeletons = renderSkeletons;
window.apiFetch = apiFetch;
window.formatDate = formatDate;
window.timeAgo = timeAgo;
window.debounce = debounce;
window.escapeHtml = escapeHtml;
window.subscribeNewsletter = subscribeNewsletter;
window.submitContact = submitContact;
window.trackLinkClick = trackLinkClick;
window.trackShare = trackShare;
