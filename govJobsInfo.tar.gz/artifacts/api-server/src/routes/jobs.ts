import { Router } from "express";
import { db } from "@workspace/db";
import { jobsTable } from "@workspace/db";
import { eq, desc, and, sql } from "drizzle-orm";
import {
  ListJobsQueryParams,
  CreateJobBody,
  GetJobParams,
} from "@workspace/api-zod";

const router = Router();

router.get("/", async (req, res) => {
  const parsed = ListJobsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    return res.status(400).json({ error: "Invalid query params" });
  }
  const { category, state, limit = 20, offset = 0 } = parsed.data;

  const conditions = [];
  if (category) conditions.push(eq(jobsTable.category, category));
  if (state) conditions.push(eq(jobsTable.state, state));

  const where = conditions.length > 0 ? and(...conditions) : undefined;

  const [jobs, countResult] = await Promise.all([
    db.select().from(jobsTable).where(where).orderBy(desc(jobsTable.createdAt)).limit(limit).offset(offset),
    db.select({ count: sql<number>`count(*)` }).from(jobsTable).where(where),
  ]);

  return res.json({ jobs, total: Number(countResult[0]?.count ?? 0) });
});

router.post("/", async (req, res) => {
  const parsed = CreateJobBody.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "Invalid body" });
  }
  const [job] = await db.insert(jobsTable).values(parsed.data).returning();
  return res.status(201).json(job);
});

router.get("/:id", async (req, res) => {
  const parsed = GetJobParams.safeParse({ id: Number(req.params.id) });
  if (!parsed.success) {
    return res.status(400).json({ error: "Invalid id" });
  }
  const [job] = await db.select().from(jobsTable).where(eq(jobsTable.id, parsed.data.id));
  if (!job) return res.status(404).json({ error: "Not found" });
  await db.update(jobsTable).set({ viewCount: sql`${jobsTable.viewCount} + 1` }).where(eq(jobsTable.id, parsed.data.id));
  return res.json(job);
});

export default router;
