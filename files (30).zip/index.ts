/**
 * India GovHub – Daily SEO Automation
 * Firebase Cloud Functions for scheduled content generation
 *
 * Deploy: firebase deploy --only functions
 * Schedule: Every day at 6:00 AM and 6:00 PM IST
 */

import { onSchedule } from "firebase-functions/v2/scheduler";
import { onRequest } from "firebase-functions/v2/https";
import { getFirestore } from "firebase-admin/firestore";
import { initializeApp } from "firebase-admin/app";

initializeApp();
const db = getFirestore();

// ─── Blog Topics Pool ──────────────────────────────────────────────────────

const BLOG_TOPICS = [
  {
    category: "govt-jobs",
    title: "🔥 Top Government Jobs Today 2026 – Apply Before Last Date",
    slug: "top-govt-jobs-today",
    keywords: ["govt jobs today 2026", "latest sarkari naukri"],
    sections: ["Latest Updates", "Top 10 Jobs", "Apply Process", "FAQ"],
  },
  {
    category: "kisan",
    title: "🌾 PM Kisan Latest Update – Installment Date & Status Check",
    slug: "pm-kisan-update",
    keywords: ["pm kisan update 2026", "pm kisan installment date"],
    sections: ["Latest Update", "How to Check Status", "Common Problems", "FAQ"],
  },
  {
    category: "schemes",
    title: "📋 New Government Scheme 2026 – Benefits, Eligibility & Apply",
    slug: "new-govt-scheme-2026",
    keywords: ["new government scheme 2026", "new pm yojana"],
    sections: ["Scheme Details", "Who Can Apply", "Apply Process", "Documents", "FAQ"],
  },
  {
    category: "results",
    title: "📊 Government Exam Results 2026 – SSC, Railway, Bank Updates",
    slug: "govt-exam-results",
    keywords: ["govt exam result 2026", "ssc result today"],
    sections: ["Today's Results", "How to Check", "Next Steps", "FAQ"],
  },
  {
    category: "admit-card",
    title: "🎫 Admit Card Download 2026 – Hall Ticket for Govt Exams",
    slug: "admit-card-2026",
    keywords: ["admit card 2026 download", "hall ticket government exam"],
    sections: ["Available Admit Cards", "Download Process", "Exam Day Tips", "FAQ"],
  },
  {
    category: "kisan",
    title: "💳 Kisan Credit Card Apply Online 2026 – Complete Guide",
    slug: "kisan-credit-card-apply",
    keywords: ["kisan credit card apply 2026", "kcc online apply"],
    sections: ["KCC Benefits", "Eligibility", "Apply Process", "Documents", "FAQ"],
  },
  {
    category: "govt-jobs",
    title: "🚆 Railway Recruitment 2026 – Complete Notification Guide",
    slug: "railway-recruitment-2026",
    keywords: ["railway recruitment 2026", "rrb group d apply"],
    sections: ["Vacancies List", "Eligibility", "Apply Online", "Exam Pattern", "FAQ"],
  },
  {
    category: "schemes",
    title: "🏠 PM Awas Yojana 2026 – Free House Scheme Apply Online",
    slug: "pm-awas-yojana-apply",
    keywords: ["pm awas yojana 2026 apply", "pmay gramin apply"],
    sections: ["Scheme Overview", "Eligibility", "Apply Process", "Beneficiary List", "FAQ"],
  },
];

// ─── Generate Blog Content ─────────────────────────────────────────────────

function generateBlogContent(topic: typeof BLOG_TOPICS[0], date: Date) {
  const dateStr = date.toLocaleDateString("en-IN", { 
    day: "numeric", month: "long", year: "numeric" 
  });

  return {
    id: `${topic.slug}-${Date.now()}`,
    slug: `${topic.slug}-${date.getFullYear()}-${date.getMonth() + 1}`,
    title: topic.title,
    category: topic.category,
    keywords: topic.keywords,
    sections: topic.sections,
    publishedAt: date.toISOString(),
    readTime: "5 min read",
    isNew: true,
    isTrending: false,
    viewCount: 0,
    lastUpdated: dateStr,
    metaDesc: `${topic.title}. Updated ${dateStr}. Complete guide with eligibility, application process, and FAQ.`,
    internalLinks: [
      { label: "Latest Govt Jobs 2026", href: "/seo/latest-govt-jobs-2026" },
      { label: "PM Kisan Yojana", href: "/seo/pm-kisan-yojana" },
      { label: "All Schemes", href: "/schemes" },
    ],
    schemaType: "Article",
  };
}

// ─── Update Sitemap ────────────────────────────────────────────────────────

const SEO_SLUGS = [
  "latest-govt-jobs-2026", "10th-pass-govt-jobs", "12th-pass-govt-jobs",
  "graduate-govt-jobs", "railway-jobs-2026", "bank-jobs-2026", "ssc-jobs-2026",
  "maharashtra-govt-jobs", "up-govt-jobs", "bihar-govt-jobs",
  "punjab-govt-jobs", "rajasthan-govt-jobs", "gujarat-govt-jobs",
  "tamilnadu-govt-jobs", "karnataka-govt-jobs", "delhi-govt-jobs",
  "pm-kisan-yojana", "pm-kisan-status-check", "tractor-subsidy-scheme",
  "crop-insurance-scheme", "kisan-credit-card",
  "pm-yojana-list", "women-schemes-india", "farmer-schemes-india",
  "emi-calculator", "age-calculator", "image-compressor",
];

function generateSitemapXml(blogSlugs: string[], today: string): string {
  const baseUrl = "https://india-govhub.web.app";

  const staticUrls = [
    { url: "/", priority: "1.0", freq: "daily" },
    { url: "/jobs", priority: "0.9", freq: "daily" },
    { url: "/schemes", priority: "0.9", freq: "weekly" },
    { url: "/blogs", priority: "0.8", freq: "daily" },
    { url: "/trending", priority: "0.8", freq: "daily" },
    { url: "/seo", priority: "0.9", freq: "weekly" },
  ];

  const seoUrls = SEO_SLUGS.map(s => ({ url: `/seo/${s}`, priority: "0.8", freq: "weekly" }));
  const blogUrls = blogSlugs.map(s => ({ url: `/blogs/${s}`, priority: "0.7", freq: "monthly" }));

  const allUrls = [...staticUrls, ...seoUrls, ...blogUrls];

  const entries = allUrls.map(u => `  <url>
    <loc>${baseUrl}${u.url}</loc>
    <lastmod>${today}</lastmod>
    <changefreq>${u.freq}</changefreq>
    <priority>${u.priority}</priority>
  </url>`).join("\n");

  return `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${entries}
</urlset>`;
}

// ─── Scheduled Functions ───────────────────────────────────────────────────

/**
 * Morning Blog – 6 AM IST daily
 * Generates blog post + updates trending
 */
export const morningBlogGeneration = onSchedule(
  {
    schedule: "0 0 * * *", // 12 AM UTC = 5:30 AM IST
    timeZone: "Asia/Kolkata",
    region: "asia-south1",
  },
  async (_event) => {
    const today = new Date();
    const dayIndex = today.getDate() % BLOG_TOPICS.length;
    const topic = BLOG_TOPICS[dayIndex];
    const blog = generateBlogContent(topic, today);

    // Save to Firestore
    await db.collection("blogs").doc(blog.id).set(blog);

    // Update trending: mark as new
    await db.collection("trending").doc(`blog-${blog.id}`).set({
      type: "blog",
      title: blog.title,
      refId: blog.slug,
      badge: "🆕",
      viewCount: 0,
      createdAt: today.toISOString(),
    });

    console.log(`Morning blog generated: ${blog.title}`);
  }
);

/**
 * Evening Blog – 6 PM IST daily
 */
export const eveningBlogGeneration = onSchedule(
  {
    schedule: "30 12 * * *", // 12:30 PM UTC = 6 PM IST
    timeZone: "Asia/Kolkata",
    region: "asia-south1",
  },
  async (_event) => {
    const today = new Date();
    const dayIndex = (today.getDate() + 5) % BLOG_TOPICS.length;
    const topic = BLOG_TOPICS[dayIndex];
    const blog = generateBlogContent(topic, today);

    await db.collection("blogs").doc(blog.id).set(blog);
    console.log(`Evening blog generated: ${blog.title}`);
  }
);

/**
 * Daily Sitemap Update – 1 AM IST
 */
export const dailySitemapUpdate = onSchedule(
  {
    schedule: "30 19 * * *", // 7:30 PM UTC = 1 AM IST next day
    timeZone: "Asia/Kolkata",
    region: "asia-south1",
  },
  async (_event) => {
    const today = new Date().toISOString().split("T")[0];

    // Fetch all blog slugs from Firestore
    const blogsSnapshot = await db.collection("blogs")
      .orderBy("publishedAt", "desc")
      .limit(50)
      .get();

    const blogSlugs = blogsSnapshot.docs.map(d => d.data().slug as string);
    const sitemap = generateSitemapXml(blogSlugs, today);

    // Save sitemap to Firestore (can be served by a Firebase Hosting function)
    await db.collection("system").doc("sitemap").set({
      xml: sitemap,
      updatedAt: today,
      urlCount: blogSlugs.length + SEO_SLUGS.length + 6,
    });

    console.log(`Sitemap updated: ${blogSlugs.length + SEO_SLUGS.length + 6} URLs`);
  }
);

/**
 * HTTP endpoint to serve sitemap dynamically
 * Add to firebase.json hosting rewrites: { "source": "/sitemap.xml", "function": "serveSitemap" }
 */
export const serveSitemap = onRequest({ region: "asia-south1" }, async (req, res) => {
  const doc = await db.collection("system").doc("sitemap").get();
  if (!doc.exists) {
    res.status(404).send("Sitemap not found");
    return;
  }
  res.setHeader("Content-Type", "application/xml");
  res.setHeader("Cache-Control", "public, max-age=3600");
  res.send(doc.data()?.xml);
});

/**
 * HTTP endpoint: GET /api/seo-stats
 * Returns content stats for the dashboard
 */
export const seoStats = onRequest({ region: "asia-south1" }, async (req, res) => {
  const [blogsSnap, trendingSnap] = await Promise.all([
    db.collection("blogs").count().get(),
    db.collection("trending").count().get(),
  ]);

  res.json({
    totalSeoPages: SEO_SLUGS.length,
    totalBlogs: blogsSnap.data().count,
    totalTrending: trendingSnap.data().count,
    lastUpdated: new Date().toISOString(),
  });
});
