import React from "react";
import { Link, useLocation } from "wouter";
import { Search, Home, Briefcase, FileText, BookOpen, Wrench, Menu, X, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);

  const navItems = [
    { label: "Home", href: "/", icon: Home },
    { label: "Jobs", href: "/jobs", icon: Briefcase },
    { label: "Schemes", href: "/schemes", icon: FileText },
    { label: "Blogs", href: "/blogs", icon: BookOpen },
    { label: "Tools", href: "/tools/emi-calculator", icon: Wrench },
    { label: "SEO Hub", href: "/seo", icon: TrendingUp },
  ];

  return (
    <div className="min-h-[100dvh] flex flex-col bg-background text-foreground pb-16 md:pb-0 font-sans">
      {/* Ticker */}
      <div className="bg-destructive text-destructive-foreground text-sm font-semibold py-1.5 overflow-hidden whitespace-nowrap relative border-b-2 border-accent">
        <div className="inline-block animate-marquee hover:pause px-4">
          🔥 Railway RRB Group D 1 Lakh+ Vacancies Open | 🌾 PM Kisan 17th Installment Coming Soon – Check Status Now | 🏦 SBI Clerk 2026 – 13,735 Vacancies Apply Online | 📋 PM Yojana List 2026 – 100+ Schemes | 🚜 Tractor Subsidy 50% – Apply in Your State | 👮 UP Police Constable 60,244 Vacancies – Hurry!
        </div>
      </div>

      {/* Header */}
      <header className="sticky top-0 z-50 bg-background border-b border-border shadow-sm">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 group">
            <div className="flex flex-col items-center justify-center bg-white p-1 rounded-md border border-border shadow-sm group-hover:shadow-md transition-shadow">
              <div className="w-8 h-2 bg-primary rounded-t-sm"></div>
              <div className="w-8 h-2 bg-white flex items-center justify-center">
                <div className="w-3 h-3 border border-primary rounded-full" />
              </div>
              <div className="w-8 h-2 bg-secondary rounded-b-sm"></div>
            </div>
            <span className="font-extrabold text-2xl tracking-tight text-foreground">
              India<span className="text-primary">Gov</span><span className="text-secondary">Hub</span>
            </span>
          </Link>

          <nav className="hidden md:flex items-center gap-6">
            {navItems.map((item) => (
              <Link 
                key={item.href} 
                href={item.href}
                className={`font-bold transition-colors hover:text-primary ${
                  location === item.href || (location.startsWith(item.href) && item.href !== "/") 
                    ? "text-primary border-b-2 border-primary py-5" 
                    : "text-muted-foreground"
                }`}
              >
                {item.label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <Button variant="outline" size="icon" className="hidden md:flex border-border bg-white hover:bg-muted text-foreground">
              <Search className="w-4 h-4" />
            </Button>
            <Button 
              variant="outline" 
              size="icon" 
              className="md:hidden border-border bg-white"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>
        </div>
        
        {/* Mobile Menu Dropdown */}
        {isMenuOpen && (
          <div className="md:hidden bg-card border-b border-border absolute w-full shadow-lg">
            <nav className="flex flex-col p-4 gap-4">
              {navItems.map((item) => (
                <Link 
                  key={item.href} 
                  href={item.href}
                  className="font-bold flex items-center gap-3 p-2 rounded-md hover:bg-muted text-foreground"
                  onClick={() => setIsMenuOpen(false)}
                >
                  <item.icon className="w-5 h-5 text-primary" />
                  {item.label}
                </Link>
              ))}
            </nav>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="flex-1 container mx-auto px-4 py-8">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-card border-t border-border mt-auto pb-6 pt-12 text-center text-muted-foreground text-sm">
        <div className="container mx-auto px-4">
          <div className="mb-6 grid grid-cols-2 md:grid-cols-4 gap-4 text-left">
            <div>
              <h4 className="font-bold text-foreground mb-3 uppercase tracking-wider text-xs">Categories</h4>
              <ul className="space-y-2">
                <li><Link href="/jobs" className="hover:text-primary">Government Jobs</Link></li>
                <li><Link href="/schemes" className="hover:text-primary">Kisan Schemes</Link></li>
                <li><Link href="/blogs" className="hover:text-primary">Latest News</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-foreground mb-3 uppercase tracking-wider text-xs">Popular Jobs</h4>
              <ul className="space-y-2">
                <li><Link href="/seo/railway-jobs-2026" className="hover:text-primary">Railway Jobs 2026</Link></li>
                <li><Link href="/seo/bank-jobs-2026" className="hover:text-primary">Bank Jobs 2026</Link></li>
                <li><Link href="/seo/ssc-jobs-2026" className="hover:text-primary">SSC Jobs 2026</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-foreground mb-3 uppercase tracking-wider text-xs">Tools</h4>
              <ul className="space-y-2">
                <li><Link href="/tools/emi-calculator" className="hover:text-primary">EMI Calculator</Link></li>
                <li><Link href="/tools/age-calculator" className="hover:text-primary">Age Calculator</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-foreground mb-3 uppercase tracking-wider text-xs">States</h4>
              <ul className="space-y-2">
                <li><Link href="/seo/maharashtra-govt-jobs" className="hover:text-primary">Maharashtra Jobs</Link></li>
                <li><Link href="/seo/up-govt-jobs" className="hover:text-primary">UP Jobs</Link></li>
                <li><Link href="/seo/bihar-govt-jobs" className="hover:text-primary">Bihar Jobs</Link></li>
              </ul>
            </div>
          </div>
          <p>© {new Date().getFullYear()} India GovHub. All rights reserved. Not an official government website.</p>
        </div>
      </footer>

      {/* Mobile Bottom Nav */}
      <nav className="md:hidden fixed bottom-0 w-full bg-card border-t border-border flex justify-around items-center p-2 pb-safe shadow-[0_-4px_10px_rgba(0,0,0,0.05)] z-50">
        {navItems.map((item) => (
          <Link key={item.href} href={item.href} className={`flex flex-col items-center justify-center w-16 h-12 rounded-lg ${
            location === item.href || (location.startsWith(item.href) && item.href !== "/") 
              ? "text-primary font-bold" 
              : "text-muted-foreground"
          }`}>
            <item.icon className="w-5 h-5 mb-1" />
            <span className="text-[10px] leading-tight">{item.label}</span>
          </Link>
        ))}
      </nav>
    </div>
  );
}
