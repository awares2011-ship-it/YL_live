import { useGetDashboardSummary, getGetDashboardSummaryQueryKey } from "@workspace/api-client-react";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { ChevronRight, TrendingUp, Briefcase, FileText, BookOpen } from "lucide-react";
import AdSense from "@/components/adsense";

export default function Home() {
  const { data: summary, isLoading } = useGetDashboardSummary({ query: { queryKey: getGetDashboardSummaryQueryKey() } });

  if (isLoading) {
    return (
      <div className="space-y-8">
        <Skeleton className="h-40 w-full rounded-xl" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-24 w-full rounded-lg" />
          ))}
        </div>
        <Skeleton className="h-64 w-full rounded-xl" />
      </div>
    );
  }

  if (!summary) return <div>Failed to load data</div>;

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-primary/10 via-background to-secondary/10 rounded-2xl p-6 md:p-10 border border-border">
        <div className="max-w-2xl">
          <Badge className="bg-destructive hover:bg-destructive/90 text-white mb-4">Latest Updates 🔥</Badge>
          <h1 className="text-3xl md:text-5xl font-extrabold mb-4 text-foreground leading-tight">
            Find Your Dream <span className="text-primary">Sarkari Naukri</span> Today
          </h1>
          <p className="text-muted-foreground text-lg mb-6">
            Get instant updates on government jobs, PM Kisan yojana, state schemes, and exam results. 
          </p>
          <div className="flex flex-wrap gap-3">
            <Link href="/jobs">
              <Button size="lg" className="bg-primary hover:bg-primary/90 text-white font-bold px-8">
                Browse Jobs
              </Button>
            </Link>
            <Link href="/schemes">
              <Button size="lg" variant="outline" className="border-secondary text-secondary hover:bg-secondary/10 font-bold px-8">
                View Schemes
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <AdSense slot="home_top" />

      {/* Quick Links */}
      <section>
        <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
          <Briefcase className="text-primary" /> Popular Categories
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { title: "Railway Jobs", icon: "🚆", color: "bg-primary/10 text-primary border-primary/20", href: "/jobs?category=railway" },
            { title: "Bank Jobs", icon: "🏦", color: "bg-secondary/10 text-secondary border-secondary/20", href: "/jobs?category=bank" },
            { title: "Defence Jobs", icon: "⚔️", color: "bg-destructive/10 text-destructive border-destructive/20", href: "/jobs?category=defence" },
            { title: "Kisan Schemes", icon: "🌾", color: "bg-accent/10 text-accent border-accent/20", href: "/schemes?category=kisan" },
          ].map((cat) => (
            <Link key={cat.title} href={cat.href}>
              <Card className={`hover-elevate cursor-pointer border ${cat.color} transition-colors hover:shadow-md`}>
                <CardContent className="p-6 text-center flex flex-col items-center gap-2">
                  <span className="text-3xl mb-2">{cat.icon}</span>
                  <span className="font-bold">{cat.title}</span>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      {/* Latest Jobs */}
      <section>
        <div className="flex justify-between items-end mb-4">
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <TrendingUp className="text-destructive" /> Latest Jobs
          </h2>
          <Link href="/jobs" className="text-primary font-semibold flex items-center hover:underline text-sm md:text-base">
            View All <ChevronRight className="w-4 h-4" />
          </Link>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {summary.latestJobs.slice(0, 6).map((job) => (
            <Link key={job.id} href={`/jobs/${job.id}`}>
              <Card className="hover-elevate h-full cursor-pointer hover:border-primary/50 transition-colors">
                <CardContent className="p-5">
                  <div className="flex justify-between items-start mb-3 gap-2">
                    <Badge variant="outline" className="bg-muted text-muted-foreground font-semibold border-border">
                      {job.category.toUpperCase()}
                    </Badge>
                    <div className="flex gap-1">
                      {job.isHot && <Badge className="bg-accent text-accent-foreground border-none">Hot 🔥</Badge>}
                      {job.isNew && <Badge className="bg-secondary text-white border-none">New</Badge>}
                    </div>
                  </div>
                  <h3 className="font-bold text-lg leading-snug mb-1 text-foreground line-clamp-2">
                    {job.title}
                  </h3>
                  <p className="text-muted-foreground text-sm font-medium mb-4">{job.organization}</p>
                  
                  <div className="space-y-2 text-sm text-muted-foreground mb-4">
                    <div className="flex justify-between">
                      <span>Vacancies:</span>
                      <span className="font-bold text-foreground">{job.vacancies}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Last Date:</span>
                      <span className="font-bold text-destructive">{new Date(job.lastDate).toLocaleDateString()}</span>
                    </div>
                  </div>
                  
                  <Button className="w-full bg-primary/10 text-primary hover:bg-primary hover:text-white" variant="secondary">
                    View Details
                  </Button>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      <AdSense slot="home_middle" />

      {/* SEO Quick Access Section */}
      <section>
        <div className="flex justify-between items-end mb-4">
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <TrendingUp className="text-destructive" /> 🔥 Hot Topics
          </h2>
          <Link href="/seo" className="text-primary font-semibold flex items-center hover:underline text-sm">
            All Pages <ChevronRight className="w-4 h-4" />
          </Link>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
          {[
            { label: "🚆 Railway Jobs 2026", href: "/seo/railway-jobs-2026", badge: "1L+ Vacancies", color: "bg-orange-50 border-orange-200 text-orange-700" },
            { label: "🌾 PM Kisan Status", href: "/seo/pm-kisan-status-check", badge: "Check Now", color: "bg-green-50 border-green-200 text-green-700" },
            { label: "🏦 Bank Jobs 2026", href: "/seo/bank-jobs-2026", badge: "25,000+", color: "bg-blue-50 border-blue-200 text-blue-700" },
            { label: "📋 PM Yojana List", href: "/seo/pm-yojana-list", badge: "100+ Schemes", color: "bg-purple-50 border-purple-200 text-purple-700" },
            { label: "👮 UP Police 2026", href: "/seo/up-govt-jobs", badge: "60,244 Posts", color: "bg-red-50 border-red-200 text-red-700" },
            { label: "💳 Kisan Credit Card", href: "/seo/kisan-credit-card", badge: "₹3L at 4%", color: "bg-yellow-50 border-yellow-200 text-yellow-700" },
            { label: "🎓 Graduate Jobs", href: "/seo/graduate-govt-jobs", badge: "2 Lakh+", color: "bg-teal-50 border-teal-200 text-teal-700" },
            { label: "📅 Age Calculator", href: "/tools/age-calculator", badge: "Free Tool", color: "bg-gray-50 border-gray-200 text-gray-700" },
          ].map((item) => (
            <Link key={item.href} href={item.href}>
              <div className={`border rounded-xl p-3 hover:shadow-md transition-all hover:-translate-y-0.5 cursor-pointer ${item.color}`}>
                <p className="font-bold text-sm line-clamp-1">{item.label}</p>
                <p className="text-xs mt-1 opacity-70">{item.badge}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <div className="grid md:grid-cols-2 gap-8">
        {/* Latest Schemes */}
        <section>
          <div className="flex justify-between items-end mb-4">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <FileText className="text-secondary" /> Govt Schemes
            </h2>
            <Link href="/schemes" className="text-secondary font-semibold flex items-center hover:underline text-sm">
              All Schemes <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
          
          <div className="space-y-3">
            {summary.latestSchemes.slice(0, 4).map((scheme) => (
              <Link key={scheme.id} href={`/schemes/${scheme.id}`}>
                <div className="flex p-4 rounded-xl border border-border bg-card hover:bg-muted/50 transition-colors items-center gap-4 group">
                  <div className="w-12 h-12 rounded-full bg-secondary/10 text-secondary flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                    <FileText className="w-6 h-6" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-foreground line-clamp-1">{scheme.title}</h3>
                    <p className="text-sm text-muted-foreground line-clamp-1">{scheme.description}</p>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </section>

        {/* Trending Now */}
        <section>
          <div className="flex justify-between items-end mb-4">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <TrendingUp className="text-accent" /> Trending Now
            </h2>
            <Link href="/trending" className="text-accent font-semibold flex items-center hover:underline text-sm">
              Top 10 <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
          
          <Card className="border-border shadow-sm">
            <CardContent className="p-0 divide-y divide-border">
              {summary.trendingNow.slice(0, 5).map((item, idx) => (
                <Link 
                  key={`${item.type}-${item.refId}`} 
                  href={`/${item.type}s/${item.refId}`}
                  className="flex items-center p-4 hover:bg-muted/50 transition-colors gap-4"
                >
                  <div className="font-black text-2xl text-muted-foreground/30 w-6 text-center">
                    {idx + 1}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-semibold text-foreground line-clamp-1">{item.title}</h4>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant="outline" className="text-[10px] py-0 px-1 border-border">
                        {item.type.toUpperCase()}
                      </Badge>
                      <span className="text-xs text-muted-foreground">{item.viewCount} views</span>
                    </div>
                  </div>
                  {item.badge && (
                    <Badge className="bg-destructive text-white">{item.badge}</Badge>
                  )}
                </Link>
              ))}
            </CardContent>
          </Card>
        </section>
      </div>
    </div>
  );
}
