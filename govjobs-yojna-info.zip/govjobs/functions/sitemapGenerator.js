/**
 * GovJobs & Yojna Info — sitemapGenerator.js
 * Dynamic sitemap generation with hreflang
 * Developed by Breakout Trade
 */

const admin = require('firebase-admin');

const BASE_URL = 'https://govjobsyojnainfo.in';
const LANGS = ['hi','mr','gu','ta','te','kn','bn','pa','ml'];

const STATIC_PAGES = [
  { path: '/',                        priority: '1.0', changefreq: 'daily' },
  { path: '/jobs.html',               priority: '0.9', changefreq: 'daily' },
  { path: '/yojana.html',             priority: '0.9', changefreq: 'daily' },
  { path: '/news.html',               priority: '0.8', changefreq: 'daily' },
  { path: '/blog/',                   priority: '0.8', changefreq: 'daily' },
  { path: '/about.html',              priority: '0.5', changefreq: 'monthly' },
  { path: '/contact.html',            priority: '0.5', changefreq: 'monthly' },
  { path: '/privacy-policy.html',     priority: '0.3', changefreq: 'yearly' },
  { path: '/terms-of-service.html',   priority: '0.3', changefreq: 'yearly' },
  { path: '/disclaimer.html',         priority: '0.3', changefreq: 'yearly' },
];

// ─── Generate Sitemap XML ─────────────────────────────────────
async function generateSitemap() {
  const db = admin.firestore();

  // Fetch all blog slugs
  let blogPosts = [];
  try {
    const snap = await db.collection('blogs')
      .orderBy('publishedAt', 'desc')
      .limit(500)
      .get();
    blogPosts = snap.docs.map(d => ({
      slug: d.id,
      publishedAt: d.data().publishedAt?.toDate?.()?.toISOString() || new Date().toISOString()
    }));
  } catch (err) {
    console.warn('sitemapGenerator: could not fetch blogs:', err.message);
  }

  const xml = buildSitemapXML(blogPosts);
  return xml;
}

// ─── Build XML ────────────────────────────────────────────────
function buildSitemapXML(blogPosts) {
  const now = new Date().toISOString().split('T')[0];

  let urlEntries = '';

  // Static pages with hreflang
  for (const page of STATIC_PAGES) {
    const url = `${BASE_URL}${page.path}`;
    urlEntries += `
  <url>
    <loc>${url}</loc>
    <lastmod>${now}</lastmod>
    <changefreq>${page.changefreq}</changefreq>
    <priority>${page.priority}</priority>
    <xhtml:link rel="alternate" hreflang="x-default" href="${url}"/>
    <xhtml:link rel="alternate" hreflang="en-IN" href="${url}"/>
    ${LANGS.map(l => `<xhtml:link rel="alternate" hreflang="${l}" href="${BASE_URL}/${l}${page.path}"/>`).join('\n    ')}
  </url>`;
  }

  // Blog posts
  for (const post of blogPosts) {
    const url = `${BASE_URL}/blog/post.html?slug=${encodeURIComponent(post.slug)}`;
    const date = (post.publishedAt || '').split('T')[0] || now;
    urlEntries += `
  <url>
    <loc>${url}</loc>
    <lastmod>${date}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>`;
  }

  return `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:xhtml="http://www.w3.org/1999/xhtml">
${urlEntries}
</urlset>`;
}

module.exports = { generateSitemap };
