import { pgTable, serial, text, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const jobsTable = pgTable("jobs", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  organization: text("organization").notNull(),
  category: text("category").notNull(),
  state: text("state").notNull().default("All India"),
  totalPosts: integer("total_posts").notNull().default(0),
  salary: text("salary").notNull(),
  lastDate: text("last_date").notNull(),
  qualifications: text("qualifications").notNull(),
  content: text("content").notNull(),
  applyUrl: text("apply_url"),
  isTrending: boolean("is_trending").notNull().default(false),
  isNew: boolean("is_new").notNull().default(true),
  viewCount: integer("view_count").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertJobSchema = createInsertSchema(jobsTable).omit({ id: true, createdAt: true });
export type InsertJob = z.infer<typeof insertJobSchema>;
export type Job = typeof jobsTable.$inferSelect;
