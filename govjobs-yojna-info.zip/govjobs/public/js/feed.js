/**
 * GovJobs & Yojna Info — feed.js
 * Feed loading, filtering, pagination
 * Developed by Breakout Trade
 */

const ITEMS_PER_PAGE = 15;
let feedState = {
  items: [],
  filtered: [],
  page: 1,
  type: 'all',
  region: 'all',
  loading: false
};

// ─── Initialize Feed ────────────────────────────────────────
async function initFeed(defaultType = 'all', defaultRegion = 'all') {
  feedState.type = defaultType;
  feedState.region = localStorage.getItem('gj_region') || defaultRegion;

  const regionSelect = document.getElementById('region-select');
  if (regionSelect) {
    regionSelect.value = feedState.region;
    regionSelect.addEventListener('change', (e) => {
      feedState.region = e.target.value;
      localStorage.setItem('gj_region', feedState.region);
      feedState.page = 1;
      loadFeed();
    });
  }

  // Filter buttons
  document.querySelectorAll('.filter-btn[data-type]').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.filter-btn[data-type]').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      feedState.type = btn.dataset.type;
      feedState.page = 1;
      applyFilters();
      renderFeed();
    });
  });

  await loadFeed();
}

// ─── Load Feed from API ──────────────────────────────────────
async function loadFeed() {
  if (feedState.loading) return;
  feedState.loading = true;

  const container = document.getElementById('feed-container');
  if (!container) { feedState.loading = false; return; }

  renderSkeletons(container, 6);

  const params = {
    page: feedState.page,
    limit: ITEMS_PER_PAGE
  };
  if (feedState.type !== 'all') params.type = feedState.type;
  if (feedState.region !== 'all') params.region = feedState.region;
  if (GovApp?.currentLang) params.lang = GovApp.currentLang;

  try {
    const data = await apiFetch('/feed', params);
    feedState.items = Array.isArray(data.items) ? data.items : [];
    feedState.total = data.total || feedState.items.length;
    applyFilters();
    renderFeed();

    if (typeof gtag !== 'undefined') {
      gtag('event', 'feed_loaded', {
        region: feedState.region,
        type: feedState.type,
        item_count: feedState.items.length
      });
    }
  } catch (e) {
    container.innerHTML = `
      <div class="error-card">
        <p>⚠️ Could not load feed. Please check your connection and try again.</p>
        <button onclick="loadFeed()" class="btn-primary" style="margin-top:12px">Retry</button>
      </div>
    `;
  } finally {
    feedState.loading = false;
  }
}

// ─── Apply Client-Side Filters ───────────────────────────────
function applyFilters() {
  let items = [...feedState.items];
  if (feedState.type !== 'all') {
    items = items.filter(i => i.type === feedState.type);
  }
  if (feedState.region !== 'all') {
    items = items.filter(i => !i.region || i.region === 'all' || i.region === feedState.region);
  }
  feedState.filtered = items;
}

// ─── Render Feed ─────────────────────────────────────────────
function renderFeed() {
  const container = document.getElementById('feed-container');
  if (!container) return;

  const items = feedState.filtered;
  const start = (feedState.page - 1) * ITEMS_PER_PAGE;
  const pageItems = items.slice(start, start + ITEMS_PER_PAGE);

  if (pageItems.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">📭</div>
        <p>No results found for your selection. Try changing the filter or region.</p>
      </div>
    `;
    updatePagination(0);
    return;
  }

  // Inject ad after card 3 and card 8
  let html = '';
  pageItems.forEach((item, idx) => {
    html += buildFeedCard(item);
    if (idx === 2) html += buildAdSlot('YOUR_AD_SLOT_ID_2');
    if (idx === 7) html += buildAdSlot('YOUR_AD_SLOT_ID_3');
  });

  container.innerHTML = html;
  updatePagination(items.length);

  // Initialize adsbygoogle for injected ads
  try {
    (window.adsbygoogle = window.adsbygoogle || []).push({});
    (window.adsbygoogle = window.adsbygoogle || []).push({});
  } catch(e) {}
}

// ─── Build Ad Slot HTML ──────────────────────────────────────
function buildAdSlot(slotId) {
  return `
    <div class="ad-slot ad-slot-rectangle">
      <ins class="adsbygoogle"
           style="display:block"
           data-ad-client="ca-pub-YOUR_ADSENSE_PUBLISHER_ID"
           data-ad-slot="${slotId}"
           data-ad-format="auto"
           data-full-width-responsive="true"></ins>
    </div>
  `;
}

// ─── Pagination ──────────────────────────────────────────────
function updatePagination(totalItems) {
  const container = document.getElementById('pagination');
  if (!container) return;

  const totalPages = Math.ceil(totalItems / ITEMS_PER_PAGE);
  if (totalPages <= 1) { container.innerHTML = ''; return; }

  let html = `
    <button class="page-btn" onclick="changePage(${feedState.page - 1})"
            ${feedState.page === 1 ? 'disabled' : ''}>‹</button>
  `;

  const start = Math.max(1, feedState.page - 2);
  const end = Math.min(totalPages, feedState.page + 2);

  if (start > 1) html += `<button class="page-btn" onclick="changePage(1)">1</button>`;
  if (start > 2) html += `<span style="padding:0 4px;color:var(--text-3)">…</span>`;

  for (let i = start; i <= end; i++) {
    html += `<button class="page-btn ${i === feedState.page ? 'active' : ''}" onclick="changePage(${i})">${i}</button>`;
  }

  if (end < totalPages - 1) html += `<span style="padding:0 4px;color:var(--text-3)">…</span>`;
  if (end < totalPages) html += `<button class="page-btn" onclick="changePage(${totalPages})">${totalPages}</button>`;

  html += `<button class="page-btn" onclick="changePage(${feedState.page + 1})"
            ${feedState.page === totalPages ? 'disabled' : ''}>›</button>`;

  container.innerHTML = html;
}

function changePage(page) {
  const totalPages = Math.ceil(feedState.filtered.length / ITEMS_PER_PAGE);
  if (page < 1 || page > totalPages) return;
  feedState.page = page;
  renderFeed();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ─── Stats Counter ───────────────────────────────────────────
async function loadStats() {
  try {
    const data = await apiFetch('/stats');
    if (!data) return;
    const el = (id, val) => {
      const e = document.getElementById(id);
      if (e && val !== undefined) animateCount(e, val);
    };
    el('stat-jobs', data.totalJobs);
    el('stat-yojanas', data.totalYojanas);
    el('stat-news', data.totalNews);
    el('stat-blogs', data.totalBlogs);
  } catch (e) { /* stats are non-critical */ }
}

function animateCount(el, target) {
  const start = 0;
  const duration = 1200;
  const startTime = performance.now();
  const update = (now) => {
    const elapsed = now - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    el.textContent = Math.floor(start + (target - start) * eased).toLocaleString('en-IN');
    if (progress < 1) requestAnimationFrame(update);
  };
  requestAnimationFrame(update);
}

// ─── State Selector ──────────────────────────────────────────
function selectState(state) {
  feedState.region = state;
  feedState.page = 1;
  localStorage.setItem('gj_region', state);
  const regionSelect = document.getElementById('region-select');
  if (regionSelect) regionSelect.value = state;
  loadFeed();
  if (typeof gtag !== 'undefined') {
    gtag('event', 'state_selected', { state });
  }
}

window.initFeed = initFeed;
window.loadFeed = loadFeed;
window.changePage = changePage;
window.loadStats = loadStats;
window.selectState = selectState;
