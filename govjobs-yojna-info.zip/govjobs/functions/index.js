/**
 * GovJobs & Yojna Info — functions/index.js
 * Firebase Functions: API endpoints + scheduled tasks
 * Developed by Breakout Trade
 */

const functions = require('firebase-functions');
const admin = require('firebase-admin');
const express = require('express');
const cors = require('cors');

admin.initializeApp();
const db = admin.firestore();

const { fetchAllFeeds } = require('./feedFetcher');
const { generateBlogPosts } = require('./blogGenerator');
const { generateSitemap } = require('./sitemapGenerator');

const app = express();
app.use(cors({ origin: true }));
app.use(express.json());

const CACHE_TTL_MS = 2 * 60 * 60 * 1000; // 2 hours

// ═══════════════════════════════════════════════════════════════
// CACHE HELPERS
// ═══════════════════════════════════════════════════════════════
async function getCached(key) {
  try {
    const doc = await db.collection('cache').doc(key).get();
    if (!doc.exists) return null;
    const data = doc.data();
    if (!data || !data.expiresAt) return null;
    const expiry = data.expiresAt.toDate ? data.expiresAt.toDate() : new Date(data.expiresAt);
    if (Date.now() > expiry.getTime()) return null;
    return data.payload;
  } catch (e) { return null; }
}

async function setCached(key, payload) {
  try {
    await db.collection('cache').doc(key).set({
      payload,
      expiresAt: new Date(Date.now() + CACHE_TTL_MS),
      createdAt: admin.firestore.FieldValue.serverTimestamp()
    });
  } catch (e) { /* cache write failure is non-critical */ }
}

// ═══════════════════════════════════════════════════════════════
// GET /api/feed
// Query: ?type=job|yojana|news|all &region=... &lang=... &page=1 &limit=15
// ═══════════════════════════════════════════════════════════════
app.get('/feed', async (req, res) => {
  res.set('Cache-Control', 'public, max-age=3600, s-maxage=7200');
  const { type = 'all', region = 'all', lang, page = 1, limit = 15 } = req.query;
  const pageNum = Math.max(1, parseInt(page) || 1);
  const limitNum = Math.min(50, Math.max(1, parseInt(limit) || 15));
  const cacheKey = `feed_${type}_${region}_${lang || 'all'}_p${pageNum}_l${limitNum}`;

  const cached = await getCached(cacheKey);
  if (cached) return res.json(cached);

  try {
    let query = db.collection('feeds').orderBy('pubDate', 'desc');

    if (type !== 'all') query = query.where('type', '==', type);
    if (region !== 'all') query = query.where('region', 'in', [region, 'central']);
    if (lang) query = query.where('lang', '==', lang);

    const snap = await query.limit(pageNum * limitNum + limitNum).get();
    const allItems = snap.docs.map(d => ({ id: d.id, ...d.data(), createdAt: undefined }));
    const start = (pageNum - 1) * limitNum;
    const items = allItems.slice(start, start + limitNum);

    const result = { items, total: allItems.length, page: pageNum, limit: limitNum };
    await setCached(cacheKey, result);
    res.json(result);
  } catch (err) {
    console.error('/api/feed error:', err);
    res.status(500).json({ error: 'Failed to fetch feed', items: [], total: 0 });
  }
});

// ═══════════════════════════════════════════════════════════════
// GET /api/search
// Query: ?q=... &region=all &lang=en
// ═══════════════════════════════════════════════════════════════
app.get('/search', async (req, res) => {
  res.set('Cache-Control', 'public, max-age=1800');
  const { q = '', region = 'all', lang } = req.query;

  if (!q || q.trim().length < 2) {
    return res.json({ results: [], query: q });
  }

  const query = q.trim().toLowerCase();
  const cacheKey = `search_${query}_${region}_${lang || 'all'}`;
  const cached = await getCached(cacheKey);
  if (cached) return res.json(cached);

  try {
    // Firestore doesn't have full-text search — fetch recent items and filter client-side
    let dbQuery = db.collection('feeds').orderBy('pubDate', 'desc').limit(200);
    if (region !== 'all') dbQuery = dbQuery.where('region', '==', region);

    const snap = await dbQuery.get();
    const items = snap.docs
      .map(d => ({ id: d.id, ...d.data() }))
      .filter(item => {
        const title = (item.title || '').toLowerCase();
        const desc = (item.desc || '').toLowerCase();
        return title.includes(query) || desc.includes(query);
      })
      .slice(0, 10);

    // Also search blogs
    const blogSnap = await db.collection('blogs').orderBy('publishedAt', 'desc').limit(50).get();
    const blogResults = blogSnap.docs
      .map(d => ({ id: d.id, type: 'blog', ...d.data() }))
      .filter(b => (b.title || '').toLowerCase().includes(query))
      .slice(0, 3);

    const results = [...items, ...blogResults];
    const response = { results, query };
    await setCached(cacheKey, response);
    res.json(response);
  } catch (err) {
    console.error('/api/search error:', err);
    res.status(500).json({ results: [], query, error: 'Search failed' });
  }
});

// ═══════════════════════════════════════════════════════════════
// GET /api/blog
// Query: ?slug=... | ?page=1 &limit=10 &category=... &region=... &lang=...
// ═══════════════════════════════════════════════════════════════
app.get('/blog', async (req, res) => {
  res.set('Cache-Control', 'public, max-age=3600');
  const { slug, page = 1, limit = 10, category, region, lang } = req.query;

  // Single post by slug
  if (slug) {
    try {
      const doc = await db.collection('blogs').doc(slug).get();
      if (!doc.exists) return res.status(404).json({ error: 'Post not found' });
      // Increment views
      db.collection('blogs').doc(slug).update({ views: admin.firestore.FieldValue.increment(1) }).catch(() => {});
      return res.json({ post: { slug: doc.id, ...doc.data() } });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to fetch post' });
    }
  }

  // Post listing
  const pageNum = Math.max(1, parseInt(page) || 1);
  const limitNum = Math.min(50, parseInt(limit) || 10);
  const cacheKey = `blog_${category || 'all'}_${region || 'all'}_${lang || 'all'}_p${pageNum}`;
  const cached = await getCached(cacheKey);
  if (cached) return res.json(cached);

  try {
    let query = db.collection('blogs').orderBy('publishedAt', 'desc');
    if (category) query = query.where('category', '==', category);
    if (region) query = query.where('region', '==', region);
    if (lang) query = query.where('lang', '==', lang);

    const snap = await query.limit(pageNum * limitNum + limitNum).get();
    const allPosts = snap.docs.map(d => {
      const data = d.data();
      return {
        slug: d.id,
        title: data.title,
        category: data.category,
        region: data.region,
        lang: data.lang,
        excerpt: data.excerpt,
        publishedAt: data.publishedAt,
        readTime: data.readTime,
        views: data.views || 0
        // Do not include full content in listing
      };
    });

    const start = (pageNum - 1) * limitNum;
    const posts = allPosts.slice(start, start + limitNum);
    const result = { posts, total: allPosts.length, page: pageNum, limit: limitNum };
    await setCached(cacheKey, result);
    res.json(result);
  } catch (err) {
    console.error('/api/blog error:', err);
    res.status(500).json({ posts: [], total: 0, error: 'Failed to fetch blog posts' });
  }
});

// ═══════════════════════════════════════════════════════════════
// GET /api/ticker
// Returns top 10 latest items for ticker bar
// ═══════════════════════════════════════════════════════════════
app.get('/ticker', async (req, res) => {
  res.set('Cache-Control', 'public, max-age=1800');

  const cached = await getCached('ticker_items');
  if (cached) return res.json(cached);

  try {
    const snap = await db.collection('latestUpdates').orderBy('pubDate', 'desc').limit(10).get();
    const items = snap.docs.map(d => d.data());

    if (items.length === 0) {
      // Fall back to latest feeds
      const feedSnap = await db.collection('feeds').orderBy('pubDate', 'desc').limit(10).get();
      const feedItems = feedSnap.docs.map(d => ({ id: d.id, ...d.data() }));
      const result = { items: feedItems };
      await setCached('ticker_items', result);
      return res.json(result);
    }

    const result = { items };
    await setCached('ticker_items', result);
    res.json(result);
  } catch (err) {
    console.error('/api/ticker error:', err);
    res.status(500).json({ items: [], error: 'Failed to fetch ticker' });
  }
});

// ═══════════════════════════════════════════════════════════════
// GET /api/stats
// ═══════════════════════════════════════════════════════════════
app.get('/stats', async (req, res) => {
  res.set('Cache-Control', 'public, max-age=3600');
  try {
    const doc = await db.collection('stats').doc('main').get();
    if (doc.exists) return res.json(doc.data());
    res.json({ totalJobs: 0, totalYojanas: 0, totalNews: 0, totalBlogs: 0 });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch stats' });
  }
});

// ═══════════════════════════════════════════════════════════════
// GET /api/sitemap
// Dynamic sitemap XML
// ═══════════════════════════════════════════════════════════════
app.get('/sitemap', async (req, res) => {
  res.set('Cache-Control', 'public, max-age=86400');
  try {
    const xml = await generateSitemap();
    res.set('Content-Type', 'application/xml');
    res.send(xml);
  } catch (err) {
    res.status(500).send('<?xml version="1.0"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"></urlset>');
  }
});

// 404 for unknown API routes
app.use((req, res) => {
  res.status(404).json({ error: 'API endpoint not found', path: req.path });
});

// ═══════════════════════════════════════════════════════════════
// EXPORT: Express API
// ═══════════════════════════════════════════════════════════════
exports.api = functions
  .region('asia-south1')
  .runWith({ timeoutSeconds: 30, memory: '256MB' })
  .https.onRequest(app);

// ═══════════════════════════════════════════════════════════════
// SCHEDULED: RSS Fetcher — every 48 hours
// ═══════════════════════════════════════════════════════════════
exports.scheduledFeedFetch = functions
  .region('asia-south1')
  .runWith({ timeoutSeconds: 540, memory: '512MB' })
  .pubsub.schedule('0 6 */2 * *') // 6 AM every 2 days
  .timeZone('Asia/Kolkata')
  .onRun(async (context) => {
    console.log('scheduledFeedFetch started');
    try {
      const result = await fetchAllFeeds();
      console.log('scheduledFeedFetch complete:', result);
    } catch (err) {
      console.error('scheduledFeedFetch failed:', err);
    }
  });

// ═══════════════════════════════════════════════════════════════
// SCHEDULED: Blog Generator — daily at 7 AM IST
// ═══════════════════════════════════════════════════════════════
exports.scheduledBlogGenerate = functions
  .region('asia-south1')
  .runWith({ timeoutSeconds: 540, memory: '512MB' })
  .pubsub.schedule('0 7 * * *')
  .timeZone('Asia/Kolkata')
  .onRun(async (context) => {
    console.log('scheduledBlogGenerate started');
    try {
      const result = await generateBlogPosts();
      console.log('scheduledBlogGenerate complete:', result);
    } catch (err) {
      console.error('scheduledBlogGenerate failed:', err);
    }
  });

// ═══════════════════════════════════════════════════════════════
// MANUAL TRIGGER: HTTP endpoint to trigger feed fetch (for testing)
// ═══════════════════════════════════════════════════════════════
exports.triggerFeedFetch = functions
  .region('asia-south1')
  .runWith({ timeoutSeconds: 540, memory: '512MB' })
  .https.onRequest(async (req, res) => {
    // Basic secret check
    const secret = req.query.secret || req.headers['x-admin-secret'];
    const expectedSecret = functions.config().admin?.secret || 'change-me-in-production';
    if (secret !== expectedSecret) {
      return res.status(403).json({ error: 'Unauthorized' });
    }
    try {
      const result = await fetchAllFeeds();
      res.json({ success: true, ...result });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

exports.triggerBlogGenerate = functions
  .region('asia-south1')
  .runWith({ timeoutSeconds: 540, memory: '512MB' })
  .https.onRequest(async (req, res) => {
    const secret = req.query.secret || req.headers['x-admin-secret'];
    const expectedSecret = functions.config().admin?.secret || 'change-me-in-production';
    if (secret !== expectedSecret) {
      return res.status(403).json({ error: 'Unauthorized' });
    }
    try {
      const result = await generateBlogPosts();
      res.json({ success: true, ...result });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
