/**
 * GovJobs & Yojna Info — analytics.js
 * Google Analytics 4 event tracking
 * Developed by Breakout Trade
 */

const GA_ID = 'G-YOUR_GA4_MEASUREMENT_ID';

// ─── Initialize GA4 ─────────────────────────────────────────
(function initGA4() {
  const script = document.createElement('script');
  script.async = true;
  script.src = `https://www.googletagmanager.com/gtag/js?id=${GA_ID}`;
  document.head.appendChild(script);

  window.dataLayer = window.dataLayer || [];
  function gtag() { dataLayer.push(arguments); }
  window.gtag = gtag;

  gtag('js', new Date());
  gtag('config', GA_ID, {
    page_title: document.title,
    page_location: window.location.href,
    send_page_view: true
  });
})();

// ─── Track Card Expand ──────────────────────────────────────
document.addEventListener('click', (e) => {
  const card = e.target.closest('.feed-card');
  if (card) {
    const title = card.querySelector('.feed-card-title')?.textContent?.trim();
    const type = card.classList.contains('type-yojana') ? 'yojana'
                : card.classList.contains('type-news') ? 'news' : 'job';
    if (title && typeof gtag !== 'undefined') {
      gtag('event', 'card_expanded', { title, type });
    }
  }
});

// ─── Track Scroll Depth ─────────────────────────────────────
(function trackScroll() {
  const thresholds = [25, 50, 75, 90];
  const fired = new Set();

  window.addEventListener('scroll', () => {
    const scrollPct = Math.round(
      (window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100
    );
    thresholds.forEach(t => {
      if (scrollPct >= t && !fired.has(t)) {
        fired.add(t);
        if (typeof gtag !== 'undefined') {
          gtag('event', 'scroll_depth', { percent: t });
        }
      }
    });
  }, { passive: true });
})();

// ─── Track Time on Page ─────────────────────────────────────
(function trackTimeOnPage() {
  const startTime = Date.now();
  window.addEventListener('beforeunload', () => {
    const seconds = Math.round((Date.now() - startTime) / 1000);
    if (typeof gtag !== 'undefined') {
      gtag('event', 'time_on_page', { seconds });
    }
  });
})();
