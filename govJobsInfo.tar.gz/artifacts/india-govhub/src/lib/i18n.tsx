import { createContext, useContext, useState, ReactNode } from "react";

export type Language = "en" | "hi" | "mr" | "ta" | "te";

export const languages: { code: Language; label: string; native: string }[] = [
  { code: "en", label: "English", native: "English" },
  { code: "hi", label: "Hindi", native: "हिंदी" },
  { code: "mr", label: "Marathi", native: "मराठी" },
  { code: "ta", label: "Tamil", native: "தமிழ்" },
  { code: "te", label: "Telugu", native: "తెలుగు" },
];

type Translations = {
  siteTitle: string;
  siteTagline: string;
  heroTitle1: string;
  heroTitle2: string;
  heroSubtitle: string;
  latestGovtJobs: string;
  pmKisanYojana: string;
  govtJobs: string;
  kisanYojana: string;
  schemes: string;
  blogs: string;
  tools: string;
  home: string;
  totalJobs: string;
  totalSchemes: string;
  newJobsToday: string;
  newSchemes: string;
  trendingNow: string;
  latestJobs: string;
  pmKisanSchemes: string;
  newsUpdates: string;
  viewAll: string;
  applyNow: string;
  lastDate: string;
  salary: string;
  posts: string;
  advertisement: string;
  disclaimer: string;
  disclaimerText: string;
  allRightsReserved: string;
  quickLinks: string;
  popularCategories: string;
  sscJobs: string;
  railwayJobs: string;
  bankJobs: string;
  calculatorsTools: string;
};

const translations: Record<Language, Translations> = {
  en: {
    siteTitle: "govJobsInfo",
    siteTagline: "India's Most Trusted Portal for Govt Jobs & Kisan Schemes",
    heroTitle1: "All Government Jobs",
    heroTitle2: "& Schemes of India",
    heroSubtitle: "India's Most Trusted Portal for Govt Jobs & Kisan Schemes",
    latestGovtJobs: "Latest Govt Jobs",
    pmKisanYojana: "PM Kisan Yojana",
    govtJobs: "Govt Jobs",
    kisanYojana: "Kisan Yojana",
    schemes: "Schemes",
    blogs: "Blogs",
    tools: "Tools",
    home: "Home",
    totalJobs: "Total Jobs",
    totalSchemes: "Total Schemes",
    newJobsToday: "New Jobs Today",
    newSchemes: "New Schemes",
    trendingNow: "Trending Now",
    latestJobs: "Latest Govt Jobs",
    pmKisanSchemes: "PM Kisan & Schemes",
    newsUpdates: "News & Updates",
    viewAll: "View All",
    applyNow: "Apply Now",
    lastDate: "Last Date",
    salary: "Salary",
    posts: "Posts",
    advertisement: "Advertisement",
    disclaimer: "Disclaimer",
    disclaimerText:
      "govJobsInfo is an informational portal aggregating publicly available data about government jobs and schemes. We are NOT affiliated with the Government of India or any State Government. Always verify information on official government websites (.gov.in / .nic.in).",
    allRightsReserved: "All rights reserved.",
    quickLinks: "Quick Links",
    popularCategories: "Popular Categories",
    sscJobs: "SSC Jobs",
    railwayJobs: "Railway Jobs",
    bankJobs: "Bank Jobs",
    calculatorsTools: "Calculators & Tools",
  },
  hi: {
    siteTitle: "govJobsInfo",
    siteTagline: "सरकारी नौकरी और किसान योजनाओं का सबसे भरोसेमंद पोर्टल",
    heroTitle1: "भारत सरकार की सभी",
    heroTitle2: "नौकरियां और योजनाएं",
    heroSubtitle: "सरकारी नौकरी और किसान योजनाओं का सबसे भरोसेमंद पोर्टल",
    latestGovtJobs: "ताजा सरकारी नौकरियां",
    pmKisanYojana: "पीएम किसान योजना",
    govtJobs: "सरकारी नौकरी",
    kisanYojana: "किसान योजना",
    schemes: "योजनाएं",
    blogs: "ब्लॉग",
    tools: "टूल्स",
    home: "होम",
    totalJobs: "कुल नौकरियां",
    totalSchemes: "कुल योजनाएं",
    newJobsToday: "आज की नई नौकरियां",
    newSchemes: "नई योजनाएं",
    trendingNow: "ट्रेंडिंग",
    latestJobs: "ताजा सरकारी नौकरियां",
    pmKisanSchemes: "पीएम किसान और योजनाएं",
    newsUpdates: "समाचार और अपडेट",
    viewAll: "सभी देखें",
    applyNow: "अभी आवेदन करें",
    lastDate: "अंतिम तारीख",
    salary: "वेतन",
    posts: "पद",
    advertisement: "विज्ञापन",
    disclaimer: "अस्वीकरण",
    disclaimerText:
      "govJobsInfo एक सूचनात्मक पोर्टल है जो सार्वजनिक रूप से उपलब्ध सरकारी नौकरियों और योजनाओं की जानकारी एकत्र करता है। हम भारत सरकार या किसी राज्य सरकार से संबद्ध नहीं हैं। कृपया आधिकारिक सरकारी वेबसाइट (.gov.in / .nic.in) पर जाकर जानकारी सत्यापित करें।",
    allRightsReserved: "सर्वाधिकार सुरक्षित।",
    quickLinks: "त्वरित लिंक",
    popularCategories: "लोकप्रिय श्रेणियां",
    sscJobs: "एसएससी नौकरियां",
    railwayJobs: "रेलवे नौकरियां",
    bankJobs: "बैंक नौकरियां",
    calculatorsTools: "कैलकुलेटर और टूल्स",
  },
  mr: {
    siteTitle: "govJobsInfo",
    siteTagline: "सरकारी नोकऱ्या आणि किसान योजनांचे सर्वात विश्वसनीय पोर्टल",
    heroTitle1: "भारत सरकारच्या सर्व",
    heroTitle2: "नोकऱ्या आणि योजना",
    heroSubtitle: "सरकारी नोकऱ्या आणि किसान योजनांचे सर्वात विश्वसनीय पोर्टल",
    latestGovtJobs: "ताज्या सरकारी नोकऱ्या",
    pmKisanYojana: "पीएम किसान योजना",
    govtJobs: "सरकारी नोकरी",
    kisanYojana: "किसान योजना",
    schemes: "योजना",
    blogs: "ब्लॉग",
    tools: "साधने",
    home: "मुखपृष्ठ",
    totalJobs: "एकूण नोकऱ्या",
    totalSchemes: "एकूण योजना",
    newJobsToday: "आजच्या नव्या नोकऱ्या",
    newSchemes: "नव्या योजना",
    trendingNow: "ट्रेंडिंग",
    latestJobs: "ताज्या सरकारी नोकऱ्या",
    pmKisanSchemes: "पीएम किसान आणि योजना",
    newsUpdates: "बातम्या आणि अपडेट",
    viewAll: "सर्व पहा",
    applyNow: "आता अर्ज करा",
    lastDate: "शेवटची तारीख",
    salary: "पगार",
    posts: "पदे",
    advertisement: "जाहिरात",
    disclaimer: "अस्वीकरण",
    disclaimerText:
      "govJobsInfo हे एक माहितीपूर्ण पोर्टल आहे. आम्ही भारत सरकारशी संबंधित नाही. अधिकृत सरकारी वेबसाइटवर माहिती तपासा.",
    allRightsReserved: "सर्व हक्क राखीव.",
    quickLinks: "त्वरित दुवे",
    popularCategories: "लोकप्रिय श्रेणी",
    sscJobs: "एसएससी नोकऱ्या",
    railwayJobs: "रेल्वे नोकऱ्या",
    bankJobs: "बँक नोकऱ्या",
    calculatorsTools: "कॅल्क्युलेटर आणि साधने",
  },
  ta: {
    siteTitle: "govJobsInfo",
    siteTagline: "அரசு வேலைகள் மற்றும் கிசான் திட்டங்களுக்கான நம்பகமான தளம்",
    heroTitle1: "இந்திய அரசின் அனைத்து",
    heroTitle2: "வேலைகள் மற்றும் திட்டங்கள்",
    heroSubtitle: "அரசு வேலைகள் மற்றும் கிசான் திட்டங்களுக்கான நம்பகமான தளம்",
    latestGovtJobs: "புதிய அரசு வேலைகள்",
    pmKisanYojana: "பிஎம் கிசான் திட்டம்",
    govtJobs: "அரசு வேலை",
    kisanYojana: "கிசான் திட்டம்",
    schemes: "திட்டங்கள்",
    blogs: "வலைப்பதிவு",
    tools: "கருவிகள்",
    home: "முகப்பு",
    totalJobs: "மொத்த வேலைகள்",
    totalSchemes: "மொத்த திட்டங்கள்",
    newJobsToday: "இன்றைய புதிய வேலைகள்",
    newSchemes: "புதிய திட்டங்கள்",
    trendingNow: "டிரெண்டிங்",
    latestJobs: "புதிய அரசு வேலைகள்",
    pmKisanSchemes: "பிஎம் கிசான் திட்டங்கள்",
    newsUpdates: "செய்திகள் & புதுப்பிப்புகள்",
    viewAll: "அனைத்தும் பார்க்க",
    applyNow: "இப்போது விண்ணப்பிக்கவும்",
    lastDate: "கடைசி தேதி",
    salary: "சம்பளம்",
    posts: "பதவிகள்",
    advertisement: "விளம்பரம்",
    disclaimer: "மறுப்பு",
    disclaimerText:
      "govJobsInfo ஒரு தகவல் தளம். நாங்கள் இந்திய அரசாங்கத்துடன் தொடர்புடையவர்கள் அல்ல. உத்தியோகபூர்வ அரசு இணையதளங்களில் தகவலை சரிபார்க்கவும்.",
    allRightsReserved: "அனைத்து உரிமைகளும் பாதுகாக்கப்பட்டவை.",
    quickLinks: "விரைவு இணைப்புகள்",
    popularCategories: "பிரபலமான வகைகள்",
    sscJobs: "எஸ்எஸ்சி வேலைகள்",
    railwayJobs: "ரயில்வே வேலைகள்",
    bankJobs: "வங்கி வேலைகள்",
    calculatorsTools: "கணிப்பான்கள் & கருவிகள்",
  },
  te: {
    siteTitle: "govJobsInfo",
    siteTagline: "ప్రభుత్వ ఉద్యోగాలు మరియు కిసాన్ పథకాల నమ్మకమైన పోర్టల్",
    heroTitle1: "భారత ప్రభుత్వంలోని",
    heroTitle2: "ఉద్యోగాలు & పథకాలు",
    heroSubtitle: "ప్రభుత్వ ఉద్యోగాలు మరియు కిసాన్ పథకాల నమ్మకమైన పోర్టల్",
    latestGovtJobs: "తాజా ప్రభుత్వ ఉద్యోగాలు",
    pmKisanYojana: "పిఎం కిసాన్ యోజన",
    govtJobs: "ప్రభుత్వ ఉద్యోగం",
    kisanYojana: "కిసాన్ యోజన",
    schemes: "పథకాలు",
    blogs: "బ్లాగులు",
    tools: "సాధనాలు",
    home: "హోమ్",
    totalJobs: "మొత్తం ఉద్యోగాలు",
    totalSchemes: "మొత్తం పథకాలు",
    newJobsToday: "నేటి కొత్త ఉద్యోగాలు",
    newSchemes: "కొత్త పథకాలు",
    trendingNow: "ట్రెండింగ్",
    latestJobs: "తాజా ప్రభుత్వ ఉద్యోగాలు",
    pmKisanSchemes: "పిఎం కిసాన్ & పథకాలు",
    newsUpdates: "వార్తలు & నవీకరణలు",
    viewAll: "అన్నీ చూడండి",
    applyNow: "ఇప్పుడు దరఖాస్తు చేయండి",
    lastDate: "చివరి తేదీ",
    salary: "జీతం",
    posts: "పోస్టులు",
    advertisement: "ప్రకటన",
    disclaimer: "నిరాకరణ",
    disclaimerText:
      "govJobsInfo ఒక సమాచార పోర్టల్. మేము భారత ప్రభుత్వంతో అనుబంధం లేదు. అధికారిక ప్రభుత్వ వెబ్‌సైట్‌లలో సమాచారాన్ని ధృవీకరించండి.",
    allRightsReserved: "అన్ని హక్కులూ రక్షించబడ్డాయి.",
    quickLinks: "త్వరిత లింకులు",
    popularCategories: "ప్రసిద్ధ వర్గాలు",
    sscJobs: "ఎస్ఎస్సి ఉద్యోగాలు",
    railwayJobs: "రైల్వే ఉద్యోగాలు",
    bankJobs: "బ్యాంక్ ఉద్యోగాలు",
    calculatorsTools: "కాల్క్యులేటర్లు & సాధనాలు",
  },
};

interface I18nContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: Translations;
}

const I18nContext = createContext<I18nContextType | null>(null);

export function I18nProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>(() => {
    const stored = localStorage.getItem("govJobsInfo_lang");
    return (stored as Language) || "en";
  });

  const handleSetLanguage = (lang: Language) => {
    setLanguage(lang);
    localStorage.setItem("govJobsInfo_lang", lang);
  };

  return (
    <I18nContext.Provider value={{ language, setLanguage: handleSetLanguage, t: translations[language] }}>
      {children}
    </I18nContext.Provider>
  );
}

export function useI18n() {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error("useI18n must be used within I18nProvider");
  return ctx;
}
