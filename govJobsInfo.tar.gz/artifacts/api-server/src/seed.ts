import { db } from "@workspace/db";
import { jobsTable, schemesTable, blogsTable } from "@workspace/db";

const jobs = [
  {
    title: "🔥 SSC CGL 2026 – Apply Now (17000+ Posts)",
    organization: "Staff Selection Commission",
    category: "ssc",
    state: "All India",
    totalPosts: 17727,
    salary: "₹25,500 – ₹1,51,100/month",
    lastDate: "2026-05-30",
    qualifications: "Graduate from recognized university",
    content: `The Staff Selection Commission Combined Graduate Level (SSC CGL) 2026 is one of India's most prestigious government examinations, recruiting for over 17,000 posts across various central government ministries and departments.

## Eligibility Criteria
- Age: 18 to 32 years (relaxation for SC/ST/OBC as per rules)
- Educational Qualification: Graduate in any discipline from a recognized university
- Nationality: Indian citizen

## Post Details
SSC CGL 2026 recruits for posts like:
- Group B (Non-Gazetted): Inspector, Sub-Inspector, Auditor, Accountant
- Group C: LDC (Lower Division Clerk), JSA (Junior Secretariat Assistant), Data Entry Operator (DEO)

## Selection Process
1. Tier 1: Computer Based Test (CBT) – 100 marks, 60 minutes
2. Tier 2: CBT – Papers in Math, English, Statistics, General Studies
3. Skill Test/Document Verification (for specific posts)

## Step-by-Step Application Guide
1. Visit the official SSC website: ssc.gov.in
2. Register with your email and mobile number
3. Fill in personal and educational details
4. Upload photo and signature
5. Pay the application fee (₹100 for General; free for SC/ST/Female candidates)
6. Download and print the application form

## Documents Required
- Class 10 certificate (for DOB proof)
- Graduation degree/marksheet
- Caste certificate (if applicable)
- PWD certificate (if applicable)

## Salary & Benefits
- Pay Level 4–8 (₹25,500–1,51,100/month)
- Grade Pay varies by post
- DA, HRA, Transport Allowance, and other perks

## Important Dates
| Event | Date |
|-------|------|
| Notification Release | January 2026 |
| Application Start | February 2026 |
| Last Date to Apply | May 30, 2026 |
| Tier-1 Exam | August 2026 |

## FAQ

**Q: Can final year students apply for SSC CGL 2026?**
A: No, you must have completed graduation to apply.

**Q: How many attempts are allowed for SSC CGL?**
A: There is no restriction on the number of attempts until the age limit.

**Q: Is there negative marking in SSC CGL?**
A: Yes, 0.5 marks are deducted for each wrong answer in Tier-1 and Tier-2.

**Q: What is the salary of an Inspector in SSC CGL?**
A: An Inspector (Central Excise/Income Tax) gets approximately ₹44,900–₹1,42,400/month.

**Q: Can I apply for SSC CGL from any state?**
A: Yes, SSC CGL is a national-level exam and candidates from all states can apply.`,
    applyUrl: "https://ssc.gov.in",
    isTrending: true,
    isNew: true,
  },
  {
    title: "🚂 Railway Group D 2026 – 1 Lakh Vacancies! Apply Online",
    organization: "Railway Recruitment Boards (RRB)",
    category: "railway",
    state: "All India",
    totalPosts: 103769,
    salary: "₹18,000 – ₹56,900/month",
    lastDate: "2026-06-15",
    qualifications: "10th Pass (Matriculation) + ITI/Trade Certificate",
    content: `Railway Recruitment Board (RRB) Group D 2026 is one of the biggest employment opportunities in India with over 1 lakh vacancies. This exam recruits for Level 1 posts in various departments of Indian Railways.

## Eligibility Criteria
- Age: 18 to 33 years (relaxation for reserved categories)
- Qualification: 10th pass + ITI certificate OR NCVT/SCVT National Apprenticeship Certificate

## Post Details
- Track Maintainer (Grade IV)
- Helper/Assistant in Engineering, Signal & Telecommunication, Electrical, Medical
- Porter
- Pointsman

## Selection Process
1. Computer Based Test (CBT)
2. Physical Efficiency Test (PET)
3. Document Verification & Medical Examination

## Step-by-Step Application Guide
1. Visit RRBs official websites (rrbcdg.gov.in, rrbmumbai.gov.in, etc.)
2. Register as a new candidate
3. Fill the application form carefully
4. Upload required documents (photo & signature)
5. Pay the application fee (₹500 for General; ₹250 for others – refundable on exam appearance)

## Documents Required
- 10th Marksheet and Certificate
- ITI/NAC Certificate
- Caste/Category Certificate
- Aadhaar Card / PAN Card

## Salary & Benefits
- Pay Level 1: ₹18,000–₹56,900/month
- HRA, Transport Allowance, Medical facilities
- Free railway passes for self and family
- Job security and pension

## Important Dates
| Event | Date |
|-------|------|
| Application Start | March 2026 |
| Last Date | June 15, 2026 |
| Exam Date | September–October 2026 |

## FAQ

**Q: Is ITI mandatory for RRB Group D?**
A: Yes, 10th pass + ITI is required OR National Apprenticeship Certificate.

**Q: What is the physical test in RRB Group D?**
A: Males: Should be able to lift and carry 35 kg for 100 meters in 2 minutes. Females: Carry 20 kg for 100 meters in 2 minutes.

**Q: How many times can I apply for RRB Group D?**
A: Until the age limit (33 years for General category).

**Q: Will there be an interview for RRB Group D?**
A: No, there is no interview. Selection is based on CBT + PET + Medical.`,
    applyUrl: "https://indianrailways.gov.in",
    isTrending: true,
    isNew: true,
  },
  {
    title: "🏦 Bank PO Recruitment 2026 – IBPS PO 5000+ Vacancies",
    organization: "IBPS (Institute of Banking Personnel Selection)",
    category: "bank",
    state: "All India",
    totalPosts: 5367,
    salary: "₹52,000 – ₹1,15,000/month (CTC)",
    lastDate: "2026-07-20",
    qualifications: "Any Graduate (minimum 60% marks)",
    content: `IBPS PO (Probationary Officer) 2026 notification for over 5000 vacancies across public sector banks. This is one of the most sought-after banking jobs in India.

## Eligibility Criteria
- Age: 20 to 30 years
- Qualification: Graduate in any discipline (minimum 60% aggregate for General; 55% for SC/ST/PWD)
- Computer literacy is mandatory

## Participating Banks
- Bank of Baroda, Bank of India, Bank of Maharashtra
- Canara Bank, Central Bank of India
- Indian Bank, Indian Overseas Bank
- Punjab National Bank, UCO Bank, Union Bank of India

## Selection Process
1. Preliminary Exam (Prelims): 100 marks, 1 hour
2. Main Exam (Mains): 200 marks + Descriptive Test
3. Interview: 100 marks
4. Document Verification

## Step-by-Step Application Guide
1. Go to ibps.in
2. Click on "CRP-PO/MT" notification
3. Register with email and phone
4. Fill application, upload photo and signature
5. Pay fee: ₹850 (General/EWS/OBC), ₹175 (SC/ST/PWD)

## Salary & Benefits
- Basic Pay: ₹36,000/month
- DA, HRA, CCA, Medical: ~₹52,000–₹55,000 per month
- CTC approximately ₹12–14 LPA
- Promotion opportunities to Manager, Senior Manager, Chief Manager

## FAQ

**Q: What is the minimum percentage for IBPS PO?**
A: 60% for General/EWS/OBC and 55% for SC/ST/PWD candidates.

**Q: Can a final year student apply for IBPS PO?**
A: Yes, final year students can apply provisionally.

**Q: Is there a negative marking in IBPS PO?**
A: Yes, 0.25 marks per wrong answer in Prelims and Mains.`,
    applyUrl: "https://ibps.in",
    isTrending: true,
    isNew: false,
  },
  {
    title: "📋 10th Pass Govt Jobs 2026 – 50,000+ New Vacancies",
    organization: "Various Government Departments",
    category: "10th-pass",
    state: "All India",
    totalPosts: 50000,
    salary: "₹18,000 – ₹35,000/month",
    lastDate: "2026-08-31",
    qualifications: "10th Pass (Matriculation)",
    content: `Thousands of government jobs are available for 10th pass candidates in 2026. From railways to defense to state police, here's everything you need to know about 10th pass government job opportunities.

## Top 10th Pass Govt Jobs in 2026

### 1. RRB Group D (Indian Railways)
- Posts: Track Maintainer, Helper, Porter
- Salary: ₹18,000+
- Qualification: 10th + ITI

### 2. Multi-Tasking Staff (MTS) – SSC
- Posts: Office helper, Peon, Watchman
- Salary: ₹18,000–₹25,000
- Qualification: 10th pass

### 3. Army Soldier GD
- Posts: Soldier General Duty
- Salary: ₹21,700+
- Qualification: 10th with 45% marks

### 4. Police Constable
- Posts: Various state police departments
- Salary: ₹20,000–₹35,000
- Qualification: 10th/12th pass

### 5. CISF, BSF, CRPF Constable
- Posts: Constable GD, Tradesman
- Salary: ₹21,700+
- Qualification: 10th pass

## How to Apply
Each organization has its own recruitment portal. The key steps are:
1. Visit the official recruitment website
2. Check notification for eligibility
3. Register and fill application form
4. Upload documents and pay fee
5. Download admit card when released

## FAQ

**Q: What government jobs are available for 10th pass in 2026?**
A: RRB Group D, SSC MTS, Army Soldier GD, Police Constable, and Central/State government peon roles.

**Q: What is the salary for 10th pass government jobs?**
A: Salary ranges from ₹18,000 to ₹35,000 per month depending on the post and organization.`,
    applyUrl: "#",
    isTrending: false,
    isNew: true,
  },
  {
    title: "🎓 Graduate Govt Jobs 2026 – Best Opportunities for Graduates",
    organization: "Central Government",
    category: "graduate",
    state: "All India",
    totalPosts: 35000,
    salary: "₹25,000 – ₹1,42,400/month",
    lastDate: "2026-09-30",
    qualifications: "Any Graduate",
    content: `Graduate government jobs are among the most prestigious and secure career paths in India. In 2026, thousands of opportunities are available across banking, railways, civil services, defense, and more.

## Top Graduate Govt Jobs 2026

### 1. SSC CGL (Combined Graduate Level)
- Posts: Inspector, Auditor, Tax Assistant, JSA
- Salary: ₹25,500–₹1,51,100
- Exam: Tier 1, Tier 2, Skill Test

### 2. UPSC Civil Services
- Posts: IAS, IPS, IFS, and 24 other services
- Salary: ₹56,100–₹2,50,000
- One of India's most prestigious exams

### 3. IBPS PO/Clerk
- Posts: Probationary Officer, Clerk
- Salary: ₹52,000–₹1,15,000 CTC
- Multiple public sector banks

### 4. IBPS RRB Officer
- Posts: Officer Scale I, II, III
- Salary: ₹45,000–₹75,000
- Regional Rural Banks

### 5. SBI PO
- Posts: Probationary Officer at State Bank of India
- Salary: ₹55,000+ per month
- Most prestigious banking job

## How to Prepare
- Make a study schedule
- Focus on reasoning, quantitative aptitude, and English
- Practice previous year papers
- Join coaching or online courses if needed

## FAQ

**Q: What is the best government job for graduates in India?**
A: UPSC Civil Services (IAS/IPS) is considered the most prestigious, but SSC CGL and IBPS PO are excellent options with good salaries.`,
    applyUrl: "#",
    isTrending: false,
    isNew: true,
  },
  {
    title: "🏛️ Maharashtra Govt Jobs 2026 – State PSC & Department Recruitment",
    organization: "Maharashtra Public Service Commission (MPSC)",
    category: "state",
    state: "Maharashtra",
    totalPosts: 8000,
    salary: "₹25,500 – ₹1,00,000/month",
    lastDate: "2026-07-15",
    qualifications: "Graduates/Post Graduates",
    content: `Maharashtra government jobs in 2026 offer exciting opportunities across various departments including MPSC State Services, Police, Teachers, and more.

## Key Recruitments

### MPSC State Services Exam
- Posts: Deputy Collector, DSP, Tax Inspector, Naib Tehsildar
- Salary: ₹41,800–₹1,32,300/month

### Maharashtra Police Recruitment
- Constable, Sub-Inspector positions
- Salary: ₹20,200–₹68,000/month

### Zilla Parishad / Local Body
- Various posts at district level
- Salary: ₹18,000–₹48,000/month

## How to Apply (MPSC)
1. Register at mpsconline.gov.in
2. Create a profile with educational details
3. Apply for specific exam notifications
4. Pay fee and download challan if applicable

## FAQ

**Q: Is Marathi language knowledge required for Maharashtra govt jobs?**
A: Yes, proficiency in Marathi is mandatory for most Maharashtra state government positions.

**Q: What is the age limit for MPSC State Services?**
A: 19 to 38 years for General; relaxation of 5 years for SC/ST/OBC candidates.`,
    applyUrl: "https://mpsconline.gov.in",
    isTrending: false,
    isNew: true,
  },
  {
    title: "🏛️ UP Govt Jobs 2026 – UPPSC, Police, Teacher & More",
    organization: "Uttar Pradesh Public Service Commission",
    category: "state",
    state: "Uttar Pradesh",
    totalPosts: 15000,
    salary: "₹25,500 – ₹1,42,400/month",
    lastDate: "2026-08-30",
    qualifications: "10th Pass to Post Graduate",
    content: `Uttar Pradesh government jobs in 2026 span a wide range of departments and organizations. UP being the most populous state in India, offers thousands of job opportunities every year.

## Key Recruitments in UP 2026

### UPPSC PCS (Provincial Civil Services)
- Posts: SDM, DSP, BDO, and more
- Salary: ₹56,100–₹1,32,000/month
- Application: uppsc.up.nic.in

### UP Police Recruitment
- Constable, Sub-Inspector posts
- 50,000+ vacancies expected
- Salary: ₹21,700–₹60,000/month

### UP TGT/PGT Teacher Recruitment
- Secondary and Senior Secondary teachers
- 10,000+ posts
- Salary: ₹44,900–₹1,42,400/month

### UP Lekhpal (Revenue Department)
- Lekhpal for village record keeping
- Salary: ₹20,200–₹64,000/month

## How to Apply
- UPPSC: uppsc.up.nic.in
- UP Police: uppbpb.gov.in
- UP Basic Education: updeled.gov.in

## FAQ

**Q: What is the official website for UP government jobs?**
A: Key websites include uppsc.up.nic.in (UPPSC), uppbpb.gov.in (UP Police), and upsssc.gov.in (UPSSSC).`,
    applyUrl: "https://uppsc.up.nic.in",
    isTrending: true,
    isNew: true,
  },
];

const schemes = [
  {
    title: "🌾 PM Kisan Samman Nidhi Yojana 2026 – ₹6000/year Direct Benefit",
    ministry: "Ministry of Agriculture",
    category: "kisan",
    beneficiaries: "Small and marginal farmers",
    benefit: "₹6,000 per year in 3 installments of ₹2,000 each",
    content: `PM Kisan Samman Nidhi Yojana is one of India's biggest farmer welfare schemes providing direct income support of ₹6,000 annually to small and marginal farmers.

## About the Scheme
Launched in February 2019, PM-KISAN provides ₹6,000 per year to all farmer families having cultivable land up to 2 hectares. The amount is transferred in three equal installments of ₹2,000 each directly to the bank accounts of beneficiaries.

## Eligibility
- All farmer families (husband, wife, and minor children)
- Own and cultivate agricultural land
- Small/marginal farmers with up to 2 hectares of land (no upper limit since PM-KISAN revision)
- Should be Indian citizen

## Who Cannot Apply
- Former/current Constitutional post holders
- Current/former Ministers/MPs/MLAs
- Income Tax payers
- Persons with income above ₹10,000/month from non-agricultural sources

## How to Check PM Kisan Status
1. Visit pmkisan.gov.in
2. Click on "Farmers Corner" → "Beneficiary Status"
3. Enter Aadhaar Number or Account Number
4. Click "Get Data"

## Step-by-Step Registration Guide
1. Visit the PM-KISAN portal: pmkisan.gov.in
2. Click "New Farmer Registration" under Farmers Corner
3. Select Rural Farmer or Urban Farmer
4. Enter Aadhaar number and state
5. Fill in personal details, bank account information, and land details
6. Upload required documents
7. Submit application

## Documents Required
- Aadhaar Card
- Bank Account details (linked to Aadhaar)
- Land records/Khasra Khatauni
- Mobile number linked to Aadhaar

## Important Dates
| Event | Date |
|-------|------|
| 1st Installment (Apr–Jul) | April–July |
| 2nd Installment (Aug–Nov) | August–November |
| 3rd Installment (Dec–Mar) | December–March |

## PM Kisan eKYC
eKYC is now mandatory for PM-KISAN beneficiaries. Complete it via:
- OTP-based: pmkisan.gov.in
- Biometric: CSC centers

## FAQ

**Q: What is the PM Kisan installment amount?**
A: ₹2,000 per installment, paid 3 times a year for a total of ₹6,000 annually.

**Q: How do I check my PM Kisan status?**
A: Visit pmkisan.gov.in → Farmers Corner → Beneficiary Status → Enter Aadhaar/Account Number.

**Q: My name is not in PM Kisan list, what should I do?**
A: Contact your local Patwari or village Pradhan to verify your land records and complete eKYC.

**Q: Has the PM Kisan amount increased to ₹8000?**
A: No official announcement has been made. The current amount is ₹6,000 per year.

**Q: Can tenant farmers benefit from PM Kisan?**
A: No, only land-owning farmers are eligible. Sharecroppers/tenant farmers are not covered.`,
    applyUrl: "https://pmkisan.gov.in",
    isTrending: true,
    isNew: false,
  },
  {
    title: "🚜 PM Kisan Tractor Subsidy Scheme 2026 – 50% Subsidy on Tractors",
    ministry: "Ministry of Agriculture",
    category: "kisan",
    beneficiaries: "Farmers",
    benefit: "20%–50% subsidy on purchase of new tractors",
    content: `The PM Kisan Tractor Subsidy Scheme provides 20% to 50% subsidy to farmers for purchasing new tractors, helping mechanize farming and boost agricultural productivity.

## About the Scheme
Under this scheme, the government provides direct subsidy of 20%–50% on the purchase of new tractors. The subsidy amount is credited directly to the farmer's bank account after purchase.

## Eligibility Criteria
- Must be a farmer (own land or lease land)
- Should not have received tractor subsidy in the last 7 years
- One subsidy per family
- Bank account linked to Aadhaar

## Subsidy Amount by State
| State | Subsidy |
|-------|---------|
| Haryana | 25% |
| Punjab | 25% |
| Maharashtra | 40% |
| Bihar | 50% |
| UP | 25% |
| MP | 40–50% |

## How to Apply
1. Visit the Agriculture Department of your state
2. Apply through DBT Agriculture portal or state agriculture portal
3. Submit required documents
4. After approval, purchase from authorized dealer
5. Subsidy credited to bank account

## Documents Required
- Aadhaar Card
- Land ownership documents
- Bank passbook
- Passport size photo
- Mobile number

## FAQ

**Q: How much subsidy do I get on a tractor?**
A: 20%–50% depending on your state and category (SC/ST farmers may get higher subsidy).

**Q: Where do I apply for tractor subsidy?**
A: Through your state's Agriculture Department portal or DBT Agriculture portal (agri-input.gov.in).

**Q: How long does it take to get tractor subsidy?**
A: Typically 30–90 days after verification and approval.

**Q: Can I buy any brand of tractor under this scheme?**
A: You must purchase from government-approved dealers. Most major brands (Mahindra, TAFE, Sonalika, John Deere) are covered.`,
    applyUrl: "https://agri-input.gov.in",
    isTrending: false,
    isNew: true,
  },
  {
    title: "🌾 Pradhan Mantri Fasal Bima Yojana – Crop Insurance for Farmers",
    ministry: "Ministry of Agriculture",
    category: "kisan",
    beneficiaries: "Farmers with crop loans and voluntary applicants",
    benefit: "Full crop loss compensation; premium as low as 1.5% for Rabi crops",
    content: `Pradhan Mantri Fasal Bima Yojana (PMFBY) is a comprehensive crop insurance scheme that protects farmers against natural calamities, pests, and diseases.

## About the Scheme
PMFBY was launched in 2016 to replace older crop insurance schemes. It provides financial support to farmers in case of crop failure due to natural disasters, pests, or diseases. The premium is minimal for farmers while the government pays the remaining amount.

## Premium Rates
| Season | Crop Type | Farmer's Premium |
|--------|-----------|-----------------|
| Kharif | All crops | 2% of sum insured |
| Rabi | All crops | 1.5% of sum insured |
| Annual Commercial/Horticultural | All crops | 5% of sum insured |

## Eligible Farmers
- All farmers (loanee and non-loanee)
- Sharecroppers/tenant farmers are also eligible
- Applies to all states across India

## Risks Covered
- Natural disasters (flood, drought, hailstorm, cyclone)
- Pest and disease attacks
- Post-harvest losses up to 14 days
- Localized calamities
- Prevented sowing/planting risk

## How to Apply
1. Visit your bank or Common Service Center (CSC)
2. Apply online at pmfby.gov.in
3. Submit land details, crop details, and bank account information
4. Pay the premium amount
5. Receive policy certificate

## Claim Process
1. Report crop damage within 72 hours to bank/insurer
2. Crop cutting experiments conducted by state government
3. Claim assessed and processed
4. Amount credited directly to bank account

## FAQ

**Q: Is PMFBY mandatory for farmers with crop loans?**
A: From 2020, it is voluntary for all farmers including those with crop loans.

**Q: How much will I get if my entire crop is destroyed?**
A: You will receive 100% of the sum insured (based on crop area and average yield).

**Q: What documents are needed for PMFBY?**
A: Land records, bank account details, sowing certificate, and Aadhaar card.`,
    applyUrl: "https://pmfby.gov.in",
    isTrending: false,
    isNew: false,
  },
  {
    title: "💳 Kisan Credit Card Scheme 2026 – Low Interest Loan for Farmers",
    ministry: "Ministry of Agriculture",
    category: "kisan",
    beneficiaries: "All farmers, sharecroppers, tenant farmers",
    benefit: "Credit up to ₹3 lakh at just 4% interest per annum",
    content: `Kisan Credit Card (KCC) provides farmers with affordable credit for agricultural needs including crop cultivation, post-harvest expenses, and allied activities at a subsidized interest rate of 4% per annum.

## About the Scheme
Introduced in 1998, KCC provides farmers a credit limit based on their land holding and crop pattern. With interest subvention, the effective rate is only 4% per annum for loans up to ₹3 lakh.

## Credit Limit
- Based on land area and crop type
- Up to ₹3 lakh for crop production at 4% interest
- Higher amounts possible for allied activities

## Eligibility
- All farmers (owner cultivators, tenant farmers, sharecroppers)
- SHGs or Joint Liability Groups of farmers
- Fishermen and animal husbandry farmers are also eligible

## Uses of KCC
1. Purchase of seeds, fertilizers, pesticides
2. Post-harvest expenses
3. Produce marketing expenses
4. Consumption requirements
5. Maintenance of farm assets

## Interest Rate
- Interest rate: 7% per annum (normally)
- With government subvention: Effective rate 4% per annum
- For timely repayment: Additional 3% interest incentive (making it 4% effective)

## How to Apply
1. Visit your nearest bank branch (SBI, PNB, cooperative bank)
2. Fill KCC application form
3. Submit land documents and photograph
4. Bank assesses credit limit and issues KCC

## Documents Required
- Identity proof (Aadhaar)
- Address proof
- Land records (Khatauni/Khasra)
- Passport size photo

## FAQ

**Q: What is the interest rate on Kisan Credit Card?**
A: 4% effective rate per annum for loans up to ₹3 lakh with timely repayment.

**Q: Can I use KCC for buying farm equipment?**
A: Yes, KCC can be used for farm equipment, seeds, fertilizers, and other agricultural inputs.

**Q: What is the validity of Kisan Credit Card?**
A: KCC is valid for 5 years and renewed thereafter based on repayment record.`,
    applyUrl: "https://pmkisan.gov.in",
    isTrending: true,
    isNew: true,
  },
  {
    title: "👩 PM Mahila Shakti Yojana – Women Empowerment Schemes 2026",
    ministry: "Ministry of Women and Child Development",
    category: "women",
    beneficiaries: "Women across India",
    benefit: "Financial support, education, healthcare and skill development",
    content: `The Indian government runs multiple schemes for women empowerment under PM Mahila Shakti Yojana and related programs. These provide financial aid, education support, healthcare, and skill development opportunities.

## Key Women Schemes in 2026

### 1. Beti Bachao Beti Padhao
- Promotes education of girl children
- Financial incentive for girl births in select districts
- Awareness campaigns against sex-selective abortion

### 2. Pradhan Mantri Matru Vandana Yojana (PMMVY)
- ₹5,000 maternity benefit for first live birth
- Paid in 2 installments
- Eligible: Pregnant and lactating women above 19 years

### 3. Mahila Samridhi Yojana
- Self-help group (SHG) formation support
- Microfinance access at subsidized rates

### 4. PM Ujjwala Yojana
- Free LPG connection for BPL households
- Over 9 crore connections provided
- Saves women from indoor pollution

### 5. Sukanya Samridhi Yojana
- Savings scheme for girl children (up to age 10)
- Interest rate: 8.2% per annum
- Tax exemption under 80C

## How to Apply
Each scheme has a different application process:
- PMMVY: Via Anganwadi centers or health facilities
- Sukanya Samridhi: Post office or bank
- Ujjwala: LPG dealers

## FAQ

**Q: What is the benefit under Matru Vandana Yojana?**
A: ₹5,000 in two installments for the first live birth after complying with health conditions.

**Q: Can I open Sukanya Samridhi account for my daughter who is 8 years old?**
A: Yes, Sukanya Samridhi account can be opened for girls up to age 10.

**Q: Who is eligible for PM Ujjwala Yojana?**
A: Women from BPL households (below poverty line) who don't already have an LPG connection.`,
    applyUrl: "https://wcd.nic.in",
    isTrending: false,
    isNew: true,
  },
  {
    title: "📋 PM Yojana List 2026 – All Government Schemes in One Place",
    ministry: "Various Ministries",
    category: "general",
    beneficiaries: "All Indian citizens",
    benefit: "Access to 1000+ government schemes and benefits",
    content: `The Government of India runs over 1000 welfare schemes covering agriculture, health, education, housing, employment, and more. Here is a comprehensive list of key PM Yojana schemes in 2026.

## Agriculture & Farmer Schemes
| Scheme | Benefit |
|--------|---------|
| PM Kisan Samman Nidhi | ₹6,000/year to farmers |
| PM Fasal Bima Yojana | Crop insurance |
| Kisan Credit Card | 4% interest loans |
| Soil Health Card | Free soil testing |
| PM Sinchai Yojana | Irrigation support |

## Health Schemes
| Scheme | Benefit |
|--------|---------|
| PM Jan Arogya Yojana (Ayushman) | ₹5 lakh health cover/family |
| PM Matru Vandana Yojana | ₹5,000 maternity benefit |
| Janani Suraksha Yojana | Safe delivery support |

## Housing Schemes
| Scheme | Benefit |
|--------|---------|
| PM Awas Yojana (Urban) | Subsidy on home loans |
| PM Awas Yojana (Rural) | Free house for BPL |

## Employment & Skill Schemes
| Scheme | Benefit |
|--------|---------|
| PM Kaushal Vikas Yojana | Free skill training |
| MGNREGA | 100 days work guarantee |
| Startup India | Support for entrepreneurs |

## Education Schemes
| Scheme | Benefit |
|--------|---------|
| PM Scholarship Scheme | Scholarships for students |
| Sukanya Samridhi | Savings for girl children |
| Mid-Day Meal | Free meals in schools |

## How to Check Eligibility and Apply
1. Visit myscheme.gov.in – the official government schemes portal
2. Search schemes by category or use the eligibility wizard
3. Click on the scheme to see full details and apply

## FAQ

**Q: How many government schemes are there in India?**
A: The Government of India runs over 1000 central schemes. State governments have additional schemes.

**Q: Where can I find all government schemes in one place?**
A: Visit myscheme.gov.in – the official one-stop portal for all government schemes.

**Q: Are all government schemes free?**
A: Most welfare schemes are free or subsidized. Some require a small contribution.`,
    applyUrl: "https://myscheme.gov.in",
    isTrending: true,
    isNew: true,
  },
];

const blogs = [
  {
    title: "Top 10 Government Jobs in India for 2026 – Apply Now!",
    slug: "top-10-govt-jobs-india-2026",
    category: "jobs",
    excerpt: "Looking for the best government jobs in India? Here are the top 10 most sought-after govt job opportunities in 2026 with high salary and job security.",
    content: `Government jobs in India offer unmatched job security, salary, and benefits. With thousands of vacancies opening in 2026, now is the best time to prepare and apply.

## Why Government Jobs are Still the Best Career Choice in 2026

Despite the booming private sector, government jobs remain the first choice for millions of Indians due to:
- **Job Security**: No fear of layoffs or recession
- **Pension**: Government employees get pension after retirement
- **Benefits**: Medical, housing allowance, LTC, and more
- **Respect**: Social status associated with government jobs

## Top 10 Government Jobs in India for 2026

### 1. IAS/IPS (UPSC Civil Services)
- Salary: ₹56,100–₹2,50,000/month
- Prestige: Highest administrative position
- Exam: UPSC Civil Services (Prelims + Mains + Interview)

### 2. SSC CGL Posts (Inspector, Auditor)
- Salary: ₹35,400–₹1,12,400/month
- Posts: 17,000+ across India
- Exam: SSC CGL Tier 1, 2, Skill Test

### 3. IBPS PO (Bank PO)
- Salary: ₹52,000–₹1,15,000 CTC/month
- Posts: 5,000+ across public sector banks
- Exam: IBPS PO Prelims + Mains + Interview

### 4. Indian Railway Group B/C
- Salary: ₹35,400–₹1,12,400/month
- Posts: ALP, JE, Station Master positions
- Good perks including free travel passes

### 5. Army/Navy/Air Force Officer
- Salary: ₹56,100–₹2,12,400/month
- Prestigious career with accommodation and allowances
- Entry through NDA, CDS, or AFCAT exams

### 6. SBI PO
- Salary: ₹55,000+/month
- Most prestigious banking job in India
- SBI conducts its own exam separately from IBPS

### 7. RBI Grade B Officer
- Salary: ₹78,000+/month
- Works at India's central bank
- Highly competitive but very rewarding

### 8. EPFO SSA/Enforcement Officer
- Salary: ₹44,900–₹1,42,400/month
- Works with Employee Provident Fund Organization
- SSC conducts EPFO recruitment

### 9. State Civil Services (PCS/PSC)
- Salary: ₹40,000–₹1,00,000/month
- Posts: SDM, BDO, DSP, etc.
- State PSC conducts exams

### 10. Teaching Jobs (UGC NET/CTET)
- Salary: ₹44,900–₹1,51,100/month (college/school level)
- Job security, vacations, and prestige
- UGC NET for college; CTET/TET for school teachers

## How to Start Preparing

1. **Choose your target exam**: Focus on 1-2 exams at a time
2. **Understand the syllabus**: Download official syllabus from the organization's website
3. **Get good study material**: NCERT books are foundational
4. **Practice previous year papers**: Best way to understand exam pattern
5. **Time management**: Develop a realistic daily study plan
6. **Mock tests**: Take full-length mocks regularly

## FAQ

**Q: Which government job has the highest salary in India?**
A: Cabinet Secretary (IAS) draws the highest salary at ₹2,50,000/month, but starting salaries for IAS officers are ₹56,100.

**Q: Which is the easiest government job to get?**
A: SSC MTS and RRB Group D are considered relatively accessible with lower education requirements.

**Q: How many hours of study per day are required to clear govt exams?**
A: 6-8 hours of focused study daily is recommended, especially for UPSC. For SSC/Bank, 4-6 hours may suffice.`,
    author: "GovHub Team",
    tags: ["govt jobs", "government jobs 2026", "SSC CGL", "UPSC", "IBPS PO"],
    viewCount: 1520,
  },
  {
    title: "PM Kisan 19th Installment 2026 – Status Check, Date & Amount",
    slug: "pm-kisan-19th-installment-2026",
    category: "kisan",
    excerpt: "PM Kisan 19th installment is expected soon. Check your status, beneficiary list, and how to ensure you receive your ₹2,000 installment.",
    content: `PM Kisan Samman Nidhi Yojana 19th installment is highly anticipated by millions of farmers across India. Here is everything you need to know about the date, status, and how to check.

## PM Kisan 19th Installment – Key Details

| Detail | Information |
|--------|-------------|
| Installment | 19th |
| Expected Date | February–March 2026 |
| Amount | ₹2,000 |
| Transferred Via | Direct Bank Transfer (DBT) |
| Official Website | pmkisan.gov.in |

## How to Check PM Kisan 19th Installment Status

### Method 1: Online via Official Website
1. Visit pmkisan.gov.in
2. Click "Beneficiary Status" under Farmers Corner
3. Enter your Aadhaar Number, Account Number, or Mobile Number
4. Click "Get Data"
5. Your installment status will be displayed

### Method 2: Via PM Kisan Mobile App
1. Download "PM Kisan" app from Google Play Store
2. Enter your mobile number
3. Verify with OTP
4. Check installment status

### Method 3: Via Common Service Center (CSC)
Visit your nearest CSC or village-level Pragya Kendra to check status.

## Why Some Farmers Don't Receive Installments

Common reasons for missing PM Kisan installments:
1. **eKYC not completed** – eKYC is mandatory for all beneficiaries
2. **Incorrect bank details** – Wrong account number or IFSC code
3. **Aadhaar not linked to bank account** – Link immediately at your bank
4. **Name mismatch** – Name in land records vs Aadhaar is different
5. **Land records issues** – Ownership verification problems

## How to Complete PM Kisan eKYC

### OTP-Based eKYC (Online)
1. Visit pmkisan.gov.in
2. Click "eKYC" option
3. Enter Aadhaar number
4. Enter OTP received on Aadhaar-linked mobile

### Biometric eKYC (Offline)
Visit your nearest CSC center with Aadhaar card. The CSC operator will complete biometric verification.

## New Farmers Registration for PM Kisan

If you haven't registered yet:
1. Go to pmkisan.gov.in
2. Click "New Farmer Registration"
3. Select Rural/Urban Farmer
4. Enter Aadhaar Number
5. Fill in all required details
6. Upload land records
7. Submit and note the reference number

## FAQ

**Q: When is the PM Kisan 19th installment date?**
A: The 19th installment is expected between February-March 2026. The exact date will be announced officially.

**Q: I completed eKYC but still didn't receive the installment?**
A: Wait for 1-2 weeks after eKYC. If still not received, contact your block agriculture office.

**Q: How do I know if my name is in the PM Kisan beneficiary list?**
A: Check at pmkisan.gov.in under "Beneficiary Status" by entering your Aadhaar or bank account number.

**Q: Can both husband and wife get PM Kisan benefit?**
A: No. Only one member per family is eligible.`,
    author: "GovHub Team",
    tags: ["PM Kisan", "PM Kisan status", "19th installment", "farmers", "kisan yojana"],
    viewCount: 3240,
  },
  {
    title: "SSC CGL 2026 Complete Guide – Syllabus, Eligibility, Salary & Preparation",
    slug: "ssc-cgl-2026-complete-guide",
    category: "jobs",
    excerpt: "Complete guide to SSC CGL 2026 exam – everything from eligibility, syllabus, exam pattern, best books, salary details, and preparation strategy.",
    content: `SSC CGL 2026 is one of the most popular government exams in India. This complete guide covers everything you need to know to clear SSC CGL and secure a Group B/C government job.

## SSC CGL 2026 – Quick Overview

| Parameter | Details |
|-----------|---------|
| Conducting Body | Staff Selection Commission (SSC) |
| Exam Name | Combined Graduate Level Exam |
| Application Mode | Online |
| Exam Mode | Computer Based Test |
| Selection Rounds | Tier 1, Tier 2, Skill Test |
| Total Vacancies | 17,727 (2025-26) |

## SSC CGL 2026 Eligibility

### Age Limit
- Minimum: 18 years
- Maximum: 32 years (varies by post; 18-27 for some posts)
- SC/ST: 5 years relaxation
- OBC: 3 years relaxation
- PWD: 10 years relaxation

### Educational Qualification
- Bachelor's degree in any discipline from a recognized university

## SSC CGL 2026 Exam Pattern

### Tier 1 – Preliminary Exam
- Sections: General Intelligence, General Awareness, Quantitative Aptitude, English Comprehension
- Total Questions: 100
- Total Marks: 200
- Time: 60 minutes
- Negative Marking: 0.5 marks per wrong answer

### Tier 2 – Main Exam (CBT)
**Paper I (for all posts):**
- Session 1: Mathematical Abilities + Reasoning & General Intelligence (60+30 = 90 questions)
- Session 2: English Language, General Awareness, Computer Knowledge (45+25+20 = 90 questions)

**Paper II (for Statistics posts):**
- 100 questions, 200 marks

**Paper III (for Junior Statistical Officer):**
- General Studies (Finance & Economics)

## SSC CGL 2026 Syllabus

### General Intelligence & Reasoning
- Analogy, Classification, Series
- Coding-Decoding, Sitting Arrangement
- Logical Reasoning, Syllogism
- Non-verbal: figures, pattern completion

### Quantitative Aptitude
- Number System, LCM/HCF
- Percentage, Ratio, Average
- Profit/Loss, Simple/Compound Interest
- Time-Distance, Time-Work
- Geometry, Mensuration, Algebra
- Trigonometry, Statistics

### English Comprehension
- Vocabulary, Error Spotting
- Fill in the Blanks, Synonyms/Antonyms
- Reading Comprehension
- Para Jumbles, Idioms/Phrases

### General Awareness
- Current Affairs, History
- Geography, Polity, Economics
- Science: Physics, Chemistry, Biology

## Best Books for SSC CGL 2026

| Subject | Book | Author |
|---------|------|--------|
| Reasoning | A Modern Approach to Verbal & Non-Verbal Reasoning | R.S. Aggarwal |
| Math | Quantum CAT | Sarvesh K. Verma |
| English | SP Bakshi English | Arihant |
| GK | Lucent's General Knowledge | Dr. Binay Karna |

## Preparation Strategy

### 3-Month Plan
**Month 1**: Foundation
- Focus on basic concepts of all 4 subjects
- NCERT books for GK (History, Geography, Science)
- Complete at least one standard book per subject

**Month 2**: Practice
- Solve 50+ questions daily per subject
- Analyze weak areas and improve
- Start mock tests (2 per week)

**Month 3**: Revision + Mocks
- Revise all formulas and important concepts
- Take 1 full mock test every alternate day
- Focus on accuracy and time management

## FAQ

**Q: How many attempts does SSC CGL allow?**
A: No limit on attempts until the age limit is reached.

**Q: Is coaching necessary for SSC CGL?**
A: Not mandatory. Many candidates clear SSC CGL with self-study using good books and online resources.

**Q: What is the CGL cutoff for General category?**
A: Cutoffs vary by year and post, but typically 140-155 marks (Tier 1, out of 200) for General category.`,
    author: "GovHub Team",
    tags: ["SSC CGL 2026", "SSC CGL syllabus", "SSC CGL preparation", "government exam"],
    viewCount: 2190,
  },
  {
    title: "New Government Schemes Launched in 2026 – Benefits & How to Apply",
    slug: "new-government-schemes-2026",
    category: "schemes",
    excerpt: "Complete list of new government schemes launched in 2026 with benefits, eligibility, and step-by-step application process for each scheme.",
    content: `The Indian government has launched several new welfare schemes in 2026 targeting farmers, women, youth, and the poor. Here's a complete list with application details.

## Key New Schemes in 2026

### 1. PM Surya Ghar Muft Bijli Yojana
**Launch**: January 2024 (expanded in 2026)
**Benefit**: Free electricity up to 300 units/month via rooftop solar installation
**Eligible**: Residential households with roof space
**Application**: pmsuryaghar.gov.in

### 2. PM Vishwakarma Yojana
**Launch**: September 2023 (major expansion in 2026)
**Benefit**: 
- Free skill training
- Toolkit support up to ₹15,000
- Low-interest credit up to ₹3 lakh
**Eligible**: Traditional artisans and craftspeople (18 communities)
**Application**: pmvishwakarma.gov.in

### 3. PM JANMAN Scheme
**For**: Particularly Vulnerable Tribal Groups (PVTGs)
**Benefit**: Housing, clean water, sanitation, education support
**States**: 18 states with PVTG communities

### 4. PM E-Bus Sewa
**For**: Public transport in cities
**Benefit**: Electric buses replacing diesel buses
**Covers**: 169 cities, 10,000+ electric buses

### 5. Atal Vayo Abhyuday Yojana (AVYAY)
**For**: Senior citizens
**Benefit**: Integrated scheme for elder welfare including healthcare, shelters
**Agency**: Ministry of Social Justice

## Expanded Schemes in 2026

### PM Awas Yojana – 2026 Targets
- 3 crore additional rural houses
- Interest subsidy on home loans
- Application: pmayg.nic.in

### Ayushman Bharat – Expanded Coverage
- Extended to senior citizens above 70 years
- ₹5 lakh health cover per year
- Application: beneficiary.nha.gov.in

### PM Kisan – Drone Program
- Drones for crop monitoring and spraying
- Training for PM Kisan beneficiaries
- Reduces pesticide cost and increases yield

## How to Find All Schemes

The easiest way to find all government schemes is:
1. Visit **myscheme.gov.in** – official portal
2. Use the Eligibility Wizard to find schemes you qualify for
3. Apply directly from the portal

## FAQ

**Q: Which new schemes were launched in 2026?**
A: PM Surya Ghar Muft Bijli Yojana, PM Vishwakarma (expanded), and several state-level schemes are the major new schemes.

**Q: How do I apply for government schemes online?**
A: Visit myscheme.gov.in or the specific scheme's official portal. You'll need Aadhaar, bank account details, and relevant documents.

**Q: Is there any scheme for free solar panels?**
A: Yes, PM Surya Ghar Muft Bijli Yojana provides subsidy for rooftop solar installation and gives 300 units free electricity per month.`,
    author: "GovHub Team",
    tags: ["new schemes 2026", "government schemes", "PM Vishwakarma", "PM Surya Ghar"],
    viewCount: 1870,
  },
  {
    title: "RRB Railway Jobs 2026 – Complete Guide to All Railway Exams",
    slug: "rrb-railway-jobs-2026-complete-guide",
    category: "jobs",
    excerpt: "Complete guide to Railway recruitment 2026 – RRB Group D, NTPC, ALP, JE vacancies, eligibility, syllabus, and application process.",
    content: `Indian Railways is one of the world's largest employers. In 2026, over 1.5 lakh vacancies are expected across various RRB (Railway Recruitment Board) examinations.

## Types of Railway Jobs

### Group A (Officers)
- Indian Railway Service (through UPSC)
- IRS, IRAS, IRSS, IRPS, IRSEE

### Group B (Promoted from Group C)
- Senior Supervisor level posts
- Filled through departmental promotion

### Group C (Gazetted/Non-Gazetted)
- **RRB NTPC**: Station Master, Commercial Apprentice, Goods Guard, Clerk
- **RRB ALP**: Assistant Loco Pilot
- **RRB JE**: Junior Engineer
- **RRB NTPC Level 2-6**

### Group D
- **RRB Group D**: Track Maintainer, Helper, Porter, Pointsman

## Major RRB Exams in 2026

### 1. RRB Group D 2026
- Vacancies: 1,03,769
- Qualification: 10th + ITI
- Salary: Level 1 (₹18,000–₹56,900)

### 2. RRB NTPC 2026
- Vacancies: 35,000+
- Qualification: 12th Pass to Graduate
- Salary: Level 2-6 (₹19,900–₹47,600)

### 3. RRB ALP 2026
- Vacancies: 18,799
- Qualification: 10th + ITI/Diploma
- Salary: Level 2 (₹19,900–₹63,200)

### 4. RRB JE 2026
- Vacancies: 7,951
- Qualification: Diploma/Degree in Engineering
- Salary: Level 6 (₹35,400–₹1,12,400)

## Selection Process

For most RRB exams:
1. **CBT Stage 1**: Common test for all candidates
2. **CBT Stage 2**: Advanced test based on the applied post
3. **Skill Test/CBAT**: For certain posts
4. **Physical Efficiency Test**: For Group D and some others
5. **Document Verification + Medical**: Final stage

## Railway Job Benefits

- **Salary**: Competitive with DA and allowances
- **Free Travel**: Railway passes for self and family
- **Accommodation**: Railway quarters in many cities
- **Medical**: Free treatment in railway hospitals
- **Children's Education**: Railway schools with nominal fee
- **Pension**: Post-retirement security

## How to Apply for Railway Jobs
1. Visit the RRB zone's official website
2. Register with email and mobile number
3. Fill the application with education and personal details
4. Upload photo and signature
5. Pay the application fee
6. Download and keep the application number

## FAQ

**Q: What is the age limit for RRB Group D?**
A: 18–33 years for General (30–38 for SC/ST/OBC with relaxation).

**Q: Which RRB zone is best to choose for application?**
A: Choose the zone closest to your home state or where you want to be posted.

**Q: Is there a limit on how many RRB zones I can apply to?**
A: You can apply to only one RRB zone per exam.

**Q: What happens if I fail the PET in RRB Group D?**
A: Failing PET results in elimination from the selection process.`,
    author: "GovHub Team",
    tags: ["RRB 2026", "railway jobs", "RRB Group D", "RRB NTPC", "RRB ALP"],
    viewCount: 2540,
  },
];

async function seed() {
  console.log("Seeding database...");

  for (const job of jobs) {
    await db.insert(jobsTable).values(job).onConflictDoNothing();
  }
  console.log(`Seeded ${jobs.length} jobs`);

  for (const scheme of schemes) {
    await db.insert(schemesTable).values(scheme).onConflictDoNothing();
  }
  console.log(`Seeded ${schemes.length} schemes`);

  for (const blog of blogs) {
    await db.insert(blogsTable).values(blog).onConflictDoNothing();
  }
  console.log(`Seeded ${blogs.length} blogs`);

  console.log("Seeding complete!");
}

seed().catch(console.error);
