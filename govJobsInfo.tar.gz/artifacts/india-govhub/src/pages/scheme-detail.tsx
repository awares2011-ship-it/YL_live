import { useEffect } from "react";
import { Link, useParams } from "wouter";
import { useGetScheme, useListSchemes, getGetSchemeQueryKey } from "@workspace/api-client-react";
import { ContentRenderer } from "@/components/ContentRenderer";
import { Advertisement } from "@/components/Advertisement";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Landmark, Users2, IndianRupee, ExternalLink, Share2, CheckCircle2 } from "lucide-react";

export default function SchemeDetailPage() {
  const params = useParams();
  const id = parseInt(params.id || "0", 10);

  const { data: scheme, isLoading } = useGetScheme(id, {
    query: { enabled: !!id, queryKey: getGetSchemeQueryKey(id) }
  });

  const { data: relatedSchemes } = useListSchemes(
    { category: scheme?.category, limit: 3 },
    { query: { enabled: !!scheme?.category } }
  );

  useEffect(() => {
    if (scheme) {
      document.title = `${scheme.title} | govJobsInfo`;
    }
  }, [scheme]);

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        <Skeleton className="h-8 w-64 mb-4" />
        <Skeleton className="h-12 w-full max-w-3xl mb-8" />
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <Skeleton className="h-[200px] w-full" />
            <Skeleton className="h-[400px] w-full" />
          </div>
        </div>
      </div>
    );
  }

  if (!scheme) return <div className="text-center py-20 font-bold text-2xl">Scheme not found</div>;

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      {/* Breadcrumb */}
      <div className="flex items-center text-sm text-muted-foreground mb-6 overflow-x-auto whitespace-nowrap pb-2">
        <Link href="/" className="hover:text-secondary">Home</Link>
        <span className="mx-2 shrink-0">›</span>
        <Link href="/schemes" className="hover:text-secondary shrink-0">Govt Schemes</Link>
        <span className="mx-2 shrink-0">›</span>
        <span className="text-foreground font-medium truncate">{scheme.title}</span>
      </div>

      <Advertisement />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-6">
        {/* Main Content */}
        <div className="lg:col-span-2">
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-4 flex-wrap">
              <Badge className="bg-secondary hover:bg-secondary/90 border-secondary">{scheme.category}</Badge>
              {scheme.isTrending && <Badge variant="destructive">🔥 Trending</Badge>}
              {scheme.isNew && <Badge className="bg-secondary hover:bg-secondary/90">🆕 New</Badge>}
            </div>
            
            <h1 className="text-3xl md:text-4xl font-extrabold text-accent mb-4 leading-tight">
              {scheme.title}
            </h1>
            
            <div className="flex flex-col sm:flex-row gap-4 sm:items-center text-muted-foreground font-medium pb-6 border-b border-border">
              <div className="flex items-center">
                <Landmark className="w-5 h-5 mr-2 text-secondary" />
                {scheme.ministry}
              </div>
            </div>
          </div>

          {/* Quick Info Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
            <Card className="bg-secondary/5 border-secondary/20">
              <CardContent className="p-5 flex items-start gap-4">
                <div className="bg-secondary/10 p-3 rounded-full">
                  <Users2 className="w-6 h-6 text-secondary" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-muted-foreground uppercase tracking-wider mb-1">Beneficiaries</h3>
                  <p className="font-semibold text-foreground text-lg">{scheme.beneficiaries}</p>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-secondary/5 border-secondary/20">
              <CardContent className="p-5 flex items-start gap-4">
                <div className="bg-secondary/10 p-3 rounded-full">
                  <IndianRupee className="w-6 h-6 text-secondary" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-muted-foreground uppercase tracking-wider mb-1">Benefits</h3>
                  <p className="font-semibold text-foreground text-lg">{scheme.benefit}</p>
                </div>
              </CardContent>
            </Card>
          </div>

          <Advertisement />

          {/* Content */}
          <div className="mt-8 bg-white border border-border rounded-xl p-6 md:p-8 shadow-sm">
            <h2 className="text-2xl font-bold text-accent mb-6 border-b border-border pb-2">Scheme Details</h2>
            <ContentRenderer content={scheme.content} />
            
            <div className="mt-12 mb-8">
              <h2 className="text-2xl font-bold text-accent mb-6 border-b border-border pb-2">Frequently Asked Questions</h2>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="item-1">
                  <AccordionTrigger className="font-bold text-left">Who is eligible for this scheme?</AccordionTrigger>
                  <AccordionContent className="text-foreground/80 leading-relaxed">
                    The eligibility criteria are defined by the {scheme.ministry}. Generally, it targets {scheme.beneficiaries}. Please check the official notification for exact requirements.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-2">
                  <AccordionTrigger className="font-bold text-left">How to apply for {scheme.title}?</AccordionTrigger>
                  <AccordionContent className="text-foreground/80 leading-relaxed">
                    You can apply online through the official portal. Click the "Apply Online Now" button below to visit the official website and complete your registration.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-3">
                  <AccordionTrigger className="font-bold text-left">What are the documents required?</AccordionTrigger>
                  <AccordionContent className="text-foreground/80 leading-relaxed">
                    Commonly required documents include Aadhaar Card, Bank Account Details linked to Aadhaar, Income Certificate, and relevant category certificates.
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </div>
            
            <div className="mt-10 pt-8 border-t border-border flex flex-col items-center text-center bg-muted/30 p-8 rounded-xl">
              <CheckCircle2 className="w-12 h-12 text-secondary mb-4" />
              <h3 className="text-2xl font-bold mb-3">Claim Your Benefits</h3>
              <p className="text-muted-foreground mb-6 max-w-md mx-auto font-medium">Register on the official portal to check your name in the beneficiary list and claim benefits.</p>
              
              <Button size="lg" className="w-full sm:w-auto text-lg h-14 px-10 bg-secondary hover:bg-secondary/90 text-white" asChild>
                <a href={scheme.applyUrl || "#"} target="_blank" rel="noopener noreferrer">
                  Apply Online Now <ExternalLink className="ml-2 w-5 h-5" />
                </a>
              </Button>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          <Button variant="outline" className="w-full flex items-center justify-center border-secondary text-secondary hover:bg-secondary hover:text-white transition-colors h-12 font-bold text-base">
            <Share2 className="w-5 h-5 mr-2" /> Share Scheme
          </Button>

          <Advertisement />

          {/* Related Schemes */}
          {relatedSchemes && relatedSchemes.schemes.length > 0 && (
            <div className="bg-muted/30 p-4 rounded-xl border border-border">
              <h3 className="text-xl font-bold text-accent mb-4 border-l-4 border-secondary pl-3">Similar Schemes</h3>
              <div className="space-y-4">
                {relatedSchemes.schemes.filter(s => s.id !== scheme.id).slice(0, 4).map(relatedScheme => (
                  <Link key={relatedScheme.id} href={`/schemes/${relatedScheme.id}`}>
                    <Card className="hover-elevate cursor-pointer border-border hover:border-secondary/50 transition-colors bg-white">
                      <CardContent className="p-4">
                        <h4 className="font-bold text-sm text-foreground line-clamp-2 mb-2 group-hover:text-secondary">{relatedScheme.title}</h4>
                        <div className="text-xs text-muted-foreground line-clamp-1 font-medium">
                          {relatedScheme.benefit}
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
