import { Link } from "wouter";
import { useListJobs } from "@workspace/api-client-react";
import { Zap } from "lucide-react";

export function JobsTicker() {
  const { data: jobsData } = useListJobs({ limit: 20 });

  const jobs = jobsData?.jobs ?? [];

  if (jobs.length === 0) return null;

  const items = [...jobs, ...jobs];

  return (
    <div className="bg-accent text-accent-foreground border-b-2 border-primary overflow-hidden">
      <div className="flex items-stretch">
        <div className="flex items-center gap-2 bg-primary text-primary-foreground px-4 py-2 shrink-0 font-bold text-sm uppercase tracking-wide z-10">
          <Zap className="w-4 h-4" />
          <span className="hidden sm:inline">Latest Jobs</span>
          <span className="sm:hidden">Jobs</span>
        </div>
        <div className="flex-1 overflow-hidden relative">
          <div className="ticker-track py-2">
            {items.map((job, idx) => (
              <span key={`${job.id}-${idx}`} className="inline-flex items-center">
                <Link
                  href={`/jobs/${job.id}`}
                  className="text-sm font-semibold text-accent-foreground hover:text-primary transition-colors whitespace-nowrap px-1"
                >
                  {job.isTrending && <span className="mr-1">🔥</span>}
                  {job.isNew && <span className="mr-1">🆕</span>}
                  {job.title}
                  <span className="ml-1 text-primary font-bold">({job.totalPosts} Posts)</span>
                </Link>
                <span className="mx-4 text-primary/60 select-none">•</span>
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
