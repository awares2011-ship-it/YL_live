import { useState, useEffect } from "react";
import { Link } from "wouter";
import { useListBlogs } from "@workspace/api-client-react";
import { BlogCard } from "@/components/BlogCard";
import { Advertisement } from "@/components/Advertisement";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Newspaper, Filter } from "lucide-react";

const CATEGORIES = ["All", "Admit Card", "Result", "Syllabus", "Answer Key", "News"];

export default function BlogsPage() {
  useEffect(() => {
    document.title = "Govt Jobs & Scheme Updates - Latest News | govJobsInfo";
  }, []);

  const [category, setCategory] = useState("All");
  const [page, setPage] = useState(1);
  const limit = 12;
  const offset = (page - 1) * limit;

  const params: any = { limit, offset };
  if (category !== "All") params.category = category;

  const { data, isLoading } = useListBlogs(params);

  const totalPages = data ? Math.ceil(data.total / limit) : 0;

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      <div className="mb-6">
        <div className="flex items-center text-sm text-muted-foreground mb-4">
          <Link href="/" className="hover:text-accent">Home</Link>
          <span className="mx-2">›</span>
          <span className="text-foreground font-medium">Blogs & News</span>
        </div>
        <h1 className="text-3xl md:text-4xl font-extrabold text-foreground mb-2 flex items-center">
          <Newspaper className="w-8 h-8 mr-3 text-accent" />
          Govt Jobs & Scheme Updates
        </h1>
        <p className="text-muted-foreground font-medium text-lg">Latest news, admit cards, results, and syllabus updates.</p>
      </div>

      <Advertisement />

      {/* Filters */}
      <div className="bg-muted p-4 rounded-lg mb-8 flex flex-col md:flex-row gap-4 items-center border border-border">
        <div className="flex items-center font-bold text-foreground">
          <Filter className="w-5 h-5 mr-2 text-accent" />
          Category Filter:
        </div>
        
        <div className="flex-1 w-full flex flex-col sm:flex-row gap-4">
          <Select value={category} onValueChange={(val) => { setCategory(val); setPage(1); }}>
            <SelectTrigger className="w-full sm:w-[250px] bg-background">
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent>
              {CATEGORIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        
        <div className="text-sm font-semibold text-muted-foreground">
          Showing {data?.total || 0} articles
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
        {isLoading ? (
          Array(12).fill(0).map((_, i) => (
            <Skeleton key={i} className="h-[250px] w-full rounded-xl" />
          ))
        ) : data?.blogs.length === 0 ? (
          <div className="col-span-full py-12 text-center border border-dashed border-border rounded-xl">
            <Newspaper className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
            <h3 className="text-xl font-bold text-foreground mb-2">No articles found</h3>
            <p className="text-muted-foreground">Try adjusting your filters to see more results.</p>
            <Button variant="outline" className="mt-4 border-accent text-accent" onClick={() => setCategory("All")}>
              View All Articles
            </Button>
          </div>
        ) : (
          data?.blogs.map((blog) => (
            <BlogCard key={blog.id} blog={blog} />
          ))
        )}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex justify-center items-center space-x-2">
          <Button 
            variant="outline" 
            disabled={page === 1}
            onClick={() => setPage(p => Math.max(1, p - 1))}
          >
            Previous
          </Button>
          <div className="flex items-center space-x-1">
            {Array.from({ length: Math.min(5, totalPages) }).map((_, i) => {
              let p = page;
              if (page < 3) p = i + 1;
              else if (page > totalPages - 2) p = totalPages - 4 + i;
              else p = page - 2 + i;
              
              if (p > 0 && p <= totalPages) {
                return (
                  <Button 
                    key={p} 
                    variant={page === p ? "default" : "outline"}
                    className={page === p ? "bg-accent text-white hover:bg-accent/90" : ""}
                    onClick={() => setPage(p)}
                  >
                    {p}
                  </Button>
                );
              }
              return null;
            })}
          </div>
          <Button 
            variant="outline" 
            disabled={page === totalPages}
            onClick={() => setPage(p => Math.min(totalPages, p + 1))}
          >
            Next
          </Button>
        </div>
      )}
    </div>
  );
}
