/**
 * GovJobs & Yojna Info — blogGenerator.js
 * Auto-generates SEO blog posts from feed items
 * Developed by Breakout Trade
 */

const admin = require('firebase-admin');

const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];
const STATES = ['maharashtra','up','gujarat','rajasthan','karnataka','tamilnadu','westbengal','bihar','mp','punjab','ap','telangana','kerala','odisha','haryana','jharkhand','assam','chhattisgarh','central'];
const STATE_NAMES = {
  maharashtra: 'Maharashtra', up: 'Uttar Pradesh', gujarat: 'Gujarat',
  rajasthan: 'Rajasthan', karnataka: 'Karnataka', tamilnadu: 'Tamil Nadu',
  westbengal: 'West Bengal', bihar: 'Bihar', mp: 'Madhya Pradesh',
  punjab: 'Punjab', ap: 'Andhra Pradesh', telangana: 'Telangana',
  kerala: 'Kerala', odisha: 'Odisha', haryana: 'Haryana',
  jharkhand: 'Jharkhand', assam: 'Assam', chhattisgarh: 'Chhattisgarh',
  central: 'Central Government'
};

// ─── Generate All Blog Posts ─────────────────────────────────
async function generateBlogPosts() {
  const db = admin.firestore();
  const now = new Date();
  const month = MONTHS[now.getMonth()];
  const year = now.getFullYear();

  let totalGenerated = 0;

  for (const region of STATES) {
    try {
      // Fetch latest 5 jobs for this state
      const jobsSnap = await db.collection('feeds')
        .where('type', '==', 'job')
        .where('region', '==', region)
        .orderBy('pubDate', 'desc')
        .limit(5)
        .get();

      // Fetch latest 5 yojanas
      const yojanaSnap = await db.collection('feeds')
        .where('type', '==', 'yojana')
        .where('region', 'in', [region, 'central'])
        .orderBy('pubDate', 'desc')
        .limit(5)
        .get();

      const jobs = jobsSnap.docs.map(d => d.data());
      const yojanas = yojanaSnap.docs.map(d => d.data());

      if (jobs.length === 0 && yojanas.length === 0) continue;

      // Generate job post
      if (jobs.length > 0) {
        const post = generateJobPost(region, jobs, month, year);
        await savePost(db, post);
        totalGenerated++;
      }

      // Generate yojana post for central only (avoid duplicates)
      if (yojanas.length > 0 && region === 'central') {
        const post = generateYojanaPost(yojanas, month, year);
        await savePost(db, post);
        totalGenerated++;
      }

    } catch (err) {
      console.warn(`Blog generation failed for ${region}:`, err.message);
    }
  }

  // Ping sitemap after generating
  await pingSitemaps().catch(() => {});

  console.log(`generateBlogPosts complete: ${totalGenerated} posts`);
  return { generated: totalGenerated };
}

// ─── Generate Job Blog Post ──────────────────────────────────
function generateJobPost(region, jobs, month, year) {
  const stateName = STATE_NAMES[region] || region;
  const title = `Latest Government Jobs in ${stateName} — ${month} ${year}`;
  const slug = toSlug(`latest-govt-jobs-${region}-${month.toLowerCase()}-${year}`);

  const jobListHTML = jobs.map((job, i) => `
    <div style="border-left:3px solid #FF6B00;padding:10px 14px;margin-bottom:12px;background:#FFF3E8;border-radius:0 8px 8px 0">
      <h3 style="margin:0 0 4px">${i+1}. ${job.title}</h3>
      <p style="margin:0;font-size:0.88rem;color:#5C4F40">📅 ${formatDate(job.pubDate)} | 📰 ${job.source || 'Official'}</p>
      <p style="margin:6px 0 0;font-size:0.85rem">${(job.desc || '').substring(0, 200)}…</p>
      <a href="${job.link}" target="_blank" rel="noopener" style="display:inline-block;margin-top:8px;background:#FF6B00;color:white;padding:4px 12px;border-radius:4px;font-size:0.82rem;text-decoration:none">View Official →</a>
    </div>
  `).join('');

  const faqs = [
    { q: `How to apply for government jobs in ${stateName}?`, a: `Visit the official recruitment website linked in each job notification. Register with your credentials, fill the online application form, upload required documents (photo, signature, certificates), pay the application fee if applicable, and submit before the deadline. Always apply only through official government portals.` },
    { q: `What documents are needed for ${stateName} government jobs?`, a: `Typically required: 10th/12th marksheet, graduation certificate, caste certificate (if applicable), Aadhaar card, passport-size photos, signature, and domicile certificate. Check each specific notification for exact requirements.` },
    { q: `When is the application deadline for these jobs?`, a: `Each job notification has its own deadline. Click "View Official" on any listing to check the exact last date on the official website. Do not rely solely on this page — always verify the deadline from the official source.` },
    { q: `What is the age limit for ${stateName} government jobs?`, a: `Age limits vary by position and category. Generally: General - 18-35 years, OBC - up to 38 years, SC/ST - up to 40 years. Check the specific notification for exact age requirements and relaxations.` },
    { q: `Are there any fees for applying to government jobs?`, a: `Fees vary: General/OBC candidates typically pay ₹100-₹500. SC/ST/Female/PwD candidates often have fee waivers. Payment is accepted online (Debit/Credit card, Net Banking, UPI). Check official notification for exact fee details.` }
  ];

  const content = `
    <p>Looking for the latest government jobs in <strong>${stateName}</strong>? You're at the right place. GovJobs & Yojna Info aggregates official government recruitment notifications every 48 hours, so you never miss an opportunity.</p>

    <p><strong>⚠️ Disclaimer:</strong> GovJobs & Yojna Info is NOT an official government website. Always verify details from official government portals before applying. Developed by Breakout Trade.</p>

    <h2>Latest ${stateName} Government Jobs — ${month} ${year}</h2>
    <p>Here are the latest government job notifications for ${stateName} updated this month:</p>

    ${jobListHTML}

    <h2>How to Apply for Government Jobs in ${stateName}</h2>
    <ol>
      <li><strong>Check Official Notification:</strong> Click the "View Official" button above to go to the official recruitment website.</li>
      <li><strong>Read Notification Carefully:</strong> Check eligibility, age limit, qualifications, and important dates.</li>
      <li><strong>Register Online:</strong> Create an account on the official recruitment portal.</li>
      <li><strong>Fill Application Form:</strong> Enter all details accurately. Double-check before submitting.</li>
      <li><strong>Upload Documents:</strong> Photo, signature, and required certificates in specified format/size.</li>
      <li><strong>Pay Application Fee:</strong> If applicable, pay online via Net Banking/UPI/Debit Card.</li>
      <li><strong>Submit & Print:</strong> Submit the form and take a printout for future reference.</li>
    </ol>

    <h2>Important Dates</h2>
    <table>
      <tr><th>Event</th><th>Details</th></tr>
      <tr><td>Notification Published</td><td>${month} ${year}</td></tr>
      <tr><td>Application Start</td><td>Check official website</td></tr>
      <tr><td>Last Date to Apply</td><td>Check official notification</td></tr>
      <tr><td>Admit Card</td><td>Check official website</td></tr>
      <tr><td>Exam Date</td><td>Check official notification</td></tr>
    </table>

    <h2>General Eligibility</h2>
    <ul>
      <li>Citizenship: Indian National</li>
      <li>Age: As per specific notification (typically 18–35 years, relaxation for reserved categories)</li>
      <li>Educational Qualification: As per post requirements</li>
      <li>Domicile: ${stateName} domicile may be required for state-level jobs</li>
    </ul>

    <p>For accurate eligibility criteria, always refer to the official recruitment notification.</p>

    <div style="background:#FFF3CD;border:1px solid #FF6B00;border-radius:8px;padding:14px;margin:20px 0">
      <strong>⚠️ Disclaimer:</strong> GovJobs & Yojna Info is NOT affiliated with the Government of India or ${stateName} government. All information is for reference only. Always verify from official government websites. Developed by <strong>Breakout Trade</strong>.
    </div>
  `;

  return {
    title,
    slug,
    content,
    excerpt: `Latest government jobs in ${stateName} for ${month} ${year}. Check eligibility, how to apply, important dates and official links.`,
    category: 'jobs',
    region,
    lang: 'en',
    keywords: `govt jobs ${stateName.toLowerCase()} ${year}, sarkari naukri ${region} ${year}, ${stateName.toLowerCase()} recruitment ${year}, ${month.toLowerCase()} ${year} jobs`,
    faqs,
    publishedAt: admin.firestore.FieldValue.serverTimestamp(),
    views: 0,
    readTime: Math.ceil(content.split(' ').length / 200),
    isAutoGenerated: true
  };
}

// ─── Generate Yojana Blog Post ───────────────────────────────
function generateYojanaPost(yojanas, month, year) {
  const title = `Sarkari Yojana ${year} — Latest Government Schemes | ${month} Updates`;
  const slug = toSlug(`sarkari-yojana-${year}-latest-schemes-${month.toLowerCase()}`);

  const yojanaListHTML = yojanas.map((y, i) => `
    <div style="border-left:3px solid #7B2FBE;padding:10px 14px;margin-bottom:12px;background:#F3E8FF;border-radius:0 8px 8px 0">
      <h3 style="margin:0 0 4px">${i+1}. ${y.title}</h3>
      <p style="margin:0;font-size:0.85rem">${(y.desc || '').substring(0, 200)}…</p>
      <a href="${y.link}" target="_blank" rel="noopener" style="display:inline-block;margin-top:8px;background:#7B2FBE;color:white;padding:4px 12px;border-radius:4px;font-size:0.82rem;text-decoration:none">View Official →</a>
    </div>
  `).join('');

  const faqs = [
    { q: 'What is PM Awas Yojana and how to apply?', a: 'PM Awas Yojana provides housing assistance to urban and rural poor. Apply at pmayg.nic.in (rural) or pmaymis.gov.in (urban). You can also apply through your local gram panchayat, urban local body, or Common Service Centre (CSC).' },
    { q: 'Who is eligible for PM Kisan Samman Nidhi?', a: 'All landholding farmers with cultivable land are eligible. Exclusions include those holding constitutional posts, paying income tax, or employed with government. Register at pmkisan.gov.in or through your local patwari/lekhpal.' },
    { q: 'How to apply for Ayushman Bharat PM-JAY?', a: 'Check eligibility on the Ayushman Bharat website (pmjay.gov.in) or call 14555. If eligible, get your e-card from any empanelled hospital or Common Service Centre.' },
    { q: 'What documents are needed for government schemes?', a: 'Common documents: Aadhaar card, bank passbook, income certificate, caste certificate (if applicable), land records (for agricultural schemes), BPL/SECC data proof. Requirements vary by scheme — check official websites.' },
    { q: 'Are these yojanas available in all states?', a: 'Central government yojanas like PM Awas, PM Kisan, and Ayushman Bharat are available across all states. Some states have additional schemes. State-specific yojanas are available based on residence in that state.' }
  ];

  const content = `
    <p>The Government of India runs hundreds of schemes (yojanas) to improve the lives of citizens across India. Here are the latest updates on government schemes for ${month} ${year}.</p>

    <p><strong>⚠️ Disclaimer:</strong> GovJobs & Yojna Info is NOT an official government website. Always verify yojana details from official government portals. Developed by Breakout Trade.</p>

    <h2>Latest Yojana Updates — ${month} ${year}</h2>
    ${yojanaListHTML}

    <h2>Key Central Government Yojanas to Know</h2>
    <table>
      <tr><th>Scheme Name</th><th>Benefit</th><th>Official Portal</th></tr>
      <tr><td>PM Awas Yojana</td><td>Housing assistance up to ₹2.67 lakh</td><td>pmayg.nic.in</td></tr>
      <tr><td>PM Kisan</td><td>₹6,000/year to farmers</td><td>pmkisan.gov.in</td></tr>
      <tr><td>Ayushman Bharat</td><td>₹5 lakh health insurance</td><td>pmjay.gov.in</td></tr>
      <tr><td>PM Ujjwala Yojana</td><td>Free LPG connection</td><td>pmuy.gov.in</td></tr>
      <tr><td>Jan Dhan Yojana</td><td>Zero-balance bank account</td><td>pmjdy.gov.in</td></tr>
      <tr><td>Mudra Yojana</td><td>Business loans up to ₹10 lakh</td><td>mudra.org.in</td></tr>
    </table>

    <h2>How to Apply for Government Schemes</h2>
    <ol>
      <li>Visit the official scheme portal (links in table above)</li>
      <li>Check eligibility criteria</li>
      <li>Gather required documents (Aadhaar, bank details, etc.)</li>
      <li>Visit nearest Common Service Centre (CSC) or apply online</li>
      <li>Submit application and note reference number</li>
    </ol>

    <div style="background:#FFF3CD;border:1px solid #FF6B00;border-radius:8px;padding:14px;margin:20px 0">
      <strong>⚠️ Disclaimer:</strong> GovJobs & Yojna Info is NOT affiliated with the Government of India. All information is for reference only. Always verify from official government websites. Developed by <strong>Breakout Trade</strong>.
    </div>
  `;

  return {
    title, slug, content,
    excerpt: `Latest government schemes and yojana updates for ${month} ${year}. PM Awas, PM Kisan, Ayushman Bharat and more.`,
    category: 'yojana',
    region: 'central',
    lang: 'en',
    keywords: `sarkari yojana ${year}, pm yojana ${year}, government schemes india ${year}, pm awas yojana apply, pm kisan 19th installment`,
    faqs,
    publishedAt: admin.firestore.FieldValue.serverTimestamp(),
    views: 0,
    readTime: Math.ceil(content.split(' ').length / 200),
    isAutoGenerated: true
  };
}

// ─── Save Post to Firestore ──────────────────────────────────
async function savePost(db, post) {
  try {
    // Check if slug already exists
    const existing = await db.collection('blogs').doc(post.slug).get();
    if (existing.exists) {
      // Update view count preserved, update content
      await db.collection('blogs').doc(post.slug).set({
        ...post,
        updatedAt: admin.firestore.FieldValue.serverTimestamp()
      }, { merge: true });
    } else {
      await db.collection('blogs').doc(post.slug).set(post);
    }
  } catch (err) {
    console.warn(`savePost failed for ${post.slug}:`, err.message);
  }
}

// ─── Ping Sitemaps ───────────────────────────────────────────
async function pingSitemaps() {
  const fetch = (...args) => import('node-fetch').then(({ default: f }) => f(...args));
  const sitemapUrl = encodeURIComponent('https://govjobsyojnainfo.in/sitemap.xml');
  const pings = [
    `https://www.google.com/ping?sitemap=${sitemapUrl}`,
    `https://www.bing.com/webmaster/ping.aspx?siteMap=${sitemapUrl}`
  ];
  await Promise.allSettled(pings.map(url =>
    fetch(url, { signal: AbortSignal.timeout(5000) })
  ));
}

// ─── Helpers ─────────────────────────────────────────────────
function toSlug(str) {
  return str.toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
    .substring(0, 100);
}

function formatDate(dateStr) {
  if (!dateStr) return 'Recent';
  try {
    return new Date(dateStr).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
  } catch(e) { return dateStr; }
}

module.exports = { generateBlogPosts };
