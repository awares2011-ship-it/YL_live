/**
 * GovJobs & Yojna Info — ticker.js
 * Scrolling latest updates ticker bar
 * Developed by Breakout Trade
 */

const TICKER_REFRESH_MS = 30 * 60 * 1000; // 30 minutes
let tickerRefreshTimer = null;

document.addEventListener('DOMContentLoaded', () => {
  loadTicker();
});

async function loadTicker() {
  const tickerContent = document.getElementById('ticker-content');
  if (!tickerContent) return;

  try {
    // Try localStorage cache first
    const cached = localStorage.getItem('gj_ticker_cache');
    if (cached) {
      const parsed = JSON.parse(cached);
      if (Date.now() < parsed.expiry && Array.isArray(parsed.items) && parsed.items.length > 0) {
        renderTicker(parsed.items);
        scheduleTickerRefresh();
        return;
      }
    }
    await fetchAndRenderTicker();
  } catch (e) {
    // On error, show static fallback
    renderTickerFallback();
  }

  scheduleTickerRefresh();
}

async function fetchAndRenderTicker() {
  const tickerContent = document.getElementById('ticker-content');
  if (!tickerContent) return;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8000);

  try {
    const res = await fetch('/api/ticker', { signal: controller.signal });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    const items = Array.isArray(data.items) ? data.items : [];

    if (items.length > 0) {
      localStorage.setItem('gj_ticker_cache', JSON.stringify({
        items,
        expiry: Date.now() + 30 * 60 * 1000
      }));
      renderTicker(items);

      if (typeof gtag !== 'undefined') {
        gtag('event', 'feed_loaded', { type: 'ticker', item_count: items.length });
      }
    } else {
      renderTickerFallback();
    }
  } catch (e) {
    if (e.name !== 'AbortError') {
      renderTickerFallback();
    }
  } finally {
    clearTimeout(timeout);
  }
}

function renderTicker(items) {
  const tickerContent = document.getElementById('ticker-content');
  if (!tickerContent) return;

  if (!Array.isArray(items) || items.length === 0) {
    renderTickerFallback();
    return;
  }

  const html = items.map((item, idx) => {
    const type = (item.type || 'news').toLowerCase();
    const title = escapeTickerText(item.title || '');
    const link = item.link || '#';
    return `
      <span class="ticker-item"
            onclick="tickerItemClicked('${encodeURIComponent(title)}', '${type}', '${encodeURIComponent(link)}')"
            title="${title}">
        <span class="ticker-type ${type}">${capitalize(type)}</span>
        ${title}
      </span>
      <span class="ticker-sep">●</span>
    `;
  }).join('');

  tickerContent.innerHTML = html;
  // Reset animation
  tickerContent.style.animation = 'none';
  requestAnimationFrame(() => {
    tickerContent.style.animation = '';
  });
}

function renderTickerFallback() {
  const tickerContent = document.getElementById('ticker-content');
  if (!tickerContent) return;
  const fallbacks = [
    { type: 'job', text: 'Latest Railway Recruitment 2026 — Check eligibility & apply online' },
    { type: 'yojana', text: 'PM Awas Yojana — New beneficiary list released for 2026' },
    { type: 'job', text: 'SSC CGL 2026 Notification released — 17,727 posts available' },
    { type: 'yojana', text: 'PM Kisan Samman Nidhi — 19th installment date announced' },
    { type: 'job', text: 'UPSC Civil Services 2026 — Application window now open' },
    { type: 'news', text: 'State government schemes — Apply before deadline' },
  ];
  tickerContent.innerHTML = fallbacks.map(f => `
    <span class="ticker-item">
      <span class="ticker-type ${f.type}">${capitalize(f.type)}</span>
      ${f.text}
    </span>
    <span class="ticker-sep">●</span>
  `).join('');
}

function scheduleTickerRefresh() {
  if (tickerRefreshTimer) clearInterval(tickerRefreshTimer);
  tickerRefreshTimer = setInterval(async () => {
    // Invalidate cache and refresh
    localStorage.removeItem('gj_ticker_cache');
    try {
      await fetchAndRenderTicker();
    } catch (e) { /* silent fail */ }
  }, TICKER_REFRESH_MS);
}

function tickerItemClicked(title, type, link) {
  try {
    if (typeof gtag !== 'undefined') {
      gtag('event', 'ticker_clicked', {
        title: decodeURIComponent(title),
        type
      });
    }
    const decodedLink = decodeURIComponent(link);
    if (decodedLink && decodedLink !== '#') {
      window.open(decodedLink, '_blank', 'noopener');
    }
  } catch (e) { /* ignore */ }
}

function escapeTickerText(str) {
  if (!str) return '';
  return String(str)
    .replace(/'/g, '\\\'')
    .replace(/"/g, '&quot;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .slice(0, 120);
}

function capitalize(str) {
  if (!str) return '';
  return str.charAt(0).toUpperCase() + str.slice(1);
}

window.tickerItemClicked = tickerItemClicked;
