import { Router } from "express";
import { db } from "@workspace/db";
import { schemesTable } from "@workspace/db";
import { eq, desc, and, sql } from "drizzle-orm";
import {
  ListSchemesQueryParams,
  CreateSchemeBody,
  GetSchemeParams,
} from "@workspace/api-zod";

const router = Router();

router.get("/", async (req, res) => {
  const parsed = ListSchemesQueryParams.safeParse(req.query);
  if (!parsed.success) {
    return res.status(400).json({ error: "Invalid query params" });
  }
  const { category, limit = 20, offset = 0 } = parsed.data;

  const conditions = [];
  if (category) conditions.push(eq(schemesTable.category, category));
  const where = conditions.length > 0 ? and(...conditions) : undefined;

  const [schemes, countResult] = await Promise.all([
    db.select().from(schemesTable).where(where).orderBy(desc(schemesTable.createdAt)).limit(limit).offset(offset),
    db.select({ count: sql<number>`count(*)` }).from(schemesTable).where(where),
  ]);

  return res.json({ schemes, total: Number(countResult[0]?.count ?? 0) });
});

router.post("/", async (req, res) => {
  const parsed = CreateSchemeBody.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "Invalid body" });
  }
  const [scheme] = await db.insert(schemesTable).values(parsed.data).returning();
  return res.status(201).json(scheme);
});

router.get("/:id", async (req, res) => {
  const parsed = GetSchemeParams.safeParse({ id: Number(req.params.id) });
  if (!parsed.success) {
    return res.status(400).json({ error: "Invalid id" });
  }
  const [scheme] = await db.select().from(schemesTable).where(eq(schemesTable.id, parsed.data.id));
  if (!scheme) return res.status(404).json({ error: "Not found" });
  await db.update(schemesTable).set({ viewCount: sql`${schemesTable.viewCount} + 1` }).where(eq(schemesTable.id, parsed.data.id));
  return res.json(scheme);
});

export default router;
