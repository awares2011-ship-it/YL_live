import { useEffect } from "react";
import { Link, useParams } from "wouter";
import { useGetJob, useListJobs, getGetJobQueryKey } from "@workspace/api-client-react";
import { ContentRenderer } from "@/components/ContentRenderer";
import { Advertisement } from "@/components/Advertisement";
import { JobCard } from "@/components/JobCard";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent } from "@/components/ui/card";
import { Briefcase, Building2, Calendar, MapPin, IndianRupee, Users, Share2, ExternalLink } from "lucide-react";

export default function JobDetailPage() {
  const params = useParams();
  const id = parseInt(params.id || "0", 10);

  const { data: job, isLoading } = useGetJob(id, {
    query: { enabled: !!id, queryKey: getGetJobQueryKey(id) }
  });

  const { data: relatedJobs } = useListJobs(
    { category: job?.category, limit: 3 },
    { query: { enabled: !!job?.category } }
  );

  useEffect(() => {
    if (job) {
      document.title = `${job.title} | govJobsInfo`;
      // In a real app, update meta tags here
    }
  }, [job]);

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        <Skeleton className="h-8 w-64 mb-4" />
        <Skeleton className="h-12 w-full max-w-3xl mb-8" />
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <Skeleton className="h-[200px] w-full" />
            <Skeleton className="h-[400px] w-full" />
          </div>
          <div className="space-y-6">
            <Skeleton className="h-[300px] w-full" />
          </div>
        </div>
      </div>
    );
  }

  if (!job) return <div className="text-center py-20 font-bold text-2xl">Job not found</div>;

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      {/* Breadcrumb */}
      <div className="flex items-center text-sm text-muted-foreground mb-6 overflow-x-auto whitespace-nowrap pb-2">
        <Link href="/" className="hover:text-primary">Home</Link>
        <span className="mx-2 shrink-0">›</span>
        <Link href="/jobs" className="hover:text-primary shrink-0">Govt Jobs</Link>
        <span className="mx-2 shrink-0">›</span>
        <span className="text-foreground font-medium truncate">{job.title}</span>
      </div>

      <Advertisement />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-6">
        {/* Main Content */}
        <div className="lg:col-span-2">
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-4 flex-wrap">
              <Badge className="bg-primary hover:bg-primary/90">{job.category}</Badge>
              {job.isTrending && <Badge variant="destructive">🔥 Trending</Badge>}
              {job.isNew && <Badge className="bg-secondary hover:bg-secondary/90">🆕 New</Badge>}
            </div>
            
            <h1 className="text-3xl md:text-4xl font-extrabold text-accent mb-4 leading-tight">
              {job.title}
            </h1>
            
            <div className="flex flex-col sm:flex-row gap-4 sm:items-center text-muted-foreground font-medium pb-6 border-b border-border">
              <div className="flex items-center">
                <Building2 className="w-5 h-5 mr-2 text-primary" />
                {job.organization}
              </div>
              <div className="hidden sm:block text-border">•</div>
              <div className="flex items-center text-sm">
                Posted on: {new Date(job.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
              </div>
            </div>
          </div>

          {/* Quick Info Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <Card className="bg-muted/50 border-none shadow-none">
              <CardContent className="p-4 flex flex-col items-center justify-center text-center">
                <Users className="w-8 h-8 text-primary mb-2" />
                <span className="text-sm text-muted-foreground font-semibold">Total Posts</span>
                <span className="text-lg font-bold text-foreground">{job.totalPosts}</span>
              </CardContent>
            </Card>
            <Card className="bg-muted/50 border-none shadow-none">
              <CardContent className="p-4 flex flex-col items-center justify-center text-center">
                <IndianRupee className="w-8 h-8 text-primary mb-2" />
                <span className="text-sm text-muted-foreground font-semibold">Salary</span>
                <span className="text-lg font-bold text-foreground truncate w-full">{job.salary}</span>
              </CardContent>
            </Card>
            <Card className="bg-muted/50 border-none shadow-none">
              <CardContent className="p-4 flex flex-col items-center justify-center text-center">
                <MapPin className="w-8 h-8 text-primary mb-2" />
                <span className="text-sm text-muted-foreground font-semibold">Location</span>
                <span className="text-lg font-bold text-foreground">{job.state}</span>
              </CardContent>
            </Card>
            <Card className="bg-destructive/5 border-none shadow-none">
              <CardContent className="p-4 flex flex-col items-center justify-center text-center">
                <Calendar className="w-8 h-8 text-destructive mb-2" />
                <span className="text-sm text-muted-foreground font-semibold">Last Date</span>
                <span className="text-lg font-bold text-destructive">{job.lastDate}</span>
              </CardContent>
            </Card>
          </div>

          <Advertisement />

          {/* Content */}
          <div className="mt-8 bg-white border border-border rounded-xl p-6 md:p-8 shadow-sm">
            <ContentRenderer content={job.content} />
            
            <div className="mt-10 pt-8 border-t border-border flex flex-col items-center text-center">
              <h3 className="text-xl font-bold mb-4">Ready to Apply?</h3>
              <p className="text-muted-foreground mb-6 max-w-md mx-auto">Make sure you have read all the eligibility criteria and keep your documents ready before applying.</p>
              
              <Button size="lg" className="w-full sm:w-auto text-lg h-14 px-10" asChild>
                <a href={job.applyUrl || "#"} target="_blank" rel="noopener noreferrer">
                  Apply Online Now <ExternalLink className="ml-2 w-5 h-5" />
                </a>
              </Button>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          <Card className="border-border">
            <CardContent className="p-6">
              <h3 className="text-lg font-bold text-accent mb-4 pb-2 border-b border-border">Important Dates</h3>
              <ul className="space-y-3 font-medium">
                <li className="flex justify-between">
                  <span className="text-muted-foreground">Notification out:</span>
                  <span className="text-foreground">Soon</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-muted-foreground">Start Date:</span>
                  <span className="text-foreground">Available</span>
                </li>
                <li className="flex justify-between text-destructive font-bold">
                  <span>Last Date:</span>
                  <span>{job.lastDate}</span>
                </li>
              </ul>
            </CardContent>
          </Card>

          <Button variant="outline" className="w-full flex items-center justify-center border-primary text-primary hover:bg-primary hover:text-primary-foreground">
            <Share2 className="w-4 h-4 mr-2" /> Share with Friends
          </Button>

          <Advertisement />

          {/* Related Jobs */}
          {relatedJobs && relatedJobs.jobs.length > 0 && (
            <div>
              <h3 className="text-xl font-bold text-accent mb-4 border-l-4 border-primary pl-3">Similar Jobs</h3>
              <div className="space-y-4">
                {relatedJobs.jobs.filter(j => j.id !== job.id).slice(0, 3).map(relatedJob => (
                  <Link key={relatedJob.id} href={`/jobs/${relatedJob.id}`}>
                    <Card className="hover-elevate cursor-pointer border-border hover:border-primary/50 transition-colors">
                      <CardContent className="p-4">
                        <h4 className="font-bold text-sm text-foreground line-clamp-2 mb-2 group-hover:text-primary">{relatedJob.title}</h4>
                        <div className="flex justify-between text-xs text-muted-foreground">
                          <span>{relatedJob.organization}</span>
                          <span className="text-destructive font-semibold">{relatedJob.lastDate}</span>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
