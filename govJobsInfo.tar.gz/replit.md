# India GovHub Workspace

## Overview

Full-stack India GovHub SEO website — a comprehensive portal for Indian government jobs, Kisan (farmer) schemes, and government welfare programs, designed to rank on Google and generate organic traffic.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **Frontend**: React + Vite (artifacts/india-govhub)
- **API framework**: Express 5 (artifacts/api-server)
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)
- **Styling**: Tailwind CSS + Noto Sans font (Indian tricolor palette)

## Architecture

- `artifacts/india-govhub/` — React + Vite frontend (deployed at `/`)
- `artifacts/api-server/` — Express API server (served at `/api`)
- `lib/db/` — PostgreSQL schema (jobs, schemes, blogs tables)
- `lib/api-spec/openapi.yaml` — API contract
- `lib/api-client-react/` — Generated React Query hooks
- `lib/api-zod/` — Generated Zod schemas

## Key Features

### SEO Pages
- Government Jobs: SSC, Railway, Bank, 10th Pass, Graduate, State
- Kisan Yojana: PM Kisan, Tractor Subsidy, Fasal Bima, KCC
- Women Schemes, PM Yojana List
- Blog system with rich content

### Pages
- `/` — Home with hero, stats, trending, latest jobs/schemes/blogs
- `/jobs` — Government jobs listing with filters
- `/jobs/:id` — Job detail with full content
- `/jobs/ssc`, `/jobs/railway`, `/jobs/bank` — Category pages
- `/schemes` — Government schemes listing
- `/schemes/:id` — Scheme detail
- `/schemes/kisan` — Kisan schemes page
- `/blogs` — Blog listing
- `/blogs/:id` — Blog detail
- `/tools` — EMI Calculator + Age Calculator

### Backend Endpoints
- `GET /api/jobs` — List jobs (filter by category, state)
- `POST /api/jobs` — Create job
- `GET /api/jobs/:id` — Get job detail
- `GET /api/schemes` — List schemes
- `GET /api/schemes/:id` — Get scheme detail
- `GET /api/blogs` — List blogs
- `GET /api/blogs/:id` — Get blog detail
- `GET /api/trending` — Trending items
- `GET /api/summary` — Site stats

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally
- `node artifacts/api-server/dist/seed.mjs` — seed database with sample data

## Database Tables
- `jobs` — Government job listings
- `schemes` — Government welfare schemes
- `blogs` — Blog posts and articles

## SEO Optimization
- Each page has unique document.title
- AdSense placeholder banners placed strategically
- Content renderer parses markdown-like content (headers, tables, bold, lists)
- Trending/New badges on listings
- Indian tricolor palette (saffron orange, white, India green, navy)
