import { useEffect } from "react";
import { Link, useParams } from "wouter";
import { useGetBlog, useListBlogs, getGetBlogQueryKey } from "@workspace/api-client-react";
import { ContentRenderer } from "@/components/ContentRenderer";
import { Advertisement } from "@/components/Advertisement";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent } from "@/components/ui/card";
import { Newspaper, UserCircle2, CalendarDays, Share2, Tag } from "lucide-react";
import { format } from "date-fns";

export default function BlogDetailPage() {
  const params = useParams();
  const id = parseInt(params.id || "0", 10);

  const { data: blog, isLoading } = useGetBlog(id, {
    query: { enabled: !!id, queryKey: getGetBlogQueryKey(id) }
  });

  const { data: relatedBlogs } = useListBlogs(
    { category: blog?.category, limit: 3 },
    { query: { enabled: !!blog?.category } }
  );

  useEffect(() => {
    if (blog) {
      document.title = `${blog.title} | govJobsInfo`;
    }
  }, [blog]);

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        <Skeleton className="h-8 w-64 mb-4" />
        <Skeleton className="h-12 w-full max-w-3xl mb-8" />
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <Skeleton className="h-[200px] w-full" />
            <Skeleton className="h-[400px] w-full" />
          </div>
        </div>
      </div>
    );
  }

  if (!blog) return <div className="text-center py-20 font-bold text-2xl">Article not found</div>;

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      {/* Breadcrumb */}
      <div className="flex items-center text-sm text-muted-foreground mb-6 overflow-x-auto whitespace-nowrap pb-2">
        <Link href="/" className="hover:text-accent">Home</Link>
        <span className="mx-2 shrink-0">›</span>
        <Link href="/blogs" className="hover:text-accent shrink-0">Blogs & News</Link>
        <span className="mx-2 shrink-0">›</span>
        <span className="text-foreground font-medium truncate">{blog.title}</span>
      </div>

      <Advertisement />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-6">
        {/* Main Content */}
        <div className="lg:col-span-2">
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-4 flex-wrap">
              <Badge className="bg-accent hover:bg-accent/90">{blog.category}</Badge>
            </div>
            
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-extrabold text-foreground mb-6 leading-tight">
              {blog.title}
            </h1>
            
            <div className="flex flex-col sm:flex-row gap-4 sm:items-center text-muted-foreground font-medium pb-6 border-b border-border">
              <div className="flex items-center">
                <UserCircle2 className="w-5 h-5 mr-2 text-accent" />
                {blog.author}
              </div>
              <div className="hidden sm:block text-border">•</div>
              <div className="flex items-center">
                <CalendarDays className="w-5 h-5 mr-2 text-accent" />
                {format(new Date(blog.createdAt), "MMMM d, yyyy")}
              </div>
            </div>
          </div>

          {/* Excerpt */}
          <div className="text-lg text-muted-foreground font-medium italic border-l-4 border-accent pl-4 py-2 mb-8 bg-muted/20">
            {blog.excerpt}
          </div>

          <Advertisement />

          {/* Content */}
          <div className="mt-8 bg-white border border-border rounded-xl p-6 md:p-8 shadow-sm">
            <ContentRenderer content={blog.content} />
            
            <div className="mt-10 pt-8 border-t border-border">
              <div className="flex items-center gap-2 flex-wrap">
                <Tag className="w-5 h-5 text-muted-foreground mr-2" />
                {blog.tags.map((tag, i) => (
                  <Badge key={i} variant="outline" className="bg-muted text-muted-foreground hover:bg-muted/80">
                    {tag}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          <Button variant="outline" className="w-full flex items-center justify-center border-accent text-accent hover:bg-accent hover:text-white transition-colors h-12 font-bold text-base">
            <Share2 className="w-5 h-5 mr-2" /> Share Article
          </Button>

          <Advertisement />

          {/* Related Blogs */}
          {relatedBlogs && relatedBlogs.blogs.length > 0 && (
            <div className="bg-muted/30 p-4 rounded-xl border border-border">
              <h3 className="text-xl font-bold text-foreground mb-4 border-l-4 border-accent pl-3">Related Articles</h3>
              <div className="space-y-4">
                {relatedBlogs.blogs.filter(b => b.id !== blog.id).slice(0, 4).map(relatedBlog => (
                  <Link key={relatedBlog.id} href={`/blogs/${relatedBlog.id}`}>
                    <Card className="hover-elevate cursor-pointer border-border hover:border-accent/50 transition-colors bg-white">
                      <CardContent className="p-4">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant="outline" className="text-[10px] py-0 px-1 border-accent/20 text-accent bg-accent/5">{relatedBlog.category}</Badge>
                        </div>
                        <h4 className="font-bold text-sm text-foreground line-clamp-2 mb-2 group-hover:text-accent">{relatedBlog.title}</h4>
                        <div className="text-xs text-muted-foreground font-medium">
                          {format(new Date(relatedBlog.createdAt), "MMM d, yyyy")}
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
