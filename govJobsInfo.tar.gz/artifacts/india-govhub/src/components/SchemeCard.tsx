import { Link } from "wouter";
import { Scheme } from "@workspace/api-client-react";
import { Badge } from "./ui/badge";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "./ui/card";
import { Landmark, Users2, IndianRupee } from "lucide-react";

export function SchemeCard({ scheme }: { scheme: Scheme }) {
  return (
    <Card className="flex flex-col h-full hover-elevate transition-shadow border-border hover:border-secondary/50 group">
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start mb-2 gap-2">
          <Badge variant="outline" className="bg-secondary/10 text-secondary hover:bg-secondary/20 font-semibold uppercase tracking-wider text-xs border-secondary/20">
            {scheme.category}
          </Badge>
          <div className="flex gap-1 flex-wrap justify-end">
            {scheme.isTrending && <Badge variant="destructive" className="font-bold">🔥 Trending</Badge>}
            {scheme.isNew && <Badge className="bg-secondary hover:bg-secondary/90 font-bold">🆕 New</Badge>}
          </div>
        </div>
        <Link href={`/schemes/${scheme.id}`}>
          <CardTitle className="text-lg md:text-xl font-bold text-foreground group-hover:text-secondary transition-colors line-clamp-2">
            {scheme.title}
          </CardTitle>
        </Link>
        <div className="flex items-center text-muted-foreground mt-2 font-medium">
          <Landmark className="w-4 h-4 mr-1.5 shrink-0" />
          <span className="truncate">{scheme.ministry}</span>
        </div>
      </CardHeader>
      <CardContent className="flex-1 space-y-3 text-sm">
        <div className="flex items-start text-muted-foreground">
          <Users2 className="w-4 h-4 mr-2 shrink-0 mt-0.5 text-secondary" />
          <span className="line-clamp-2"><span className="font-semibold text-foreground">Beneficiaries:</span> {scheme.beneficiaries}</span>
        </div>
        <div className="flex items-start text-muted-foreground">
          <IndianRupee className="w-4 h-4 mr-2 shrink-0 mt-0.5 text-secondary" />
          <span className="line-clamp-2"><span className="font-semibold text-foreground">Benefits:</span> {scheme.benefit}</span>
        </div>
      </CardContent>
      <CardFooter className="pt-4 border-t border-border/50">
        <Link href={`/schemes/${scheme.id}`} className="text-sm font-bold text-secondary hover:underline w-full text-center">
          View Details & Apply →
        </Link>
      </CardFooter>
    </Card>
  );
}
