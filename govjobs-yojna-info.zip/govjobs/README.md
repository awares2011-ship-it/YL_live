# GovJobs & Yojna Info Portal
**Sarkari Naukri aur Yojna ki Poori Jankari — Har 48 Ghante Update**

Developed by **Breakout Trade** | Production-ready Firebase portal for Indian government jobs & schemes.

---

## 🚀 Quick Deploy

```bash
# Step 1: Prerequisites
npm install -g firebase-tools

# Step 2: Firebase Login & Init
firebase login
firebase use --add   # select your project

# Step 3: Install Function Dependencies
cd functions && npm install && cd ..

# Step 4: Set Environment Variables
firebase functions:config:set \
  adsense.client="ca-pub-YOUR_ADSENSE_PUBLISHER_ID" \
  ga.id="G-YOUR_GA4_MEASUREMENT_ID" \
  app.base_url="https://govjobsyojnainfo.in"

# Step 5: Deploy Everything
firebase deploy

# Step 6: Custom Domain
# Firebase Console → Hosting → Add custom domain → govjobsyojnainfo.in
# Add DNS A records at your registrar as shown in console

# Step 7: Google Search Console
# Add property → verify via meta tag → submit sitemap URL
# https://govjobsyojnainfo.in/sitemap.xml

# Step 8: AdSense Application
# Requirements before applying:
# - 20+ unique blog posts live
# - Privacy Policy + Disclaimer + Contact pages live
# - Site live for minimum 2–3 weeks
# Apply at: https://www.google.com/adsense/start/

# Step 9: After AdSense Approval
# Replace in ALL html files:
#   YOUR_ADSENSE_PUBLISHER_ID → your actual publisher ID
#   YOUR_AD_SLOT_ID_1 through YOUR_AD_SLOT_ID_6 → actual slot IDs
# Enable Auto Ads in AdSense dashboard for extra revenue
```

---

## 📁 Project Structure

```
govjobs-yojna-info/
├── firebase.json               ← Hosting + Functions config
├── .firebaserc                 ← Project alias
├── firestore.rules             ← Security rules
├── firestore.indexes.json      ← Composite indexes
├── .env.example                ← Environment template
├── README.md
├── public/
│   ├── index.html              ← Homepage
│   ├── jobs.html               ← Govt Jobs listing
│   ├── yojana.html             ← Sarkari Yojana listing
│   ├── news.html               ← State News
│   ├── blog/
│   │   ├── index.html          ← Blog listing
│   │   └── post.html           ← Blog post template
│   ├── state/[state].html      ← State template
│   ├── about.html
│   ├── contact.html
│   ├── privacy-policy.html
│   ├── terms-of-service.html
│   ├── disclaimer.html
│   ├── 404.html
│   ├── sitemap.xml
│   ├── robots.txt
│   ├── manifest.json
│   ├── sw.js
│   ├── css/style.css
│   └── js/
│       ├── app.js
│       ├── feed.js
│       ├── search.js
│       ├── i18n.js
│       ├── ticker.js
│       └── analytics.js
├── functions/
│   ├── index.js
│   ├── feedFetcher.js
│   ├── blogGenerator.js
│   ├── sitemapGenerator.js
│   └── package.json
└── translations/
    ├── en.json  hi.json  mr.json  gu.json  ta.json
    ├── te.json  kn.json  bn.json  pa.json  ml.json
```

---

## 🔑 API Keys to Replace

| Placeholder | Where to get it |
|---|---|
| `YOUR_FIREBASE_PROJECT_ID` | Firebase Console → Project Settings |
| `YOUR_FIREBASE_API_KEY` | Firebase Console → Project Settings → Web API Key |
| `YOUR_ADSENSE_PUBLISHER_ID` | AdSense Dashboard → Account → Publisher ID |
| `YOUR_AD_SLOT_ID_1` through `_6` | AdSense → Ads → By ad unit |
| `YOUR_GA4_MEASUREMENT_ID` | Google Analytics → Admin → Data Streams |

---

## 💰 Revenue Projections

| Traffic | Daily Pageviews | Est. Monthly Revenue |
|---|---|---|
| 5,000/day | 12,500 | ₹30,000–₹56,000 |
| 10,000/day | 25,000 | ₹60,000–₹1,12,500 |
| 25,000/day | 62,500 | ₹1,50,000–₹2,81,000 |
| 40,000/day | 1,00,000 | ₹2,40,000–₹4,50,000 |
| 60,000/day | 1,50,000 | ₹3,60,000–₹6,75,000 |

*Based on India RPM of ₹80–₹150. High-CPC keywords (UPSC, bank jobs, PM Yojana) push RPM higher.*

---

## 🌐 Supported Languages

English | हिंदी | मराठी | ગુજરાતી | தமிழ் | తెలుగు | ಕನ್ನಡ | বাংলা | ਪੰਜਾਬੀ | മലയാളം

---

## ⚙️ Firebase Collections

| Collection | Purpose |
|---|---|
| `feeds` | All RSS-parsed job/yojana/news items |
| `blogs` | Auto-generated + manual blog posts |
| `latestUpdates` | Top 10 items for ticker bar |
| `cache` | API response cache (2hr TTL) |
| `stats` | Aggregated counts per category |

---

## ⚠️ Disclaimer

GovJobs & Yojna Info is NOT an official government website. All content is for informational purposes only. Always verify from official government sources.

**Developed by Breakout Trade** | © 2026
