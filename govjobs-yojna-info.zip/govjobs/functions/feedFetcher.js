/**
 * GovJobs & Yojna Info — feedFetcher.js
 * RSS feed fetcher, parser, and Firestore writer
 * Developed by Breakout Trade
 */

const { XMLParser } = require('fast-xml-parser');
const fetch = (...args) => import('node-fetch').then(({ default: f }) => f(...args));
const admin = require('firebase-admin');

// ─── RSS Feed Sources ────────────────────────────────────────
const RSS_FEEDS = [
  // JOBS
  { url: 'https://www.safalta.com/rss/other-govt-jobs.xml', type: 'job', region: 'central', lang: 'en', source: 'Safalta' },
  { url: 'https://pib.gov.in/RssMain.aspx?ModId=6&Lang=1&Regid=3', type: 'job', region: 'central', lang: 'en', source: 'PIB Central' },

  // YOJANA
  { url: 'https://services.india.gov.in/feed/index?ln=en', type: 'yojana', region: 'central', lang: 'en', source: 'India.gov.in' },
  { url: 'https://www.safalta.com/rss/other-govt-jobs.xml', type: 'yojana', region: 'central', lang: 'en', source: 'Safalta Yojana' },

  // STATE NEWS (PIB by Regid)
  { url: 'https://pib.gov.in/RssMain.aspx?ModId=6&Lang=1&Regid=3',  type: 'news', region: 'central',      lang: 'en', source: 'PIB Central' },
  { url: 'https://pib.gov.in/RssMain.aspx?ModId=6&Lang=1&Regid=13', type: 'news', region: 'maharashtra',  lang: 'mr', source: 'PIB Maharashtra' },
  { url: 'https://pib.gov.in/RssMain.aspx?ModId=6&Lang=1&Regid=17', type: 'news', region: 'rajasthan',    lang: 'hi', source: 'PIB Rajasthan' },
  { url: 'https://pib.gov.in/RssMain.aspx?ModId=6&Lang=1&Regid=25', type: 'news', region: 'up',           lang: 'hi', source: 'PIB UP' },
  { url: 'https://pib.gov.in/RssMain.aspx?ModId=6&Lang=1&Regid=8',  type: 'news', region: 'gujarat',      lang: 'gu', source: 'PIB Gujarat' },
  { url: 'https://pib.gov.in/RssMain.aspx?ModId=6&Lang=1&Regid=22', type: 'news', region: 'tamilnadu',    lang: 'ta', source: 'PIB Tamil Nadu' },
  { url: 'https://pib.gov.in/RssMain.aspx?ModId=6&Lang=1&Regid=10', type: 'news', region: 'karnataka',    lang: 'kn', source: 'PIB Karnataka' },
  { url: 'https://pib.gov.in/RssMain.aspx?ModId=6&Lang=1&Regid=28', type: 'news', region: 'westbengal',   lang: 'bn', source: 'PIB West Bengal' },
  { url: 'https://pib.gov.in/RssMain.aspx?ModId=6&Lang=1&Regid=4',  type: 'news', region: 'bihar',        lang: 'hi', source: 'PIB Bihar' },
  { url: 'https://pib.gov.in/RssMain.aspx?ModId=6&Lang=1&Regid=16', type: 'news', region: 'punjab',       lang: 'pa', source: 'PIB Punjab' },
  { url: 'https://pib.gov.in/RssMain.aspx?ModId=6&Lang=1&Regid=12', type: 'news', region: 'mp',           lang: 'hi', source: 'PIB MP' },
  { url: 'https://pib.gov.in/RssMain.aspx?ModId=6&Lang=1&Regid=2',  type: 'news', region: 'ap',           lang: 'te', source: 'PIB AP' },
  { url: 'https://pib.gov.in/RssMain.aspx?ModId=6&Lang=1&Regid=23', type: 'news', region: 'telangana',    lang: 'te', source: 'PIB Telangana' },
  { url: 'https://pib.gov.in/RssMain.aspx?ModId=6&Lang=1&Regid=11', type: 'news', region: 'kerala',       lang: 'ml', source: 'PIB Kerala' },
  { url: 'https://pib.gov.in/RssMain.aspx?ModId=6&Lang=1&Regid=15', type: 'news', region: 'odisha',       lang: 'en', source: 'PIB Odisha' },
  { url: 'https://pib.gov.in/RssMain.aspx?ModId=6&Lang=1&Regid=9',  type: 'news', region: 'haryana',      lang: 'hi', source: 'PIB Haryana' },
  { url: 'https://pib.gov.in/RssMain.aspx?ModId=6&Lang=1&Regid=33', type: 'news', region: 'jharkhand',    lang: 'hi', source: 'PIB Jharkhand' },
  { url: 'https://pib.gov.in/RssMain.aspx?ModId=6&Lang=1&Regid=34', type: 'news', region: 'assam',        lang: 'en', source: 'PIB Assam' },
  { url: 'https://pib.gov.in/RssMain.aspx?ModId=6&Lang=1&Regid=35', type: 'news', region: 'chhattisgarh', lang: 'hi', source: 'PIB Chhattisgarh' },
];

const xmlParser = new XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: '@_',
  parseAttributeValue: true
});

// ─── Main Fetch Function ─────────────────────────────────────
async function fetchAllFeeds() {
  const db = admin.firestore();
  const now = new Date();
  const cutoff24h = new Date(now.getTime() - 24 * 60 * 60 * 1000);

  let totalSaved = 0;
  let allNewItems = [];

  // Fetch feeds in parallel batches of 5 to avoid rate limiting
  for (let i = 0; i < RSS_FEEDS.length; i += 5) {
    const batch = RSS_FEEDS.slice(i, i + 5);
    const results = await Promise.allSettled(batch.map(feed => fetchSingleFeed(feed)));

    for (let j = 0; j < results.length; j++) {
      const result = results[j];
      if (result.status === 'fulfilled' && Array.isArray(result.value)) {
        const items = result.value;
        const saved = await saveItemsBatch(db, items, cutoff24h);
        totalSaved += saved;
        // Collect new items for ticker
        const newItems = items.filter(item => new Date(item.pubDate) >= cutoff24h);
        allNewItems.push(...newItems);
      } else if (result.status === 'rejected') {
        console.warn(`Feed fetch failed (index ${i+j}):`, result.reason?.message);
      }
    }
  }

  // Update latest updates for ticker (top 10 newest)
  const tickerItems = allNewItems
    .sort((a, b) => new Date(b.pubDate) - new Date(a.pubDate))
    .slice(0, 10);
  await updateTickerItems(db, tickerItems);

  // Update stats
  await updateStats(db);

  console.log(`fetchAllFeeds complete: ${totalSaved} items saved`);
  return { saved: totalSaved };
}

// ─── Fetch Single RSS Feed ───────────────────────────────────
async function fetchSingleFeed(feedConfig) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8000);

  try {
    const res = await fetch(feedConfig.url, {
      signal: controller.signal,
      headers: { 'User-Agent': 'GovJobsYojnaInfo/1.0 (+https://govjobsyojnainfo.in)' }
    });
    clearTimeout(timeout);

    if (!res.ok) throw new Error(`HTTP ${res.status} for ${feedConfig.url}`);
    const xml = await res.text();
    return parseRSS(xml, feedConfig);
  } catch (err) {
    clearTimeout(timeout);
    if (err.name !== 'AbortError') {
      throw err;
    }
    throw new Error(`Timeout fetching ${feedConfig.url}`);
  }
}

// ─── Parse RSS XML ───────────────────────────────────────────
function parseRSS(xml, feedConfig) {
  try {
    const parsed = xmlParser.parse(xml);
    const channel = parsed?.rss?.channel || parsed?.feed;
    if (!channel) return [];

    const rawItems = channel.item || channel.entry || [];
    const items = Array.isArray(rawItems) ? rawItems : [rawItems];

    const seenTitles = new Set();
    const result = [];

    for (const item of items.slice(0, 15)) { // max 15 per feed
      const title = cleanText(item.title || item['dc:title'] || '');
      const link = cleanText(item.link || item.id || '');
      const desc = cleanText(item.description || item.summary || item.content || '');
      const pubDate = parseDate(item.pubDate || item.published || item.updated || '');

      if (!title || !link || seenTitles.has(title)) continue;
      seenTitles.add(title);

      result.push({
        type: feedConfig.type,
        region: feedConfig.region,
        lang: feedConfig.lang,
        source: feedConfig.source,
        title,
        link,
        desc: desc.substring(0, 500),
        pubDate: pubDate || new Date().toISOString(),
        isNew: false, // will be set on save
        createdAt: admin.firestore.FieldValue.serverTimestamp()
      });
    }

    return result;
  } catch (err) {
    console.warn('RSS parse error:', err.message);
    return [];
  }
}

// ─── Save Items Batch to Firestore ───────────────────────────
async function saveItemsBatch(db, items, cutoff24h) {
  if (!items || items.length === 0) return 0;

  const batch = db.batch();
  let count = 0;

  for (const item of items) {
    // Use link as unique ID (hashed for Firestore key compatibility)
    const docId = linkToId(item.link);
    const ref = db.collection('feeds').doc(docId);

    // Check if already exists to avoid duplicates
    const existing = await ref.get().catch(() => null);
    if (existing && existing.exists) continue;

    const pubDate = new Date(item.pubDate);
    const isNew = pubDate >= cutoff24h;

    batch.set(ref, { ...item, isNew, docId }, { merge: true });
    count++;

    if (count % 400 === 0) {
      await batch.commit().catch(console.error);
    }
  }

  await batch.commit().catch(console.error);
  return count;
}

// ─── Update Ticker Items ─────────────────────────────────────
async function updateTickerItems(db, items) {
  if (!items || items.length === 0) return;
  try {
    const batch = db.batch();
    // Clear and repopulate
    const snap = await db.collection('latestUpdates').limit(20).get();
    snap.docs.forEach(doc => batch.delete(doc.ref));

    items.slice(0, 10).forEach((item, idx) => {
      const ref = db.collection('latestUpdates').doc(`ticker_${idx}`);
      batch.set(ref, {
        title: item.title,
        link: item.link,
        type: item.type,
        region: item.region,
        pubDate: item.pubDate,
        updatedAt: admin.firestore.FieldValue.serverTimestamp()
      });
    });
    await batch.commit();
  } catch (err) {
    console.warn('updateTickerItems error:', err.message);
  }
}

// ─── Update Stats ────────────────────────────────────────────
async function updateStats(db) {
  try {
    const [jobs, yojanas, news] = await Promise.all([
      db.collection('feeds').where('type', '==', 'job').count().get(),
      db.collection('feeds').where('type', '==', 'yojana').count().get(),
      db.collection('feeds').where('type', '==', 'news').count().get()
    ]);
    const blogs = await db.collection('blogs').count().get().catch(() => ({ data: () => ({ count: 0 }) }));

    await db.collection('stats').doc('main').set({
      totalJobs: jobs.data().count,
      totalYojanas: yojanas.data().count,
      totalNews: news.data().count,
      totalBlogs: blogs.data().count,
      lastUpdated: admin.firestore.FieldValue.serverTimestamp()
    });
  } catch (err) {
    console.warn('updateStats error:', err.message);
  }
}

// ─── Helpers ─────────────────────────────────────────────────
function cleanText(str) {
  if (!str) return '';
  return String(str)
    .replace(/<[^>]+>/g, '') // strip HTML
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, ' ')
    .trim();
}

function parseDate(dateStr) {
  if (!dateStr) return null;
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return null;
    return d.toISOString();
  } catch (e) { return null; }
}

function linkToId(link) {
  if (!link) return `unknown_${Date.now()}`;
  // Create a safe Firestore ID from the URL
  return link
    .replace(/https?:\/\//g, '')
    .replace(/[^a-zA-Z0-9]/g, '_')
    .substring(0, 500);
}

module.exports = { fetchAllFeeds, RSS_FEEDS };
