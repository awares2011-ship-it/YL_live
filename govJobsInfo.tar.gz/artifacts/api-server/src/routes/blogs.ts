import { Router } from "express";
import { db } from "@workspace/db";
import { blogsTable } from "@workspace/db";
import { eq, desc, and, sql } from "drizzle-orm";
import {
  ListBlogsQueryParams,
  CreateBlogBody,
  GetBlogParams,
} from "@workspace/api-zod";

const router = Router();

router.get("/", async (req, res) => {
  const parsed = ListBlogsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    return res.status(400).json({ error: "Invalid query params" });
  }
  const { category, limit = 10, offset = 0 } = parsed.data;

  const conditions = [];
  if (category) conditions.push(eq(blogsTable.category, category));
  const where = conditions.length > 0 ? and(...conditions) : undefined;

  const [blogs, countResult] = await Promise.all([
    db.select().from(blogsTable).where(where).orderBy(desc(blogsTable.createdAt)).limit(limit).offset(offset),
    db.select({ count: sql<number>`count(*)` }).from(blogsTable).where(where),
  ]);

  return res.json({ blogs, total: Number(countResult[0]?.count ?? 0) });
});

router.post("/", async (req, res) => {
  const parsed = CreateBlogBody.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "Invalid body" });
  }
  const [blog] = await db.insert(blogsTable).values(parsed.data).returning();
  return res.status(201).json(blog);
});

router.get("/:id", async (req, res) => {
  const parsed = GetBlogParams.safeParse({ id: Number(req.params.id) });
  if (!parsed.success) {
    return res.status(400).json({ error: "Invalid id" });
  }
  const [blog] = await db.select().from(blogsTable).where(eq(blogsTable.id, parsed.data.id));
  if (!blog) return res.status(404).json({ error: "Not found" });
  await db.update(blogsTable).set({ viewCount: sql`${blogsTable.viewCount} + 1` }).where(eq(blogsTable.id, parsed.data.id));
  return res.json(blog);
});

export default router;
