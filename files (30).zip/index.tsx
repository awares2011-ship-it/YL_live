import { useParams, Link } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import AdSense from "@/components/adsense";
import { ChevronLeft, ExternalLink } from "lucide-react";
import {
  GraduateGovtJobs,
  TractorSubsidyScheme,
  CropInsuranceScheme,
  KisanCreditCard,
  PmYojanaList,
  WomenSchemesIndia,
  FarmerSchemesIndia,
} from "./pages-extra";
import {
  EmiCalculatorSeoPage,
  AgeCalculatorSeoPage,
  ImageCompressorSeoPage,
} from "./pages-tools";
import {
  PunjabJobs,
  RajasthanJobs,
  GujaratJobs,
  TamilNaduJobs,
  KarnatakaJobs,
  DelhiJobs,
} from "./pages-states";

const SEO_PAGES: Record<string, {
  title: string;
  metaDesc: string;
  h1: string;
  content: React.ReactNode;
}> = {
  "latest-govt-jobs-2026": {
    title: "Latest Government Jobs 2026 – Apply Now | India GovHub",
    metaDesc: "Find latest government jobs 2026 for Railway, SSC, Bank, Army, Police & State Govt. Updated daily with new vacancies. Apply online now!",
    h1: "Latest Government Jobs 2026 – Complete List",
    content: <LatestGovtJobs2026 />,
  },
  "10th-pass-govt-jobs": {
    title: "10th Pass Government Jobs 2026 – Sarkari Naukri for Matric Pass",
    metaDesc: "10th pass government jobs 2026 in Railway, Army, Police, SSC MTS. Get full list of sarkari naukri for 10th pass with salary and last date.",
    h1: "10th Pass Government Jobs 2026",
    content: <TenthPassJobs />,
  },
  "12th-pass-govt-jobs": {
    title: "12th Pass Government Jobs 2026 – Intermediate Sarkari Naukri",
    metaDesc: "Best 12th pass government jobs 2026 for SSC CHSL, Railway, Bank Clerk, Police. Salary up to Rs 50,000. Apply online today.",
    h1: "12th Pass Government Jobs 2026",
    content: <TwelfthPassJobs />,
  },
  "railway-jobs-2026": {
    title: "Railway Jobs 2026 – RRB Group D, NTPC, ALP Recruitment",
    metaDesc: "Indian Railway jobs 2026: RRB Group D 1 lakh vacancies, NTPC, ALP, RPF Constable. 10th/12th pass eligible. Apply at indianrailways.gov.in",
    h1: "Railway Jobs 2026 – RRB Recruitment",
    content: <RailwayJobs2026 />,
  },
  "bank-jobs-2026": {
    title: "Bank Jobs 2026 – SBI, IBPS, RBI Bank Recruitment | Apply Now",
    metaDesc: "Bank jobs 2026: SBI Clerk 13735 posts, IBPS PO, RBI Grade B. Salary up to Rs 1 lakh. Apply for bank government jobs 2026 today!",
    h1: "Bank Jobs 2026 – Complete Bank Recruitment Guide",
    content: <BankJobs2026 />,
  },
  "ssc-jobs-2026": {
    title: "SSC Jobs 2026 – CGL, CHSL, MTS, CPO Recruitment | SSC Bharti",
    metaDesc: "SSC recruitment 2026 notification for CGL, CHSL, MTS, CPO, GD Constable. 10th/12th/Graduate eligible. Apply at ssc.nic.in",
    h1: "SSC Jobs 2026 – Staff Selection Commission Recruitment",
    content: <SscJobs2026 />,
  },
  "pm-kisan-yojana": {
    title: "PM Kisan Yojana 2026 – Rs 6000 Benefit, Registration & Status",
    metaDesc: "PM Kisan Samman Nidhi Yojana 2026: Get Rs 6000 per year. Check beneficiary status, 17th installment date, registration process at pmkisan.gov.in",
    h1: "PM Kisan Samman Nidhi Yojana 2026 – Complete Guide",
    content: <PmKisanYojana />,
  },
  "pm-kisan-status-check": {
    title: "PM Kisan Status Check 2026 – Beneficiary List & Payment Status",
    metaDesc: "Check PM Kisan status 2026 online at pmkisan.gov.in. Verify your name in beneficiary list, check installment payment status and resolve issues.",
    h1: "PM Kisan Status Check 2026 – How to Check Online",
    content: <PmKisanStatusCheck />,
  },
  "maharashtra-govt-jobs": {
    title: "Maharashtra Government Jobs 2026 – MPSC, Police, PSC Recruitment",
    metaDesc: "Maharashtra government jobs 2026: MPSC, Maharashtra Police, PSC, Zilla Parishad. Latest sarkari naukri in Maharashtra with salary details.",
    h1: "Maharashtra Government Jobs 2026",
    content: <MaharashtraJobs />,
  },
  "up-govt-jobs": {
    title: "UP Government Jobs 2026 – UPPSC, UP Police, UPTET Recruitment",
    metaDesc: "Uttar Pradesh government jobs 2026: UP Police, UPPSC, UPSSC, UPTET. Largest state govt recruitment. Apply online for UP Sarkari Naukri 2026.",
    h1: "Uttar Pradesh Government Jobs 2026",
    content: <UpJobs />,
  },
  "bihar-govt-jobs": {
    title: "Bihar Government Jobs 2026 – BPSC, Bihar Police, BSSC Recruitment",
    metaDesc: "Bihar government jobs 2026: BPSC, Bihar Police, BSSC, BTSC recruitment. Latest sarkari naukri in Bihar 2026 with complete details.",
    h1: "Bihar Government Jobs 2026",
    content: <BiharJobs />,
  },
  "graduate-govt-jobs": {
    title: "🎓 Graduate Government Jobs 2026 – UPSC, SSC, Bank, PSU Vacancies",
    metaDesc: "Graduate government jobs 2026: UPSC IAS, SSC CGL 17727 posts, IBPS PO, RBI Grade B, PSU jobs. Salary up to ₹2.5 lakh.",
    h1: "Graduate Government Jobs 2026 – Complete List",
    content: <GraduateGovtJobs />,
  },
  "tractor-subsidy-scheme": {
    title: "🚜 PM Kisan Tractor Yojana 2026 – 50% Subsidy Apply Online",
    metaDesc: "Get 20-50% subsidy on tractor purchase under PM Kisan Tractor Yojana 2026. Eligibility, documents, state-wise apply process.",
    h1: "PM Kisan Tractor Yojana 2026 – Tractor Subsidy Scheme",
    content: <TractorSubsidyScheme />,
  },
  "crop-insurance-scheme": {
    title: "🌾 PM Fasal Bima Yojana 2026 – Crop Insurance Scheme Apply",
    metaDesc: "PMFBY 2026: Crop insurance at just 2% premium. How to apply, claim, documents. 5.5 crore farmers covered.",
    h1: "PM Fasal Bima Yojana 2026 – Crop Insurance Scheme Guide",
    content: <CropInsuranceScheme />,
  },
  "kisan-credit-card": {
    title: "🪙 Kisan Credit Card 2026 – Rs3 Lakh at 4% Interest Apply Now",
    metaDesc: "Kisan Credit Card KCC 2026: Get Rs3 lakh credit at 4% interest. Benefits, apply, documents, banks.",
    h1: "Kisan Credit Card KCC 2026 – Complete Guide",
    content: <KisanCreditCard />,
  },
  "pm-yojana-list": {
    title: "📋 PM Yojana List 2026 – All 100+ Government Schemes Benefits",
    metaDesc: "Complete PM Yojana list 2026: PM Kisan, PMAY, Ayushman Bharat, Ujjwala, Jan Dhan, Atal Pension. 100+ active schemes.",
    h1: "PM Yojana List 2026 – All Active Government Schemes",
    content: <PmYojanaList />,
  },
  "women-schemes-india": {
    title: "👩 Women Schemes India 2026 – Government Schemes for Women",
    metaDesc: "Government schemes for women 2026: PM Matru Vandana, Sukanya Samriddhi, Udyogini, JSY, Beti Bachao.",
    h1: "Government Schemes for Women India 2026",
    content: <WomenSchemesIndia />,
  },
  "farmer-schemes-india": {
    title: "🌾 Farmer Schemes India 2026 – 50+ Agriculture Schemes",
    metaDesc: "All farmer schemes 2026: PM Kisan, KCC, PMFBY, Tractor Subsidy. 14 crore farmers benefited.",
    h1: "Government Schemes for Farmers India 2026",
    content: <FarmerSchemesIndia />,
  },
  "emi-calculator": {
    title: "💰 EMI Calculator 2026 – Home Loan Car Loan EMI Online Free",
    metaDesc: "Free EMI calculator for home loan, car loan, personal loan 2026. Current bank rates. Calculate monthly payment instantly.",
    h1: "EMI Calculator 2026 – Calculate Loan EMI Online Free",
    content: <EmiCalculatorSeoPage />,
  },
  "age-calculator": {
    title: "📅 Age Calculator 2026 – Check Age for Govt Job Eligibility",
    metaDesc: "Free age calculator for government job eligibility 2026. Age limits for SSC, Railway, UPSC, Police, Banking.",
    h1: "Age Calculator 2026 – Government Exam Eligibility Check",
    content: <AgeCalculatorSeoPage />,
  },
  "image-compressor": {
    title: "🖼️ Image Compressor – Compress Photo for Govt Job Application",
    metaDesc: "Free image compressor for government job applications 2026. Photo size for SSC, IBPS, RRB, UPSC. Compress JPG online.",
    h1: "Image Compressor – Compress Photo for Government Job Application",
    content: <ImageCompressorSeoPage />,
  },

  // ── More State Jobs ────────────────────────────────────────────────────────
  "punjab-govt-jobs": {
    title: "Punjab Government Jobs 2026 – PPSC, Police, Teacher Recruitment",
    metaDesc: "Punjab government jobs 2026: PPSC PCS, Punjab Police Constable, PSPCL, Teacher posts. 25,000+ vacancies. Apply online today.",
    h1: "Punjab Government Jobs 2026 – Complete Recruitment Guide",
    content: <PunjabJobs />,
  },
  "rajasthan-govt-jobs": {
    title: "🔥 Rajasthan Government Jobs 2026 – RPSC, Police, REET 75,000 Vacancies",
    metaDesc: "Rajasthan government jobs 2026: RPSC RAS 905 posts, Police 13,000+, REET 48,000 teacher posts. Apply online at rpsc.rajasthan.gov.in.",
    h1: "Rajasthan Government Jobs 2026 – RPSC, Police & Teacher Recruitment",
    content: <RajasthanJobs />,
  },
  "gujarat-govt-jobs": {
    title: "Gujarat Government Jobs 2026 – GPSC, Police, GSSSB Recruitment",
    metaDesc: "Gujarat government jobs 2026: GPSC, LRD Police 12,000+, GSSSB Clerk, Teacher TAT. Apply at Ojas portal ojas.gujarat.gov.in.",
    h1: "Gujarat Government Jobs 2026 – Complete Recruitment Guide",
    content: <GujaratJobs />,
  },
  "tamilnadu-govt-jobs": {
    title: "Tamil Nadu Government Jobs 2026 – TNPSC, Police, TANGEDCO",
    metaDesc: "Tamil Nadu government jobs 2026: TNPSC Group 1/2/4, TN Police 6700+, TANGEDCO, TRB Teachers. Apply at tnpscexams.in.",
    h1: "Tamil Nadu Government Jobs 2026 – TNPSC & State Recruitment",
    content: <TamilNaduJobs />,
  },
  "karnataka-govt-jobs": {
    title: "Karnataka Government Jobs 2026 – KPSC, Police, BESCOM Recruitment",
    metaDesc: "Karnataka government jobs 2026: KPSC 545 posts, Police 4000+, DSERT Teachers 15000+, BESCOM JE. Apply at kpsc.kar.nic.in.",
    h1: "Karnataka Government Jobs 2026 – Complete Recruitment Guide",
    content: <KarnatakaJobs />,
  },
  "delhi-govt-jobs": {
    title: "Delhi Government Jobs 2026 – DSSSB, Delhi Police, DMRC Recruitment",
    metaDesc: "Delhi government jobs 2026: DSSSB Teacher 7236+, Delhi Police Constable 5846, DMRC JE 1200. Apply now!",
    h1: "Delhi Government Jobs 2026 – DSSSB, Police & Central Govt Jobs",
    content: <DelhiJobs />,
  },
};

// All registered slugs for "People Also Read" sidebar
const ALL_SLUGS = Object.keys(SEO_PAGES);

function getRelatedSlugs(currentSlug: string): string[] {
  return ALL_SLUGS.filter((s) => s !== currentSlug).slice(0, 6);
}

export default function SeoPage() {
  const params = useParams<{ slug: string }>();
  const slug = params.slug;
  const page = SEO_PAGES[slug];

  if (!page) {
    return (
      <div className="text-center py-12">
        <p className="text-muted-foreground">Page not found.</p>
        <Link href="/seo">
          <Button variant="outline" className="mr-2 mt-4">Browse All Pages</Button>
        </Link>
        <Link href="/"><Button className="mt-4">Go Home</Button></Link>
      </div>
    );
  }

  const related = getRelatedSlugs(slug);

  // JSON-LD Schema for SEO
  const articleSchema = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: page.title,
    description: page.metaDesc,
    author: { "@type": "Organization", name: "India GovHub" },
    publisher: {
      "@type": "Organization",
      name: "India GovHub",
      logo: { "@type": "ImageObject", url: "https://india-govhub.web.app/favicon.svg" },
    },
    datePublished: "2026-01-01",
    dateModified: new Date().toISOString().split("T")[0],
    mainEntityOfPage: `https://india-govhub.web.app/seo/${slug}`,
  };

  return (
    <div className="max-w-5xl mx-auto">
      {/* Schema Markup */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(articleSchema) }}
      />
      <title>{page.title}</title>
      <meta name="description" content={page.metaDesc} />

      {/* Breadcrumb */}
      <nav className="flex items-center gap-2 text-xs text-muted-foreground mb-4">
        <Link href="/" className="hover:text-orange-600">Home</Link>
        <span>/</span>
        <Link href="/seo" className="hover:text-orange-600">SEO Hub</Link>
        <span>/</span>
        <span className="text-foreground font-medium truncate max-w-[200px]">{page.h1}</span>
      </nav>

      <AdSense slot="seo_top" style={{ height: 90 }} />

      <div className="grid lg:grid-cols-[1fr_280px] gap-6">
        {/* Main Content */}
        <main>
          <h1 className="text-2xl md:text-3xl font-extrabold mb-6 text-gray-900 leading-tight">{page.h1}</h1>
          {page.content}
          <AdSense slot="seo_bottom" />
        </main>

        {/* Sidebar */}
        <aside className="space-y-5">
          {/* Trending Now */}
          <div className="bg-orange-50 border border-orange-200 rounded-2xl p-4 sticky top-20">
            <h3 className="font-extrabold text-orange-800 mb-3 flex items-center gap-1 text-sm">
              🔥 Trending Now
            </h3>
            <div className="space-y-2">
              {[
                { label: "🚆 Railway Group D 2026", href: "/seo/railway-jobs-2026" },
                { label: "🌾 PM Kisan Status", href: "/seo/pm-kisan-status-check" },
                { label: "🏦 SBI Clerk 2026", href: "/seo/bank-jobs-2026" },
                { label: "👮 UP Police 2026", href: "/seo/up-govt-jobs" },
                { label: "📋 PM Yojana List", href: "/seo/pm-yojana-list" },
              ].map((t) => (
                <Link key={t.href} href={t.href}>
                  <div className="text-xs font-semibold text-orange-700 hover:text-orange-900 hover:underline cursor-pointer py-1 border-b border-orange-100 last:border-0">
                    {t.label}
                  </div>
                </Link>
              ))}
            </div>

            <h3 className="font-extrabold text-gray-700 mb-3 mt-5 text-sm">📚 People Also Read</h3>
            <div className="space-y-2">
              {related.map((s) => (
                <Link key={s} href={`/seo/${s}`}>
                  <div className="text-xs text-muted-foreground hover:text-orange-600 hover:underline cursor-pointer py-1 border-b border-gray-100 last:border-0 line-clamp-2">
                    → {SEO_PAGES[s]?.h1 || s}
                  </div>
                </Link>
              ))}
            </div>

            <div className="mt-5 space-y-2">
              <Link href="/jobs">
                <div className="w-full bg-orange-500 text-white text-center font-bold text-xs py-2.5 rounded-xl hover:bg-orange-600 transition-colors cursor-pointer">
                  🔍 Browse All Jobs
                </div>
              </Link>
              <Link href="/schemes">
                <div className="w-full bg-green-600 text-white text-center font-bold text-xs py-2.5 rounded-xl hover:bg-green-700 transition-colors cursor-pointer">
                  🌾 All Schemes
                </div>
              </Link>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}

function InternalLinks({ links }: { links: { label: string; href: string }[] }) {
  return (
    <div className="mt-6 p-4 bg-orange-50 rounded-xl border border-orange-100">
      <h3 className="font-bold text-orange-800 mb-2 text-sm">Related Links</h3>
      <div className="flex flex-wrap gap-2">
        {links.map((l) => (
          <Link key={l.href} href={l.href}>
            <Badge variant="outline" className="cursor-pointer border-orange-300 text-orange-700 hover:bg-orange-100 py-1 px-3">{l.label}</Badge>
          </Link>
        ))}
      </div>
    </div>
  );
}

function FaqSection({ faqs }: { faqs: { q: string; a: string }[] }) {
  return (
    <div className="mt-6 bg-white border border-border rounded-xl p-6">
      <h2 className="text-xl font-bold mb-4">Frequently Asked Questions</h2>
      <div className="space-y-4">
        {faqs.map((faq, i) => (
          <div key={i} className="border-l-4 border-orange-400 pl-4">
            <h3 className="font-semibold text-gray-800 mb-1">{faq.q}</h3>
            <p className="text-muted-foreground text-sm">{faq.a}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function LatestGovtJobs2026() {
  return (
    <div className="space-y-6">
      <p className="text-muted-foreground leading-relaxed">Government jobs remain the most sought-after career option in India in 2026. With job security, pension benefits, and monthly salaries, lakhs of candidates apply for sarkari naukri every year. In 2026, multiple departments have released bumper recruitment notifications offering over 5 lakh vacancies across central and state government departments.</p>

      <h2 className="text-xl font-bold">Top Government Job Notifications in 2026</h2>
      <div className="grid md:grid-cols-2 gap-4">
        {[
          { name: "Railway RRB Group D", vacancies: "1,03,769", qualification: "10th/ITI", link: "/jobs?category=railway" },
          { name: "SSC CHSL 2026", vacancies: "3,712", qualification: "12th Pass", link: "/jobs?category=ssc" },
          { name: "SBI Clerk 2026", vacancies: "13,735", qualification: "Graduate", link: "/jobs?category=bank" },
          { name: "Bihar Police Constable", vacancies: "21,391", qualification: "12th Pass", link: "/jobs?category=police" },
          { name: "Indian Army Agniveer", vacancies: "50,000", qualification: "10th/12th", link: "/jobs?category=defence" },
          { name: "IBPS PO 2026", vacancies: "4,455", qualification: "Graduate", link: "/jobs?category=bank" },
        ].map((job) => (
          <Link key={job.name} href={job.link}>
            <div className="p-4 bg-white border border-orange-200 rounded-xl hover:shadow-md transition-shadow cursor-pointer">
              <h3 className="font-bold text-gray-800">{job.name}</h3>
              <div className="flex justify-between mt-2 text-sm">
                <span className="text-muted-foreground">Vacancies: <b className="text-orange-600">{job.vacancies}</b></span>
                <span className="text-muted-foreground">{job.qualification}</span>
              </div>
            </div>
          </Link>
        ))}
      </div>

      <h2 className="text-xl font-bold">How to Find Latest Government Jobs</h2>
      <p className="text-muted-foreground">Stay updated with India GovHub for daily government job updates. We aggregate notifications from official websites including ssc.nic.in, ibps.in, indianrailways.gov.in, and state PSC websites. Subscribe to our notifications to never miss a government job opportunity.</p>

      <h2 className="text-xl font-bold">Preparation Tips for Government Exams</h2>
      <ul className="list-disc list-inside space-y-2 text-muted-foreground">
        <li>Study from NCERT books for foundation building</li>
        <li>Practice previous year question papers daily</li>
        <li>Read newspaper (Hindu/Indian Express) for current affairs</li>
        <li>Focus on Mathematics, Reasoning, and English for most exams</li>
        <li>Use official mock tests available on exam conducting body websites</li>
      </ul>

      <AdSense slot="seo_latest_jobs_inline" />

      <FaqSection faqs={[
        { q: "Which government job has the most vacancies in 2026?", a: "Indian Army Agniveer with 50,000 vacancies and RRB Group D with 1,03,769 vacancies have the highest number of openings in 2026." },
        { q: "What is the minimum qualification for government jobs?", a: "Most government jobs require at least 10th pass (matriculation). Railway Group D, Army Soldier GD, and CRPF Constable accept 10th pass candidates." },
        { q: "How to apply for central government jobs?", a: "Visit the official website of the recruiting body (SSC, IBPS, RRB, UPSC) and complete the online application. India GovHub provides direct links to official application pages." },
        { q: "What is the age limit for government jobs?", a: "Generally 18-27 years for most central government jobs. Age relaxation is available for SC/ST (5 years), OBC (3 years), PwD (10 years)." },
        { q: "Which is the best government job in India in 2026?", a: "IAS (UPSC Civil Services) is considered the most prestigious, while SBI PO, IBPS PO, SSC CGL, and Railway ALP are most popular for salary and stability." },
      ]} />

      <InternalLinks links={[
        { label: "Railway Jobs 2026", href: "/seo/railway-jobs-2026" },
        { label: "Bank Jobs 2026", href: "/seo/bank-jobs-2026" },
        { label: "SSC Jobs 2026", href: "/seo/ssc-jobs-2026" },
        { label: "10th Pass Jobs", href: "/seo/10th-pass-govt-jobs" },
        { label: "12th Pass Jobs", href: "/seo/12th-pass-govt-jobs" },
        { label: "PM Kisan Yojana", href: "/seo/pm-kisan-yojana" },
      ]} />
    </div>
  );
}

function TenthPassJobs() {
  return (
    <div className="space-y-6">
      <p className="text-muted-foreground leading-relaxed">Good news for 10th pass candidates! In 2026, there are thousands of government job opportunities that only require a Matriculation (10th standard) certificate. These jobs offer excellent salary packages ranging from Rs 18,000 to Rs 56,900 per month along with other government perks.</p>

      <h2 className="text-xl font-bold">Top 10th Pass Government Jobs 2026</h2>
      <div className="space-y-3">
        {[
          { name: "RRB Group D", org: "Railway Recruitment Board", vacancies: "1,03,769", salary: "18,000-56,900" },
          { name: "Indian Army Agniveer Soldier GD", org: "Indian Army", vacancies: "50,000", salary: "30,000-40,000" },
          { name: "CRPF Constable", org: "Central Reserve Police Force", vacancies: "9,212", salary: "21,700-69,100" },
          { name: "SSC MTS (Multi Tasking Staff)", org: "Staff Selection Commission", vacancies: "8,326", salary: "18,000-56,900" },
          { name: "BSF Constable", org: "Border Security Force", vacancies: "6,000+", salary: "21,700-69,100" },
        ].map((job) => (
          <div key={job.name} className="p-4 border border-green-200 bg-green-50 rounded-xl">
            <h3 className="font-bold">{job.name}</h3>
            <p className="text-sm text-muted-foreground">{job.org}</p>
            <div className="flex gap-4 mt-2 text-sm">
              <span>Vacancies: <b className="text-green-700">{job.vacancies}</b></span>
              <span>Salary: <b className="text-orange-600">₹{job.salary}</b></span>
            </div>
          </div>
        ))}
      </div>

      <AdSense slot="10th_pass_inline" />

      <FaqSection faqs={[
        { q: "Which 10th pass government jobs are best in 2026?", a: "Railway Group D with 1 lakh vacancies, Army Agniveer with 50,000 vacancies, and CRPF Constable are the best opportunities for 10th pass candidates in 2026." },
        { q: "What is the salary for 10th pass government jobs?", a: "Salary ranges from Rs 18,000 to Rs 56,900 for entry-level posts. With allowances like HRA, DA, and TA, the in-hand salary is much higher." },
        { q: "Is ITI certificate required for Railway Group D?", a: "For Railway Group D, either 10th pass (for Helper posts) or 10th pass with ITI certificate (for technical posts) is required depending on the trade." },
      ]} />

      <InternalLinks links={[
        { label: "All Jobs", href: "/jobs" },
        { label: "12th Pass Jobs", href: "/seo/12th-pass-govt-jobs" },
        { label: "Railway Jobs 2026", href: "/seo/railway-jobs-2026" },
        { label: "Latest Govt Jobs", href: "/seo/latest-govt-jobs-2026" },
        { label: "Age Calculator", href: "/tools/age-calculator" },
      ]} />
    </div>
  );
}

function TwelfthPassJobs() {
  return (
    <div className="space-y-6">
      <p className="text-muted-foreground leading-relaxed">Intermediate (12th pass) candidates have numerous government job opportunities in 2026. From SSC CHSL to Banking to Police jobs, the options are vast for 12th pass aspirants. These jobs offer stable career growth with salaries starting from Rs 19,900 per month.</p>

      <h2 className="text-xl font-bold">Best 12th Pass Government Jobs 2026</h2>
      <div className="space-y-3">
        {[
          { name: "SSC CHSL (LDC, JSA, PA)", org: "Staff Selection Commission", vacancies: "3,712", salary: "19,900-63,200" },
          { name: "Bihar Police Constable", org: "CSBC Bihar", vacancies: "21,391", salary: "21,700-69,100" },
          { name: "Indian Air Force Agniveer Vayu", org: "Indian Air Force", vacancies: "3,500+", salary: "30,000-40,000" },
          { name: "Navy AA/SSR", org: "Indian Navy", vacancies: "2,800+", salary: "21,700-69,100" },
          { name: "Railway Ticket Collector", org: "RRB", vacancies: "1,100", salary: "29,200-92,300" },
        ].map((job) => (
          <div key={job.name} className="p-4 border border-yellow-200 bg-yellow-50 rounded-xl">
            <h3 className="font-bold">{job.name}</h3>
            <p className="text-sm text-muted-foreground">{job.org}</p>
            <div className="flex gap-4 mt-2 text-sm">
              <span>Vacancies: <b className="text-yellow-700">{job.vacancies}</b></span>
              <span>Salary: <b className="text-orange-600">₹{job.salary}</b></span>
            </div>
          </div>
        ))}
      </div>

      <AdSense slot="12th_pass_inline" />

      <FaqSection faqs={[
        { q: "What is the best government job for 12th pass in 2026?", a: "SSC CHSL offers central government desk jobs with good salary. Bihar Police Constable has the most vacancies. For defence, IAF Agniveer Vayu is highly preferred." },
        { q: "Can 12th pass get bank jobs?", a: "Currently most bank jobs require graduation. However, bank security guard posts and some contract-based positions accept 12th pass candidates." },
        { q: "What is the age limit for SSC CHSL?", a: "SSC CHSL age limit is 18-27 years with relaxation: SC/ST +5 years, OBC +3 years, PwD +10 years. Verify through official ssc.nic.in." },
      ]} />

      <InternalLinks links={[
        { label: "SSC Jobs 2026", href: "/seo/ssc-jobs-2026" },
        { label: "10th Pass Jobs", href: "/seo/10th-pass-govt-jobs" },
        { label: "Latest Govt Jobs", href: "/seo/latest-govt-jobs-2026" },
        { label: "Bihar Jobs", href: "/seo/bihar-govt-jobs" },
        { label: "Age Calculator", href: "/tools/age-calculator" },
      ]} />
    </div>
  );
}

function RailwayJobs2026() {
  return (
    <div className="space-y-6">
      <p className="text-muted-foreground leading-relaxed">Indian Railways is one of the largest employers in the world. In 2026, Railway Recruitment Boards (RRBs) have released notifications for over 1.5 lakh vacancies across various categories. Railway jobs offer excellent job security, free travel passes, medical facilities, and housing — making them extremely popular among candidates.</p>

      <h2 className="text-xl font-bold">Railway Recruitment 2026 – Complete List</h2>
      <div className="space-y-3">
        {[
          { name: "RRB Group D", posts: "Track Maintainer, Helper, Porter", vacancies: "1,03,769", qual: "10th/ITI" },
          { name: "RRB NTPC", posts: "Junior Clerk, JSA, Accounts Clerk, TC", vacancies: "11,558", qual: "12th/Graduate" },
          { name: "RRB ALP", posts: "Assistant Loco Pilot, Technician", vacancies: "5,696", qual: "ITI/Diploma" },
          { name: "RPF Constable", posts: "Railway Protection Force Constable", vacancies: "4,208", qual: "10th Pass" },
        ].map((job) => (
          <div key={job.name} className="p-4 border border-orange-200 bg-orange-50 rounded-xl">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-bold text-orange-800">{job.name}</h3>
                <p className="text-sm text-muted-foreground">{job.posts}</p>
              </div>
              <Badge className="bg-orange-500 text-white">{job.vacancies}</Badge>
            </div>
            <p className="text-sm mt-2">Qualification: <b>{job.qual}</b></p>
          </div>
        ))}
      </div>

      <h2 className="text-xl font-bold">Railway Exam Preparation Guide</h2>
      <p className="text-muted-foreground">Railway exams are conducted in Computer Based Test (CBT) format. Focus on Mathematics (40%), General Intelligence & Reasoning (30%), General Science (15%), and General Awareness (15%). Practice railway mock tests at indianrailways.gov.in and use RRB previous year papers for best results.</p>

      <AdSense slot="railway_inline" />

      <FaqSection faqs={[
        { q: "How many railway vacancies are there in 2026?", a: "Indian Railways has announced over 1.5 lakh vacancies in 2026 including 1,03,769 Group D, 11,558 NTPC, 5,696 ALP/Technician and 4,208 RPF Constable posts." },
        { q: "What is the salary for Railway Group D in 2026?", a: "Railway Group D salary is Rs 18,000-56,900 per month (Level 1 Pay Matrix) plus allowances like HRA, DA, TA making effective in-hand Rs 22,000-28,000." },
        { q: "How to apply for Railway jobs 2026?", a: "Apply online at indianrailways.gov.in or the specific RRB zone website. Registration requires Aadhaar, email, phone number, educational certificates, and caste certificate if applicable." },
      ]} />

      <InternalLinks links={[
        { label: "All Railway Jobs", href: "/jobs?category=railway" },
        { label: "10th Pass Jobs", href: "/seo/10th-pass-govt-jobs" },
        { label: "Latest Govt Jobs 2026", href: "/seo/latest-govt-jobs-2026" },
        { label: "SSC Jobs 2026", href: "/seo/ssc-jobs-2026" },
        { label: "Age Calculator", href: "/tools/age-calculator" },
      ]} />
    </div>
  );
}

function BankJobs2026() {
  return (
    <div className="space-y-6">
      <p className="text-muted-foreground leading-relaxed">Banking sector is one of the most preferred career choices for graduates in India. In 2026, SBI, IBPS, RBI, and various other banks have released recruitment notifications for Clerk, PO, SO, and Manager posts. Bank jobs offer attractive salaries, career growth, and excellent work-life balance.</p>

      <h2 className="text-xl font-bold">Major Bank Recruitment 2026</h2>
      <div className="space-y-3">
        {[
          { name: "SBI Clerk 2026", posts: "Junior Associates (Customer Support & Sales)", vacancies: "13,735", salary: "17,900-47,920" },
          { name: "IBPS PO 2026", posts: "Probationary Officer in 12 PSBs", vacancies: "4,455", salary: "36,000-63,840" },
          { name: "IBPS Clerk 2026", posts: "Clerical Cadre in PSBs", vacancies: "6,128", salary: "17,900-47,920" },
          { name: "RBI Grade B 2026", posts: "Officers in Grade B (DR-General)", vacancies: "291", salary: "55,000-1,10,000" },
          { name: "Bank of India PO", posts: "Probationary Officer", vacancies: "500", salary: "36,000-63,840" },
        ].map((job) => (
          <div key={job.name} className="p-4 border border-green-200 bg-green-50 rounded-xl">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-bold text-green-800">{job.name}</h3>
                <p className="text-sm text-muted-foreground">{job.posts}</p>
              </div>
              <Badge className="bg-green-600 text-white">{job.vacancies}</Badge>
            </div>
            <p className="text-sm mt-2">Salary: <b className="text-orange-600">₹{job.salary}</b>/month</p>
          </div>
        ))}
      </div>

      <AdSense slot="bank_inline" />

      <FaqSection faqs={[
        { q: "What qualification is needed for bank jobs?", a: "Graduation in any stream is required for most bank jobs (Clerk, PO). RBI Grade B requires graduation with 60% marks. CIBIL score doesn't matter for government bank jobs." },
        { q: "Which is better SBI or IBPS bank jobs?", a: "SBI is a standalone exam while IBPS recruits for 12 public sector banks. SBI salary is slightly higher. Both offer excellent career growth and job security." },
        { q: "What is IBPS CRP?", a: "IBPS Common Recruitment Process (CRP) is conducted for Clerk, PO, SO, and RRB posts in participating banks. Score is valid for one year and used for multiple bank selections." },
      ]} />

      <InternalLinks links={[
        { label: "All Bank Jobs", href: "/jobs?category=bank" },
        { label: "Latest Govt Jobs 2026", href: "/seo/latest-govt-jobs-2026" },
        { label: "Graduate Jobs", href: "/jobs?qualification=graduate" },
        { label: "EMI Calculator", href: "/tools/emi-calculator" },
        { label: "Age Calculator", href: "/tools/age-calculator" },
      ]} />
    </div>
  );
}

function SscJobs2026() {
  return (
    <div className="space-y-6">
      <p className="text-muted-foreground leading-relaxed">Staff Selection Commission (SSC) is the premier recruitment body for central government jobs in India. SSC conducts various exams for different posts catering to candidates from 10th pass to graduates. In 2026, SSC has announced recruitments for CGL, CHSL, MTS, CPO, GD Constable, and JE posts.</p>

      <h2 className="text-xl font-bold">SSC Exams 2026 – Complete Schedule</h2>
      <div className="space-y-3">
        {[
          { name: "SSC CGL 2026", posts: "Group B & C officers in Ministries", vacancies: "17,727", qual: "Graduate" },
          { name: "SSC CHSL 2026", posts: "LDC, JSA, PA, SA, DEO", vacancies: "3,712", qual: "12th Pass" },
          { name: "SSC MTS 2026", posts: "Multi Tasking (Non-Technical) Staff", vacancies: "8,326", qual: "10th Pass" },
          { name: "SSC CPO 2026", posts: "Sub Inspector in CAPF, Delhi Police", vacancies: "4,187", qual: "Graduate" },
          { name: "SSC GD Constable 2026", posts: "Constable in CAPF, NIA, SSF", vacancies: "39,481", qual: "10th Pass" },
        ].map((job) => (
          <div key={job.name} className="p-4 border border-yellow-200 bg-yellow-50 rounded-xl">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-bold text-yellow-800">{job.name}</h3>
                <p className="text-sm text-muted-foreground">{job.posts}</p>
              </div>
              <Badge className="bg-yellow-500 text-white">{job.vacancies}</Badge>
            </div>
            <p className="text-sm mt-2">Qualification: <b>{job.qual}</b></p>
          </div>
        ))}
      </div>

      <AdSense slot="ssc_inline" />

      <FaqSection faqs={[
        { q: "What is the difference between SSC CGL and CHSL?", a: "SSC CGL requires graduation and recruits for higher Group B & C posts with salary up to Rs 2.08 lakh. SSC CHSL requires 12th pass and recruits for lower division posts with salary up to Rs 63,200." },
        { q: "When does SSC release its annual calendar?", a: "SSC releases the annual examination calendar in December/January. The 2026 calendar is available at ssc.nic.in with tentative dates for all exams throughout the year." },
        { q: "How to prepare for SSC CGL in 3 months?", a: "Focus on Quant (previous year questions), English (grammar rules and reading comprehension), Reasoning (puzzles and coding-decoding), and GK (current affairs + static GK). Practice 2 mock tests daily." },
      ]} />

      <InternalLinks links={[
        { label: "All SSC Jobs", href: "/jobs?category=ssc" },
        { label: "10th Pass Jobs", href: "/seo/10th-pass-govt-jobs" },
        { label: "12th Pass Jobs", href: "/seo/12th-pass-govt-jobs" },
        { label: "Latest Govt Jobs 2026", href: "/seo/latest-govt-jobs-2026" },
        { label: "Age Calculator", href: "/tools/age-calculator" },
      ]} />
    </div>
  );
}

function PmKisanYojana() {
  return (
    <div className="space-y-6">
      <p className="text-muted-foreground leading-relaxed">Pradhan Mantri Kisan Samman Nidhi (PM-KISAN) is a central sector scheme providing financial support of Rs 6,000 per year to small and marginal land-holding farmer families across India. The scheme ensures farmers get supplemental income for their agricultural and domestic needs. Since its launch in February 2019, over 11 crore farmers have benefited from this scheme.</p>

      <div className="grid md:grid-cols-3 gap-4">
        <div className="bg-green-50 border border-green-200 rounded-xl p-4 text-center">
          <div className="text-3xl font-black text-green-700">₹6,000</div>
          <p className="text-sm text-muted-foreground mt-1">Annual Benefit</p>
        </div>
        <div className="bg-orange-50 border border-orange-200 rounded-xl p-4 text-center">
          <div className="text-3xl font-black text-orange-600">11 Cr+</div>
          <p className="text-sm text-muted-foreground mt-1">Farmers Benefited</p>
        </div>
        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4 text-center">
          <div className="text-3xl font-black text-yellow-700">₹2,000</div>
          <p className="text-sm text-muted-foreground mt-1">Per Installment</p>
        </div>
      </div>

      <h2 className="text-xl font-bold">PM Kisan Eligibility 2026</h2>
      <ul className="list-disc list-inside space-y-2 text-muted-foreground">
        <li>Small and marginal farmers with less than 2 hectares of cultivable land</li>
        <li>Family consisting of husband, wife, and minor children</li>
        <li>Must have valid Aadhaar card linked to bank account</li>
        <li>Not applicable to income tax payers, institutional land holders, government employees, pensioners (above Rs 10,000/month)</li>
      </ul>

      <h2 className="text-xl font-bold">How to Register for PM Kisan</h2>
      <div className="space-y-3">
        {["Visit pmkisan.gov.in official website", "Click on 'New Farmer Registration' button", "Enter your Aadhaar number and state", "Fill personal and land details carefully", "Link your bank account with Aadhaar", "Submit and wait for state government verification"].map((step, i) => (
          <div key={i} className="flex gap-3 items-start">
            <span className="w-7 h-7 rounded-full bg-green-500 text-white flex items-center justify-center font-bold text-sm shrink-0">{i + 1}</span>
            <p className="text-muted-foreground pt-0.5">{step}</p>
          </div>
        ))}
      </div>

      <AdSense slot="pm_kisan_inline" />

      <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
        <h3 className="font-bold text-yellow-800 mb-2">PM Kisan eKYC is Mandatory</h3>
        <p className="text-sm text-muted-foreground">All PM Kisan beneficiaries must complete eKYC to continue receiving benefits. Visit nearest CSC (Common Service Center) or complete OTP-based eKYC at pmkisan.gov.in using your Aadhaar linked mobile number.</p>
      </div>

      <FaqSection faqs={[
        { q: "When is PM Kisan 17th installment date?", a: "The 17th installment of PM Kisan is expected in early 2026. The government typically releases installments every 4 months. Check pmkisan.gov.in for official announcement." },
        { q: "How to check PM Kisan payment status?", a: "Visit pmkisan.gov.in → Beneficiary Status → Enter your Aadhaar/Account Number → View payment history and pending status." },
        { q: "My PM Kisan payment failed. What to do?", a: "Common reasons: Bank account not linked with Aadhaar, incorrect bank details, eKYC not done. Visit nearest CSC or agriculture office to rectify. Contact PM Kisan helpline: 155261." },
        { q: "Can tenant farmers get PM Kisan benefit?", a: "No, PM Kisan is only for farmers who own agricultural land. Tenant farmers and sharecroppers are not eligible under PM Kisan." },
      ]} />

      <InternalLinks links={[
        { label: "PM Kisan Status Check", href: "/seo/pm-kisan-status-check" },
        { label: "All Kisan Schemes", href: "/schemes?category=kisan" },
        { label: "All Schemes", href: "/schemes" },
        { label: "Latest Govt Jobs", href: "/seo/latest-govt-jobs-2026" },
        { label: "EMI Calculator", href: "/tools/emi-calculator" },
      ]} />
    </div>
  );
}

function PmKisanStatusCheck() {
  return (
    <div className="space-y-6">
      <p className="text-muted-foreground leading-relaxed">PM Kisan beneficiaries can check their payment status online in just a few minutes. The government has made it very easy to verify if your name is in the beneficiary list and track your installment payments. This guide explains the complete step-by-step process to check PM Kisan status in 2026.</p>

      <h2 className="text-xl font-bold">How to Check PM Kisan Status Online</h2>
      <div className="space-y-3">
        {[
          "Open browser and go to pmkisan.gov.in",
          "Click on 'Beneficiary Status' in the Farmers Corner menu",
          "Choose to search by Aadhaar Number, Account Number, or Mobile Number",
          "Enter your selected detail and click 'Get Data'",
          "View your complete payment history with installment dates and amounts",
        ].map((step, i) => (
          <div key={i} className="flex gap-3 items-start p-3 bg-green-50 border border-green-200 rounded-xl">
            <span className="w-7 h-7 rounded-full bg-green-500 text-white flex items-center justify-center font-bold text-sm shrink-0">{i + 1}</span>
            <p className="text-muted-foreground">{step}</p>
          </div>
        ))}
      </div>

      <a href="https://pmkisan.gov.in" target="_blank" rel="noopener noreferrer">
        <Button className="bg-green-600 hover:bg-green-700 text-white gap-2">
          <ExternalLink className="w-4 h-4" /> Go to PM Kisan Official Website
        </Button>
      </a>

      <h2 className="text-xl font-bold">Common PM Kisan Payment Issues & Solutions</h2>
      <div className="space-y-3">
        {[
          { issue: "Name not in beneficiary list", solution: "Contact local Patwari or Agriculture Officer to add your name. Ensure land records are correct." },
          { issue: "Payment pending/failed", solution: "Check if bank account is Aadhaar-linked. Complete eKYC at CSC center. Update correct bank account details." },
          { issue: "Wrong amount received", solution: "Contact PM Kisan Helpline: 155261 or email pmkisan-ict@gov.in with your Aadhaar details." },
          { issue: "eKYC not done", solution: "Visit nearest CSC center or do OTP-based eKYC at pmkisan.gov.in. Mandatory for continuing benefits." },
        ].map((item, i) => (
          <div key={i} className="p-4 border border-orange-200 bg-orange-50 rounded-xl">
            <h3 className="font-bold text-orange-800 mb-1">Problem: {item.issue}</h3>
            <p className="text-sm text-muted-foreground">Solution: {item.solution}</p>
          </div>
        ))}
      </div>

      <AdSense slot="pm_kisan_status_inline" />

      <FaqSection faqs={[
        { q: "How to check if I am a PM Kisan beneficiary?", a: "Visit pmkisan.gov.in → Beneficiary Status → Search with Aadhaar, Bank Account, or Mobile Number → If your record shows, you are a registered beneficiary." },
        { q: "PM Kisan payment not received. What to do?", a: "First check status on website. If payment failed, rectify bank/Aadhaar linking issues. Complete eKYC. Contact helpline 155261. Contact local agriculture office if issue persists." },
        { q: "Can I check PM Kisan status on mobile?", a: "Yes, download the PM Kisan app from Google Play Store. You can check status, register complaints, and view payment history on the mobile app." },
      ]} />

      <InternalLinks links={[
        { label: "PM Kisan Yojana Guide", href: "/seo/pm-kisan-yojana" },
        { label: "All Kisan Schemes", href: "/schemes?category=kisan" },
        { label: "Latest Govt Jobs", href: "/seo/latest-govt-jobs-2026" },
        { label: "Age Calculator", href: "/tools/age-calculator" },
        { label: "All Schemes", href: "/schemes" },
      ]} />
    </div>
  );
}

function MaharashtraJobs() {
  return (
    <div className="space-y-6">
      <p className="text-muted-foreground leading-relaxed">Maharashtra is one of India's most economically advanced states with numerous government job opportunities across various departments. Maharashtra Public Service Commission (MPSC), Maharashtra Police, Maharashtra SSC Board, and various state departments recruit thousands of candidates every year. In 2026, over 50,000 government vacancies are available in Maharashtra.</p>

      <h2 className="text-xl font-bold">Top Maharashtra Government Jobs 2026</h2>
      <div className="space-y-3">
        {[
          { name: "MPSC State Service 2026", dept: "Maharashtra PSC", vacancies: "800", sal: "44,900-1,42,400" },
          { name: "Maharashtra Police Constable", dept: "Maharashtra Police", vacancies: "17,471", sal: "21,700-69,100" },
          { name: "Maharashtra ZP Teacher", dept: "Zilla Parishad", vacancies: "3,200", sal: "35,400-1,12,400" },
          { name: "MPSC Assistant", dept: "Maharashtra PSC", vacancies: "1,200", sal: "38,600-1,22,800" },
          { name: "MSRTC Bus Conductor", dept: "MSRTC", vacancies: "5,000", sal: "19,000-35,000" },
        ].map((job) => (
          <div key={job.name} className="p-4 border border-purple-200 bg-purple-50 rounded-xl">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-bold text-purple-800">{job.name}</h3>
                <p className="text-sm text-muted-foreground">{job.dept}</p>
              </div>
              <Badge className="bg-purple-600 text-white">{job.vacancies}</Badge>
            </div>
            <p className="text-sm mt-2">Salary: <b className="text-orange-600">₹{job.sal}</b></p>
          </div>
        ))}
      </div>

      <FaqSection faqs={[
        { q: "How to apply for MPSC jobs in Maharashtra?", a: "Visit mpsc.gov.in and register as a candidate. Apply for your desired post when notification is released. Language proficiency in Marathi is required for most MPSC posts." },
        { q: "Is Marathi language knowledge required for Maharashtra govt jobs?", a: "Yes, for state government jobs under Maharashtra, knowledge of Marathi language (reading, writing, speaking) is mandatory. MPSC exam includes Marathi language paper." },
      ]} />

      <InternalLinks links={[
        { label: "All State Jobs", href: "/jobs?category=state" },
        { label: "Latest Govt Jobs 2026", href: "/seo/latest-govt-jobs-2026" },
        { label: "UP Govt Jobs", href: "/seo/up-govt-jobs" },
        { label: "Bihar Govt Jobs", href: "/seo/bihar-govt-jobs" },
        { label: "Age Calculator", href: "/tools/age-calculator" },
      ]} />
    </div>
  );
}

function UpJobs() {
  return (
    <div className="space-y-6">
      <p className="text-muted-foreground leading-relaxed">Uttar Pradesh is India's most populous state and also one of the largest employers in the government sector. In 2026, UP government has released bumper recruitment for Police, UPPSC, UPSSC, and various other departments. Lakhs of candidates from UP and neighboring states compete for these prestigious sarkari jobs in Uttar Pradesh.</p>

      <h2 className="text-xl font-bold">Top UP Government Jobs 2026</h2>
      <div className="space-y-3">
        {[
          { name: "UP Police Constable 2026", dept: "Uttar Pradesh Police", vacancies: "60,244", sal: "21,700-69,100" },
          { name: "UPPSC PCS 2026", dept: "UP Public Service Commission", vacancies: "220", sal: "56,100-1,77,500" },
          { name: "UPSSC Lekhpal", dept: "UP Subordinate Services Commission", vacancies: "7,882", sal: "20,800-66,800" },
          { name: "UPTET 2026", dept: "UP Basic Education Board", vacancies: "75,000", sal: "35,400-1,12,400" },
          { name: "UPPCL Technician", dept: "UP Power Corporation Ltd", vacancies: "3,200", sal: "25,500-81,100" },
        ].map((job) => (
          <div key={job.name} className="p-4 border border-orange-200 bg-orange-50 rounded-xl">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-bold text-orange-800">{job.name}</h3>
                <p className="text-sm text-muted-foreground">{job.dept}</p>
              </div>
              <Badge className="bg-orange-500 text-white">{job.vacancies}</Badge>
            </div>
            <p className="text-sm mt-2">Salary: <b className="text-green-700">₹{job.sal}</b></p>
          </div>
        ))}
      </div>

      <AdSense slot="up_jobs_inline" />

      <FaqSection faqs={[
        { q: "How to apply for UP Police jobs?", a: "Visit uppbpb.gov.in for UP Police recruitment. Create account, fill online form, upload documents, pay application fee and take printout of application." },
        { q: "What is UPPSC PCS exam?", a: "UPPSC PCS (Provincial Civil Services) is UP's premier state service exam for posts like SDM, DSP, Tehsildar. Conducted in 3 stages: Preliminary, Main, and Interview." },
      ]} />

      <InternalLinks links={[
        { label: "All State Jobs", href: "/jobs?category=state" },
        { label: "Latest Govt Jobs 2026", href: "/seo/latest-govt-jobs-2026" },
        { label: "Bihar Jobs", href: "/seo/bihar-govt-jobs" },
        { label: "Maharashtra Jobs", href: "/seo/maharashtra-govt-jobs" },
        { label: "Age Calculator", href: "/tools/age-calculator" },
      ]} />
    </div>
  );
}

function BiharJobs() {
  return (
    <div className="space-y-6">
      <p className="text-muted-foreground leading-relaxed">Bihar government is one of the most active state governments in terms of recruitment in 2026. From Bihar Police to BPSC, BSSC to BTSC, thousands of government vacancies are available for Bihar residents. The state has released multiple mega recruitment drives offering stable government employment to lakhs of youth.</p>

      <h2 className="text-xl font-bold">Top Bihar Government Jobs 2026</h2>
      <div className="space-y-3">
        {[
          { name: "Bihar Police Constable 2026", dept: "CSBC Bihar", vacancies: "21,391", sal: "21,700-69,100" },
          { name: "BPSC 70th CCE", dept: "Bihar Public Service Commission", vacancies: "2,223", sal: "56,100-1,77,500" },
          { name: "BSSC Group D 2026", dept: "Bihar SSC", vacancies: "11,098", sal: "18,000-56,900" },
          { name: "Bihar Teacher BTET", dept: "Bihar Education Dept", vacancies: "1,70,461", sal: "35,400-1,12,400" },
          { name: "BTSC Health Dept", dept: "Bihar Technical Services Commission", vacancies: "2,664", sal: "25,500-81,100" },
        ].map((job) => (
          <div key={job.name} className="p-4 border border-green-200 bg-green-50 rounded-xl">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-bold text-green-800">{job.name}</h3>
                <p className="text-sm text-muted-foreground">{job.dept}</p>
              </div>
              <Badge className="bg-green-600 text-white">{job.vacancies}</Badge>
            </div>
            <p className="text-sm mt-2">Salary: <b className="text-orange-600">₹{job.sal}</b></p>
          </div>
        ))}
      </div>

      <FaqSection faqs={[
        { q: "How to apply for BPSC exam?", a: "Visit bpsc.bih.nic.in and register. Apply when notification is released. BPSC Preliminary exam, Main exam, and Interview are the three stages for civil services posts." },
        { q: "What is Bihar Police Constable selection process?", a: "Bihar Police Constable selection has Physical Efficiency Test (PET), Written Exam, and Document Verification. Apply through csbc.bih.nic.in when notification is open." },
      ]} />

      <InternalLinks links={[
        { label: "All State Jobs", href: "/jobs?category=state" },
        { label: "12th Pass Jobs", href: "/seo/12th-pass-govt-jobs" },
        { label: "Latest Govt Jobs 2026", href: "/seo/latest-govt-jobs-2026" },
        { label: "UP Jobs", href: "/seo/up-govt-jobs" },
        { label: "Maharashtra Jobs", href: "/seo/maharashtra-govt-jobs" },
      ]} />
    </div>
  );
}
