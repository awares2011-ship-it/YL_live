import { useEffect } from "react";
import { Link } from "wouter";
import { useListJobs, useListSchemes, useListBlogs, useGetSummary, useGetTrending } from "@workspace/api-client-react";
import { JobCard } from "@/components/JobCard";
import { SchemeCard } from "@/components/SchemeCard";
import { BlogCard } from "@/components/BlogCard";
import { Advertisement } from "@/components/Advertisement";
import { JobsTicker } from "@/components/JobsTicker";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowRight, Briefcase, Landmark, TrendingUp } from "lucide-react";
import { useI18n } from "@/lib/i18n";

export default function Home() {
  const { t } = useI18n();

  useEffect(() => {
    document.title = "govJobsInfo | Govt Jobs & Schemes 2026";
  }, []);

  const { data: summaryData } = useGetSummary();
  const { data: trendingData, isLoading: loadingTrending } = useGetTrending();
  const { data: jobsData, isLoading: loadingJobs } = useListJobs({ limit: 6 });
  const { data: schemesData, isLoading: loadingSchemes } = useListSchemes({ limit: 6 });
  const { data: blogsData, isLoading: loadingBlogs } = useListBlogs({ limit: 3 });

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="bg-accent text-accent-foreground py-12 md:py-20 relative overflow-hidden border-b-4 border-primary">
        <div className="absolute inset-0 opacity-5 bg-[url('https://images.unsplash.com/photo-1532375810709-75b1d0d6e141?q=80&w=2000&auto=format&fit=crop')] bg-cover bg-center" />
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold mb-6 leading-tight font-sans">
              {t.heroTitle1} <br className="hidden md:block" />
              <span className="text-primary">{t.heroTitle2}</span>
            </h1>
            <p className="text-xl md:text-2xl text-accent-foreground/80 mb-10 font-medium">
              {t.heroSubtitle}
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground font-bold text-lg h-14 px-8">
                <Link href="/jobs">
                  <Briefcase className="mr-2 h-5 w-5" />
                  {t.latestGovtJobs}
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="bg-accent-foreground/10 text-accent-foreground border-accent-foreground/20 hover:bg-accent-foreground/20 font-bold text-lg h-14 px-8">
                <Link href="/schemes">
                  <Landmark className="mr-2 h-5 w-5" />
                  {t.pmKisanYojana}
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Scrolling Jobs Ticker */}
      <JobsTicker />

      {/* Stats Bar */}
      <div className="bg-muted py-3 border-b border-border">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap justify-center md:justify-between items-center gap-4 text-sm font-semibold">
            {summaryData ? (
              <>
                <div className="flex items-center text-foreground/70">
                  <Briefcase className="w-4 h-4 mr-2 text-primary" />
                  <span>{t.totalJobs}: <span className="text-foreground font-bold">{summaryData.totalJobs}</span></span>
                </div>
                <div className="flex items-center text-foreground/70">
                  <Landmark className="w-4 h-4 mr-2 text-secondary" />
                  <span>{t.totalSchemes}: <span className="text-foreground font-bold">{summaryData.totalSchemes}</span></span>
                </div>
                <div className="flex items-center text-foreground/70">
                  <span className="flex h-2 w-2 rounded-full bg-primary mr-2" />
                  <span>{t.newJobsToday}: <span className="text-foreground font-bold">{summaryData.newJobsToday}</span></span>
                </div>
                <div className="flex items-center text-foreground/70">
                  <span className="flex h-2 w-2 rounded-full bg-secondary mr-2" />
                  <span>{t.newSchemes}: <span className="text-foreground font-bold">{summaryData.newSchemesToday}</span></span>
                </div>
              </>
            ) : (
              <Skeleton className="h-5 w-full max-w-2xl mx-auto" />
            )}
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <Advertisement />

        {/* Trending Section */}
        {!loadingTrending && trendingData && trendingData.items.length > 0 && (
          <section className="mb-12">
            <div className="flex items-center mb-6">
              <TrendingUp className="w-6 h-6 mr-2 text-destructive" />
              <h2 className="text-2xl font-bold">{t.trendingNow}</h2>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {trendingData.items.map((item) => (
                <Card key={`${item.type}-${item.id}`} className="hover-elevate border-destructive/20 border">
                  <CardContent className="p-4 flex items-start gap-3">
                    <span className="text-2xl mt-1">{item.badge}</span>
                    <div>
                      <Link href={`/${item.type}s/${item.id}`} className="font-bold hover:text-primary transition-colors line-clamp-2">
                        {item.title}
                      </Link>
                      <div className="text-xs text-muted-foreground mt-2 font-medium">
                        {item.viewCount.toLocaleString()} views
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>
        )}

        {/* Latest Jobs */}
        <section className="mb-12">
          <div className="flex justify-between items-center mb-6 border-b border-border pb-2">
            <h2 className="text-2xl font-bold flex items-center">
              <span className="w-1.5 h-6 bg-primary mr-3 rounded-sm" />
              {t.latestJobs}
            </h2>
            <Link href="/jobs" className="text-sm font-bold text-primary hover:underline flex items-center">
              {t.viewAll} <ArrowRight className="w-4 h-4 ml-1" />
            </Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {loadingJobs
              ? Array(6).fill(0).map((_, i) => <div key={i}><Skeleton className="h-40 w-full rounded-xl" /></div>)
              : jobsData?.jobs.map((job) => <JobCard key={job.id} job={job} />)
            }
          </div>
        </section>

        <Advertisement />

        {/* Latest Schemes */}
        <section className="mb-12">
          <div className="flex justify-between items-center mb-6 border-b border-border pb-2">
            <h2 className="text-2xl font-bold flex items-center">
              <span className="w-1.5 h-6 bg-secondary mr-3 rounded-sm" />
              {t.pmKisanSchemes}
            </h2>
            <Link href="/schemes" className="text-sm font-bold text-secondary hover:underline flex items-center">
              {t.viewAll} <ArrowRight className="w-4 h-4 ml-1" />
            </Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {loadingSchemes
              ? Array(6).fill(0).map((_, i) => <div key={i}><Skeleton className="h-40 w-full rounded-xl" /></div>)
              : schemesData?.schemes.map((scheme) => <SchemeCard key={scheme.id} scheme={scheme} />)
            }
          </div>
        </section>

        {/* Recent Blogs */}
        <section className="mb-8">
          <div className="flex justify-between items-center mb-6 border-b border-border pb-2">
            <h2 className="text-2xl font-bold flex items-center">
              <span className="w-1.5 h-6 bg-accent mr-3 rounded-sm" />
              {t.newsUpdates}
            </h2>
            <Link href="/blogs" className="text-sm font-bold text-accent hover:underline flex items-center">
              {t.viewAll} <ArrowRight className="w-4 h-4 ml-1" />
            </Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {loadingBlogs
              ? Array(3).fill(0).map((_, i) => <div key={i}><Skeleton className="h-40 w-full rounded-xl" /></div>)
              : blogsData?.blogs.map((blog) => <BlogCard key={blog.id} blog={blog} />)
            }
          </div>
        </section>
      </div>
    </div>
  );
}
