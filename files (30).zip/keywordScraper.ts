/**
 * India GovHub – Keyword Domination System
 * Low-competition, high-traffic keyword targets
 * Used to guide SEO page creation and blog topics
 */

export const KEYWORD_DATABASE = {

  // ── HIGH PRIORITY: Govt Jobs Keywords ────────────────────────────────────
  govtJobs: {
    shortTail: [
      "govt jobs 2026",
      "sarkari naukri 2026",
      "government jobs today",
      "railway jobs 2026",
      "bank jobs 2026",
      "ssc jobs 2026",
    ],
    longTail: [
      "latest govt jobs 2026 apply online",
      "10th pass govt jobs today 2026",
      "12th pass government jobs 2026 apply now",
      "graduate govt jobs 2026 with high salary",
      "railway group d recruitment 2026 apply online",
      "ssc cgl 2026 notification out",
      "ibps po 2026 apply online last date",
      "sbi clerk 2026 notification",
      "up police constable 2026 apply",
      "bihar police constable 2026 vacancy",
      "maharashtra police constable 2026",
      "mpsc 2026 notification out",
      "bpsc 70th result 2026",
      "army agniveer 2026 apply online",
      "crpf constable 2026 apply",
    ],
    featured: [
      "which government job is best after 12th in 2026",
      "how to apply for railway jobs 2026 online",
      "government jobs without exam 2026",
      "direct recruitment govt jobs 2026",
    ],
  },

  // ── HIGH PRIORITY: Kisan Keywords ─────────────────────────────────────────
  kisan: {
    shortTail: [
      "pm kisan 2026",
      "kisan yojana",
      "kisan credit card",
      "fasal bima",
    ],
    longTail: [
      "pm kisan status check online 2026",
      "pm kisan 17th installment date 2026",
      "pm kisan beneficiary list 2026 check name",
      "pm kisan ekyc kaise kare",
      "pm kisan payment failed reason solution",
      "kisan credit card apply online 2026",
      "kcc interest rate 2026",
      "tractor subsidy 2026 apply online",
      "pm fasal bima yojana claim process 2026",
      "fasal bima yojana kharif 2026 premium",
      "crop insurance premium calculator",
    ],
    featured: [
      "pm kisan ka paisa kab aayega 2026",
      "kisan credit card ke fayde 2026",
      "how to check pm kisan payment status",
    ],
  },

  // ── HIGH PRIORITY: Schemes Keywords ───────────────────────────────────────
  schemes: {
    shortTail: [
      "pm yojana 2026",
      "government scheme 2026",
      "sarkari yojana",
    ],
    longTail: [
      "pm awas yojana 2026 apply online gramin",
      "ayushman bharat card apply online 2026",
      "pm ujjwala yojana 2.0 2026 apply",
      "sukanya samriddhi yojana interest rate 2026",
      "atal pension yojana apply online 2026",
      "pm jan dhan yojana account open 2026",
      "free gas cylinder scheme 2026",
      "women government schemes india 2026",
      "new government scheme for farmers 2026",
      "all pm yojana list 2026 in hindi",
    ],
    featured: [
      "which government scheme gives most money in 2026",
      "how to get free house from government 2026",
      "government schemes for BPL families 2026",
    ],
  },

  // ── MEDIUM PRIORITY: Tools Keywords ───────────────────────────────────────
  tools: {
    longTail: [
      "emi calculator home loan 2026",
      "sbi home loan emi calculator 2026",
      "government job age calculator online",
      "age calculator for ssc exam 2026",
      "compress photo for government job online free",
      "compress jpg below 20kb for upsc",
      "photo size for ssc cgl application",
      "age limit for railway group d 2026",
    ],
  },

  // ── VIRAL/TRENDING Keywords ────────────────────────────────────────────────
  trending: [
    "pm kisan 17th installment news today",
    "railway result out 2026 today",
    "ssc cgl result 2026",
    "up police result 2026",
    "agniveer result 2026",
    "ibps po result 2026",
    "new government scheme announced today",
    "latest sarkari naukri today",
  ],
};

// Keyword difficulty ratings (L=Low, M=Medium, H=High)
export const KEYWORD_DIFFICULTY = {
  "govt jobs 2026": "M",
  "pm kisan status check online": "L",
  "kisan credit card apply": "L",
  "tractor subsidy 2026": "L",
  "women schemes india 2026": "L",
  "pm yojana list 2026": "L",
  "10th pass govt jobs today": "L",
  "compress photo for government job": "L",
  "age calculator ssc 2026": "L",
  "railway group d 2026 apply": "M",
  "ssc cgl 2026": "H",
  "bank jobs 2026": "H",
};

// Pages to create based on keyword gaps
export const PAGES_TO_CREATE = [
  { slug: "agniveer-army-2026", keyword: "agniveer army 2026 apply", priority: "HIGH" },
  { slug: "upsc-2026-notification", keyword: "upsc ias 2026 notification", priority: "HIGH" },
  { slug: "neet-2026-guide", keyword: "neet 2026 apply online", priority: "MEDIUM" },
  { slug: "teaching-jobs-2026", keyword: "government teaching jobs 2026", priority: "MEDIUM" },
  { slug: "police-jobs-2026", keyword: "police constable jobs 2026", priority: "HIGH" },
  { slug: "defence-jobs-2026", keyword: "defence government jobs 2026", priority: "HIGH" },
  { slug: "psu-jobs-2026", keyword: "PSU jobs 2026 ONGC BHEL", priority: "MEDIUM" },
  { slug: "pm-kisan-registration-2026", keyword: "pm kisan new registration 2026", priority: "HIGH" },
  { slug: "ayushman-bharat-apply", keyword: "ayushman bharat card apply online", priority: "HIGH" },
  { slug: "pm-awas-yojana-list", keyword: "pm awas yojana beneficiary list 2026", priority: "MEDIUM" },
];

export default KEYWORD_DATABASE;
