import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { I18nProvider } from "@/lib/i18n";

import Home from "@/pages/home";
import JobsPage from "@/pages/jobs";
import JobDetailPage from "@/pages/job-detail";
import SchemesPage from "@/pages/schemes";
import SchemeDetailPage from "@/pages/scheme-detail";
import BlogsPage from "@/pages/blogs";
import BlogDetailPage from "@/pages/blog-detail";
import ToolsPage from "@/pages/tools";
import CategoryJobsPage from "@/pages/category-jobs";
import CategorySchemesPage from "@/pages/category-schemes";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient();

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/jobs/ssc">
        <CategoryJobsPage category="ssc" title="SSC Jobs 2026" description="Latest Staff Selection Commission notifications, admit cards, and results." />
      </Route>
      <Route path="/jobs/railway">
        <CategoryJobsPage category="railway" title="Railway Jobs 2026" description="Latest RRB & RRC recruitment – ALP, NTPC, Group D jobs." />
      </Route>
      <Route path="/jobs/bank">
        <CategoryJobsPage category="bank" title="Bank Jobs 2026" description="IBPS, SBI, RBI PO and Clerk recruitment notifications 2026." />
      </Route>
      <Route path="/jobs" component={JobsPage} />
      <Route path="/jobs/:id" component={JobDetailPage} />
      <Route path="/schemes/kisan">
        <CategorySchemesPage category="kisan" title="PM Kisan Yojana & Schemes" description="Latest PM Kisan Samman Nidhi, crop insurance and farmer subsidies." />
      </Route>
      <Route path="/schemes" component={SchemesPage} />
      <Route path="/schemes/:id" component={SchemeDetailPage} />
      <Route path="/blogs" component={BlogsPage} />
      <Route path="/blogs/:id" component={BlogDetailPage} />
      <Route path="/tools" component={ToolsPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <I18nProvider>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <div className="flex flex-col min-h-screen">
              <Header />
              <main className="flex-1">
                <Router />
              </main>
              <Footer />
            </div>
          </WouterRouter>
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </I18nProvider>
  );
}

export default App;
