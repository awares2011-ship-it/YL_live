import { Link } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import AdSense from "@/components/adsense";
import { ExternalLink, CheckCircle, AlertCircle, Calendar, FileText, Users, IndianRupee } from "lucide-react";

// ─── Shared Helpers ───────────────────────────────────────────────────────────

export function InternalLinks({ links }: { links: { label: string; href: string }[] }) {
  return (
    <div className="mt-6 p-4 bg-orange-50 rounded-xl border border-orange-100">
      <h3 className="font-bold text-orange-800 mb-2 text-sm">Related Links</h3>
      <div className="flex flex-wrap gap-2">
        {links.map((l) => (
          <Link key={l.href} href={l.href}>
            <Badge variant="outline" className="cursor-pointer border-orange-300 text-orange-700 hover:bg-orange-100 py-1 px-3">{l.label}</Badge>
          </Link>
        ))}
      </div>
    </div>
  );
}

export function FaqSection({ faqs }: { faqs: { q: string; a: string }[] }) {
  return (
    <div className="mt-6 bg-white border border-border rounded-xl p-6">
      <h2 className="text-xl font-bold mb-4">Frequently Asked Questions (FAQ)</h2>
      <div className="space-y-4">
        {faqs.map((faq, i) => (
          <div key={i} className="border-l-4 border-orange-400 pl-4">
            <h3 className="font-semibold text-gray-800 mb-1">{faq.q}</h3>
            <p className="text-muted-foreground text-sm">{faq.a}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function StepList({ steps }: { steps: string[] }) {
  return (
    <div className="space-y-3">
      {steps.map((step, i) => (
        <div key={i} className="flex gap-3 items-start p-3 bg-blue-50 border border-blue-200 rounded-xl">
          <span className="w-7 h-7 rounded-full bg-blue-500 text-white flex items-center justify-center font-bold text-sm shrink-0">{i + 1}</span>
          <p className="text-muted-foreground">{step}</p>
        </div>
      ))}
    </div>
  );
}

function InfoCard({ icon, label, value, color = "orange" }: { icon: React.ReactNode; label: string; value: string; color?: string }) {
  return (
    <div className={`bg-${color}-50 border border-${color}-200 rounded-xl p-4 text-center`}>
      <div className="flex justify-center mb-1">{icon}</div>
      <div className={`text-2xl font-black text-${color}-700`}>{value}</div>
      <p className="text-sm text-muted-foreground mt-1">{label}</p>
    </div>
  );
}

// ─── Graduate Jobs ────────────────────────────────────────────────────────────

export function GraduateGovtJobs() {
  return (
    <div className="space-y-6">
      <p className="text-muted-foreground leading-relaxed">
        Graduates have access to the most prestigious and highest-paying government jobs in India. In 2026, over 2 lakh vacancies across UPSC, SSC, Banking, PSUs, and state services are open exclusively for graduates. These jobs offer salaries ranging from ₹35,000 to ₹2.5 lakh per month with exceptional career growth and retirement benefits.
      </p>

      <div className="grid md:grid-cols-3 gap-4">
        <InfoCard icon={<Users className="text-blue-600" />} label="Total Vacancies" value="2 Lakh+" color="blue" />
        <InfoCard icon={<IndianRupee className="text-green-600" />} label="Starting Salary" value="₹35,400" color="green" />
        <InfoCard icon={<Calendar className="text-orange-600" />} label="Active Notifications" value="50+" color="orange" />
      </div>

      <h2 className="text-xl font-bold">Top Graduate Government Jobs 2026</h2>
      <div className="space-y-3">
        {[
          { name: "UPSC Civil Services (IAS/IPS/IFS)", org: "Union Public Service Commission", vacancies: "1,056", salary: "56,100–2,50,000", qual: "Any Graduate" },
          { name: "SSC CGL 2026", org: "Staff Selection Commission", vacancies: "17,727", salary: "35,400–1,12,400", qual: "Any Graduate" },
          { name: "SBI PO 2026", org: "State Bank of India", vacancies: "600", salary: "36,000–63,840", qual: "Any Graduate" },
          { name: "IBPS PO 2026", org: "Institute of Banking Personnel Selection", vacancies: "4,455", salary: "36,000–63,840", qual: "Any Graduate" },
          { name: "RBI Grade B 2026", org: "Reserve Bank of India", vacancies: "291", salary: "55,000–1,10,000", qual: "Graduate (60%+)" },
          { name: "NABARD Grade A/B", org: "National Bank for Agriculture", vacancies: "102", salary: "28,150–51,020", qual: "Graduate/PG" },
        ].map((job) => (
          <div key={job.name} className="p-4 border border-blue-200 bg-blue-50 rounded-xl">
            <div className="flex justify-between items-start gap-2">
              <div>
                <h3 className="font-bold text-blue-800">{job.name}</h3>
                <p className="text-sm text-muted-foreground">{job.org}</p>
              </div>
              <Badge className="bg-blue-600 text-white shrink-0">{job.vacancies}</Badge>
            </div>
            <div className="flex flex-wrap gap-4 mt-2 text-sm">
              <span>Salary: <b className="text-orange-600">₹{job.salary}</b></span>
              <span className="text-muted-foreground">{job.qual}</span>
            </div>
          </div>
        ))}
      </div>

      <h2 className="text-xl font-bold">Best Graduate Government Jobs by Sector</h2>
      <div className="grid md:grid-cols-2 gap-4">
        {[
          { sector: "Civil Services", jobs: "IAS, IPS, IFS, IRS via UPSC", icon: "🏛️" },
          { sector: "Banking", jobs: "SBI PO, IBPS PO, RBI Grade B, NABARD", icon: "🏦" },
          { sector: "Defence", jobs: "NDA, CDS, AFCAT, TA Officer", icon: "⚔️" },
          { sector: "Teaching", jobs: "NET/JRF, TGT, PGT, KVS, NVS", icon: "📚" },
          { sector: "PSU Jobs", jobs: "ONGC, BHEL, NTPC, SAIL, GAIL", icon: "🏭" },
          { sector: "Insurance", jobs: "LIC AAO, GIC AO, NIACL AO", icon: "📋" },
        ].map((s) => (
          <div key={s.sector} className="flex items-start gap-3 p-3 bg-white border border-border rounded-xl">
            <span className="text-2xl">{s.icon}</span>
            <div>
              <h3 className="font-bold text-sm">{s.sector}</h3>
              <p className="text-xs text-muted-foreground">{s.jobs}</p>
            </div>
          </div>
        ))}
      </div>

      <AdSense slot="graduate_jobs_inline" />

      <h2 className="text-xl font-bold">How to Prepare for Graduate Government Jobs</h2>
      <StepList steps={[
        "Identify your target exam based on your graduation stream and interests",
        "Download the official syllabus from the exam body's website (ssc.nic.in, ibps.in, upsc.gov.in)",
        "Build a 6–12 month study plan covering all subjects systematically",
        "Practice previous year papers — last 10 years are mandatory for serious aspirants",
        "Take full-length mock tests weekly to build speed and accuracy",
        "Join a coaching class or online course if self-study feels insufficient",
        "Follow current affairs daily through newspapers or apps like Inshorts, The Hindu",
      ]} />

      <FaqSection faqs={[
        { q: "What is the highest paying graduate government job?", a: "UPSC Civil Services (IAS) offers the highest pay reaching ₹2.5 lakh/month at Cabinet Secretary level. RBI Grade B (₹55,000+) and PSU jobs also offer excellent packages at graduate level." },
        { q: "Can BCom/BA/BSc graduates apply for all government jobs?", a: "Most government jobs accept any graduation stream. However, technical PSUs (ONGC, BHEL) and specialist posts (SO in banks) prefer specific streams like Engineering or Finance." },
        { q: "How many attempts are allowed for UPSC CSE?", a: "General category: 6 attempts (up to age 32). OBC: 9 attempts (age 35). SC/ST: Unlimited attempts till age 37. PwD: 9 attempts (age 42). EWS follows General category limits." },
        { q: "Is work experience required for graduate government jobs?", a: "Mostly no — freshers can apply for most government jobs. Some PSU recruitment through GATE or Senior Management posts may prefer experienced candidates." },
        { q: "Which exam has highest success rate for graduates?", a: "SSC CGL has one of the highest selection rates due to high vacancy count (17,000+). SBI Clerk and IBPS Clerk also have good vacancy numbers compared to competition level." },
      ]} />

      <InternalLinks links={[
        { label: "Latest Govt Jobs 2026", href: "/seo/latest-govt-jobs-2026" },
        { label: "Bank Jobs 2026", href: "/seo/bank-jobs-2026" },
        { label: "SSC Jobs 2026", href: "/seo/ssc-jobs-2026" },
        { label: "10th Pass Jobs", href: "/seo/10th-pass-govt-jobs" },
        { label: "12th Pass Jobs", href: "/seo/12th-pass-govt-jobs" },
        { label: "Age Calculator", href: "/tools/age-calculator" },
      ]} />
    </div>
  );
}

// ─── Tractor Subsidy ──────────────────────────────────────────────────────────

export function TractorSubsidyScheme() {
  return (
    <div className="space-y-6">
      <p className="text-muted-foreground leading-relaxed">
        The Central and State Governments of India provide substantial subsidies on tractor purchases to help farmers mechanize their agriculture. Under PM Kisan Tractor Yojana and state-level schemes, farmers can get 20%–50% subsidy on new tractor purchases. In 2026, this scheme is available in almost all states with applications accepted online and offline.
      </p>

      <div className="grid md:grid-cols-3 gap-4">
        <div className="bg-green-50 border border-green-200 rounded-xl p-4 text-center">
          <div className="text-3xl font-black text-green-700">50%</div>
          <p className="text-sm text-muted-foreground mt-1">Maximum Subsidy</p>
        </div>
        <div className="bg-orange-50 border border-orange-200 rounded-xl p-4 text-center">
          <div className="text-3xl font-black text-orange-600">₹5L</div>
          <p className="text-sm text-muted-foreground mt-1">Max Subsidy Amount</p>
        </div>
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 text-center">
          <div className="text-3xl font-black text-blue-700">28</div>
          <p className="text-sm text-muted-foreground mt-1">States Covered</p>
        </div>
      </div>

      <h2 className="text-xl font-bold">PM Kisan Tractor Yojana – Eligibility 2026</h2>
      <div className="space-y-2">
        {[
          { ok: true, text: "Indian farmer with agricultural land in their name" },
          { ok: true, text: "Land record (Khasra/Khatauni) registered in applicant's name" },
          { ok: true, text: "Should not have received tractor subsidy from government in past 7 years" },
          { ok: true, text: "No pending dues on agricultural loans (for some states)" },
          { ok: false, text: "Corporate farms and tenant/leasehold farmers are NOT eligible" },
          { ok: false, text: "Cannot have availed subsidy for another farm machinery in same year" },
        ].map((item, i) => (
          <div key={i} className={`flex items-start gap-2 p-3 rounded-xl border ${item.ok ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200"}`}>
            {item.ok
              ? <CheckCircle className="w-5 h-5 text-green-600 shrink-0 mt-0.5" />
              : <AlertCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />}
            <p className="text-sm text-muted-foreground">{item.text}</p>
          </div>
        ))}
      </div>

      <h2 className="text-xl font-bold">How to Apply for Tractor Subsidy 2026</h2>
      <StepList steps={[
        "Visit your state agriculture department portal or CSC (Common Service Center)",
        "Register with Aadhaar, bank details, and land documents (Khasra/Khatauni)",
        "Select the tractor model and manufacturer from the approved vendor list",
        "Upload required documents: Aadhaar, land records, bank passbook, photo",
        "Submit application and note your application reference number",
        "After approval, purchase tractor from empanelled dealer — subsidy is credited to your bank account",
      ]} />

      <h2 className="text-xl font-bold">Documents Required</h2>
      <div className="grid md:grid-cols-2 gap-3">
        {["Aadhaar Card", "Land Records (Khasra/Khatauni)", "Bank Passbook/Cancel Cheque", "Passport Size Photo", "Caste Certificate (if SC/ST)", "Income Certificate", "Old Tractor Registration (if any)", "Mobile Number linked with Aadhaar"].map((doc) => (
          <div key={doc} className="flex items-center gap-2 p-2 bg-gray-50 border border-border rounded-lg">
            <FileText className="w-4 h-4 text-orange-600" />
            <span className="text-sm">{doc}</span>
          </div>
        ))}
      </div>

      <AdSense slot="tractor_subsidy_inline" />

      <h2 className="text-xl font-bold">State-wise Tractor Subsidy 2026</h2>
      <div className="space-y-2">
        {[
          { state: "Rajasthan", subsidy: "40–50%", portal: "rajkisan.rajasthan.gov.in" },
          { state: "Madhya Pradesh", subsidy: "40–50%", portal: "dbt.mpdage.org" },
          { state: "Bihar", subsidy: "40–50%", portal: "dbtagriculture.bihar.gov.in" },
          { state: "Uttar Pradesh", subsidy: "25–40%", portal: "upagriculture.com" },
          { state: "Maharashtra", subsidy: "40–50%", portal: "mahadbt.maharashtra.gov.in" },
          { state: "Punjab", subsidy: "25%", portal: "agripb.gov.in" },
        ].map((s) => (
          <div key={s.state} className="flex justify-between items-center p-3 bg-white border border-border rounded-xl">
            <div>
              <span className="font-bold">{s.state}</span>
              <p className="text-xs text-muted-foreground">{s.portal}</p>
            </div>
            <Badge className="bg-green-600 text-white">{s.subsidy}</Badge>
          </div>
        ))}
      </div>

      <FaqSection faqs={[
        { q: "Can a small farmer with 1 acre apply for tractor subsidy?", a: "Yes, there is no minimum land requirement in most states. However, some states require minimum 1–2 acres of cultivable land. Check your state agriculture portal for exact criteria." },
        { q: "Which tractor brands are eligible for subsidy?", a: "Government-approved brands include Mahindra, Sonalika, John Deere, TAFE, New Holland, Eicher, and others empanelled with state agriculture departments. Buy only from approved vendors." },
        { q: "How much time does subsidy approval take?", a: "Typically 30–90 days after application submission. The amount is directly transferred to your bank account (DBT) after document verification and state approval." },
        { q: "Can one family get tractor subsidy multiple times?", a: "No. A family can receive tractor subsidy only once in 7 years. If you already received it, you must wait 7 years before applying again." },
      ]} />

      <InternalLinks links={[
        { label: "PM Kisan Yojana", href: "/seo/pm-kisan-yojana" },
        { label: "Crop Insurance Scheme", href: "/seo/crop-insurance-scheme" },
        { label: "Kisan Credit Card", href: "/seo/kisan-credit-card" },
        { label: "All Schemes", href: "/schemes" },
        { label: "Farmer Schemes India", href: "/seo/farmer-schemes-india" },
      ]} />
    </div>
  );
}

// ─── Crop Insurance ───────────────────────────────────────────────────────────

export function CropInsuranceScheme() {
  return (
    <div className="space-y-6">
      <p className="text-muted-foreground leading-relaxed">
        Pradhan Mantri Fasal Bima Yojana (PMFBY) is India's flagship crop insurance scheme that protects farmers against crop losses due to natural calamities, pests, and diseases. With premium as low as 1.5% for Rabi crops and 2% for Kharif crops, it is one of the world's largest crop insurance programs. Over 5.5 crore farmers enroll annually.
      </p>

      <div className="grid md:grid-cols-4 gap-3">
        {[
          { label: "Kharif Premium", value: "2%", color: "green" },
          { label: "Rabi Premium", value: "1.5%", color: "yellow" },
          { label: "Commercial Crops", value: "5%", color: "orange" },
          { label: "Farmers Covered", value: "5.5 Cr", color: "blue" },
        ].map((item) => (
          <div key={item.label} className={`bg-${item.color}-50 border border-${item.color}-200 rounded-xl p-3 text-center`}>
            <div className={`text-2xl font-black text-${item.color}-700`}>{item.value}</div>
            <p className="text-xs text-muted-foreground mt-1">{item.label}</p>
          </div>
        ))}
      </div>

      <h2 className="text-xl font-bold">What is Covered Under PMFBY?</h2>
      <div className="grid md:grid-cols-2 gap-3">
        {[
          { title: "Natural Calamities", items: ["Drought & Dry Spells", "Flood & Inundation", "Cyclone & Hailstorm", "Landslide & Lightning"] },
          { title: "Crop Damage", items: ["Prevented Sowing (>25% loss)", "Mid-Season Adversity", "Post-Harvest Losses (up to 14 days)", "Localized Calamities"] },
        ].map((cat) => (
          <div key={cat.title} className="p-4 bg-green-50 border border-green-200 rounded-xl">
            <h3 className="font-bold text-green-800 mb-2">{cat.title}</h3>
            <ul className="space-y-1">
              {cat.items.map((item) => (
                <li key={item} className="flex items-center gap-2 text-sm text-muted-foreground">
                  <CheckCircle className="w-4 h-4 text-green-500 shrink-0" /> {item}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <h2 className="text-xl font-bold">How to Enroll in Crop Insurance 2026</h2>
      <StepList steps={[
        "Visit nearest bank branch (where your Kisan Credit Card/crop loan account is)",
        "Fill PMFBY enrollment form with land sown details and crop type",
        "Submit Aadhaar card, bank passbook, land records (Khasra)",
        "Pay the farmer's share of premium (1.5%–5% of sum insured)",
        "Receive insurance policy certificate with your crop coverage details",
        "Report crop damage within 72 hours via crop insurance app or helpline 14447",
      ]} />

      <AdSense slot="crop_insurance_inline" />

      <h2 className="text-xl font-bold">Documents Required</h2>
      <div className="grid md:grid-cols-2 gap-2">
        {["Aadhaar Card", "Land Records (Khasra/Khatauni)", "Bank Account Details (linked with Aadhaar)", "Crop Sowing Certificate from Patwari", "Mobile Number", "Photograph"].map((doc) => (
          <div key={doc} className="flex items-center gap-2 p-2 bg-gray-50 border border-border rounded-lg text-sm">
            <FileText className="w-4 h-4 text-green-600" /> {doc}
          </div>
        ))}
      </div>

      <FaqSection faqs={[
        { q: "Is PMFBY enrollment compulsory for loanee farmers?", a: "PMFBY is compulsory for farmers who take crop loans (KCC) from banks. For non-loanee farmers, it is voluntary. You can opt-out by submitting declaration before cutoff date." },
        { q: "How to claim crop insurance after damage?", a: "Report crop damage within 72 hours via Crop Insurance App, calling 14447 helpline, or visiting nearest bank branch. Crop cutting experiment determines compensation amount." },
        { q: "How long does PMFBY claim settlement take?", a: "Claims must be settled within 2 months of crop cutting experiments. For mid-season adversity and prevented sowing, advance of 25% is paid immediately." },
        { q: "Can I enroll in PMFBY without a Kisan Credit Card?", a: "Yes, non-loanee farmers can enroll directly at their bank, CSC center, or through the Crop Insurance App before the cutoff date for each season." },
        { q: "What is the PMFBY helpline number?", a: "PMFBY helpline number is 14447. You can also use the PMFBY app (Crop Insurance) available on Google Play Store to enroll, report damage, and track claims." },
      ]} />

      <InternalLinks links={[
        { label: "PM Kisan Yojana", href: "/seo/pm-kisan-yojana" },
        { label: "Kisan Credit Card", href: "/seo/kisan-credit-card" },
        { label: "Tractor Subsidy", href: "/seo/tractor-subsidy-scheme" },
        { label: "Farmer Schemes India", href: "/seo/farmer-schemes-india" },
        { label: "All Schemes", href: "/schemes" },
      ]} />
    </div>
  );
}

// ─── Kisan Credit Card ────────────────────────────────────────────────────────

export function KisanCreditCard() {
  return (
    <div className="space-y-6">
      <p className="text-muted-foreground leading-relaxed">
        Kisan Credit Card (KCC) is a special credit facility provided by banks to farmers at subsidized interest rates. Under PM Kisan KCC scheme launched in 2019, all PM Kisan beneficiaries are eligible for KCC with a credit limit up to ₹3 lakh at just 4% effective interest rate (after 3% interest subvention). Over 7 crore KCC accounts are active in India.
      </p>

      <div className="bg-green-600 text-white rounded-2xl p-6 relative overflow-hidden">
        <div className="absolute right-0 top-0 w-32 h-32 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2" />
        <div className="relative z-10">
          <p className="text-green-200 text-sm font-semibold mb-1">KISAN CREDIT CARD</p>
          <h2 className="text-3xl font-black mb-1">₹3,00,000</h2>
          <p className="text-green-200">Credit Limit | 4% Interest Rate</p>
          <div className="mt-4 flex gap-4">
            <div>
              <p className="text-xs text-green-200">Annual Repayment</p>
              <p className="font-bold">After Harvest</p>
            </div>
            <div>
              <p className="text-xs text-green-200">Validity</p>
              <p className="font-bold">5 Years</p>
            </div>
          </div>
        </div>
      </div>

      <h2 className="text-xl font-bold">Benefits of Kisan Credit Card</h2>
      <div className="grid md:grid-cols-2 gap-3">
        {[
          { title: "Low Interest Rate", desc: "Effective interest rate of just 4% per annum (7% minus 3% subvention for timely repayment)" },
          { title: "Flexible Credit Limit", desc: "Credit limit from ₹10,000 to ₹3 lakh based on land holding and crop requirements" },
          { title: "No Security for ₹1.6L", desc: "No collateral required for KCC limit up to ₹1.6 lakh. Above ₹1.6L needs land as security" },
          { title: "ATM Facility", desc: "KCC comes with RuPay debit card for easy cash withdrawal at ATMs anywhere in India" },
          { title: "Personal Accident Insurance", desc: "Free personal accident insurance of ₹50,000 for death/permanent disability included" },
          { title: "Crop Insurance", desc: "PMFBY crop insurance premium automatically enrolled for KCC holders" },
        ].map((b) => (
          <div key={b.title} className="p-3 bg-green-50 border border-green-200 rounded-xl">
            <h3 className="font-bold text-green-800 text-sm mb-1">{b.title}</h3>
            <p className="text-xs text-muted-foreground">{b.desc}</p>
          </div>
        ))}
      </div>

      <h2 className="text-xl font-bold">How to Apply for Kisan Credit Card</h2>
      <StepList steps={[
        "Visit your nearest branch of SBI, PNB, Bank of Baroda, or any nationalized bank",
        "Fill KCC application form available at the bank or download from bank's website",
        "Submit documents: Aadhaar, land records, photo, address proof",
        "Bank sends application to agriculture department for land record verification",
        "After verification (7–15 days), KCC is sanctioned and RuPay card issued",
        "Use KCC for buying seeds, fertilizers, pesticides, and other farming needs",
        "Repay after harvest to maintain 4% subsidized interest benefit",
      ]} />

      <AdSense slot="kisan_credit_card_inline" />

      <h2 className="text-xl font-bold">Which Banks Offer Kisan Credit Card?</h2>
      <div className="flex flex-wrap gap-2">
        {["State Bank of India", "Bank of Baroda", "Punjab National Bank", "NABARD", "Union Bank", "Canara Bank", "UCO Bank", "IDBI Bank", "RRBs (Regional Rural Banks)", "Cooperative Banks"].map((bank) => (
          <Badge key={bank} variant="outline" className="border-green-300 text-green-700 py-1 px-2">{bank}</Badge>
        ))}
      </div>

      <FaqSection faqs={[
        { q: "What is the interest rate for Kisan Credit Card?", a: "KCC interest rate is 7% per annum. But with 3% interest subvention for timely repayment, effective rate is only 4% per annum. Additional 2% subvention makes it 2% for prompt repayment (state-specific)." },
        { q: "What is the maximum credit limit for KCC?", a: "Maximum KCC limit is ₹3 lakh without mortgage. Above ₹3 lakh, farmers can get higher limits with land mortgage. Limit is calculated based on land area, crop type, and cultivation cost." },
        { q: "Can tenant farmers apply for Kisan Credit Card?", a: "Yes, tenant farmers and sharecroppers can apply for KCC under the JLG (Joint Liability Group) model. They need to form a group of 4–10 farmers and apply collectively." },
        { q: "How to convert PM Kisan benefit to KCC?", a: "PM Kisan beneficiaries automatically qualify for KCC. Visit your bank with PM Kisan registration number, Aadhaar, and land records to get KCC issued quickly under the dedicated drive." },
        { q: "What is the repayment period for KCC?", a: "KCC is a revolving credit facility valid for 5 years. You must repay within 12 months of disbursement (post-harvest). Interest-free period varies by crop season." },
      ]} />

      <InternalLinks links={[
        { label: "PM Kisan Yojana", href: "/seo/pm-kisan-yojana" },
        { label: "PM Kisan Status", href: "/seo/pm-kisan-status-check" },
        { label: "Crop Insurance", href: "/seo/crop-insurance-scheme" },
        { label: "EMI Calculator", href: "/tools/emi-calculator" },
        { label: "All Schemes", href: "/schemes" },
      ]} />
    </div>
  );
}

// ─── PM Yojana List ───────────────────────────────────────────────────────────

export function PmYojanaList() {
  return (
    <div className="space-y-6">
      <p className="text-muted-foreground leading-relaxed">
        The Government of India runs over 100 central government schemes (Pradhan Mantri Yojana) covering agriculture, housing, education, health, employment, and social security. In 2026, these schemes have collectively benefited over 80 crore Indians with direct cash transfers, subsidies, and services. Here is the complete, updated list of all active PM Yojana 2026.
      </p>

      <h2 className="text-xl font-bold">Agriculture & Kisan Yojana</h2>
      <div className="space-y-2">
        {[
          { name: "PM Kisan Samman Nidhi", benefit: "₹6,000/year to farmers", link: "/seo/pm-kisan-yojana" },
          { name: "PM Fasal Bima Yojana (PMFBY)", benefit: "Crop insurance at 1.5–2% premium", link: "/seo/crop-insurance-scheme" },
          { name: "PM Kisan Tractor Yojana", benefit: "20–50% subsidy on tractors", link: "/seo/tractor-subsidy-scheme" },
          { name: "Kisan Credit Card (KCC)", benefit: "₹3L credit at 4% interest", link: "/seo/kisan-credit-card" },
          { name: "PM Krishi Sinchai Yojana", benefit: "Drip/sprinkler irrigation subsidy 55–75%" },
          { name: "Soil Health Card Scheme", benefit: "Free soil testing and recommendations" },
          { name: "Paramparagat Krishi Vikas Yojana", benefit: "₹50,000/acre for organic farming" },
        ].map((scheme) => (
          <div key={scheme.name} className="flex justify-between items-center p-3 bg-green-50 border border-green-200 rounded-xl">
            <div>
              <h3 className="font-bold text-sm">{scheme.name}</h3>
              <p className="text-xs text-muted-foreground">{scheme.benefit}</p>
            </div>
            {scheme.link
              ? <Link href={scheme.link}><Badge variant="outline" className="border-green-400 text-green-700 cursor-pointer">Details</Badge></Link>
              : <Badge variant="outline" className="border-gray-300">Active</Badge>}
          </div>
        ))}
      </div>

      <h2 className="text-xl font-bold">Housing & Urban Schemes</h2>
      <div className="space-y-2">
        {[
          { name: "PM Awas Yojana – Gramin (PMAY-G)", benefit: "₹1.2–1.5 lakh for house construction" },
          { name: "PM Awas Yojana – Urban (PMAY-U)", benefit: "Up to ₹2.67 lakh home loan subsidy" },
          { name: "PM Svanidhi Yojana", benefit: "₹10,000–₹50,000 working capital loan for street vendors" },
          { name: "Jal Jeevan Mission", benefit: "Har Ghar Nal Se Jal – tap water to all households" },
          { name: "PM Ujjwala Yojana 2.0", benefit: "Free LPG connection for BPL families" },
          { name: "PM Jan Dhan Yojana", benefit: "Zero balance bank account + ₹2L insurance" },
        ].map((scheme) => (
          <div key={scheme.name} className="flex justify-between items-center p-3 bg-blue-50 border border-blue-200 rounded-xl">
            <div>
              <h3 className="font-bold text-sm">{scheme.name}</h3>
              <p className="text-xs text-muted-foreground">{scheme.benefit}</p>
            </div>
            <Badge variant="outline" className="border-blue-400 text-blue-700">Active</Badge>
          </div>
        ))}
      </div>

      <AdSense slot="pm_yojana_list_inline" />

      <h2 className="text-xl font-bold">Health & Social Security Schemes</h2>
      <div className="space-y-2">
        {[
          { name: "Ayushman Bharat PM-JAY", benefit: "₹5 lakh free health coverage per family" },
          { name: "PM Jan Arogya Yojana", benefit: "70 lakh+ empanelled hospitals" },
          { name: "PM Suraksha Bima Yojana", benefit: "₹2 lakh accident insurance at ₹20/year" },
          { name: "PM Jeevan Jyoti Bima Yojana", benefit: "₹2 lakh life insurance at ₹436/year" },
          { name: "Atal Pension Yojana", benefit: "₹1,000–5,000/month pension after 60" },
          { name: "PM Shram Yogi Maan-Dhan", benefit: "₹3,000/month pension for unorganized workers" },
        ].map((scheme) => (
          <div key={scheme.name} className="flex justify-between items-center p-3 bg-purple-50 border border-purple-200 rounded-xl">
            <div>
              <h3 className="font-bold text-sm">{scheme.name}</h3>
              <p className="text-xs text-muted-foreground">{scheme.benefit}</p>
            </div>
            <Badge variant="outline" className="border-purple-400 text-purple-700">Active</Badge>
          </div>
        ))}
      </div>

      <FaqSection faqs={[
        { q: "How many PM Yojanas are there in 2026?", a: "There are over 100 active central government schemes (PM Yojana) in 2026. These cover agriculture, housing, health, employment, education, women empowerment, and social security sectors." },
        { q: "How to check eligibility for PM Yojana?", a: "Visit myscheme.gov.in — the government portal that helps you find schemes you are eligible for by answering a few questions about your profession, income, state, and other details." },
        { q: "Which PM Yojana gives cash directly?", a: "PM Kisan (₹6,000/year), PM Awas Yojana (₹1.2–2.67 lakh), PM Suraksha Bima (₹2L insurance), MGNREGA wages, and scholarship schemes transfer money directly to bank accounts." },
        { q: "Is PM Yojana available for urban residents?", a: "Many PM Yojanas cover urban residents including PM Awas Yojana Urban, PM Jan Dhan, Ayushman Bharat, PM Suraksha Bima, PM Jeevan Jyoti, and Atal Pension Yojana." },
      ]} />

      <InternalLinks links={[
        { label: "Women Schemes", href: "/seo/women-schemes-india" },
        { label: "Farmer Schemes", href: "/seo/farmer-schemes-india" },
        { label: "PM Kisan Yojana", href: "/seo/pm-kisan-yojana" },
        { label: "All Schemes", href: "/schemes" },
        { label: "Latest Govt Jobs", href: "/seo/latest-govt-jobs-2026" },
      ]} />
    </div>
  );
}

// ─── Women Schemes India ──────────────────────────────────────────────────────

export function WomenSchemesIndia() {
  return (
    <div className="space-y-6">
      <p className="text-muted-foreground leading-relaxed">
        The Government of India runs numerous dedicated schemes for women empowerment in 2026 covering financial assistance, health, education, self-employment, protection, and social security. These schemes aim to promote gender equality, ensure safety, and provide economic independence to women across rural and urban India. Here is the complete updated list of all active women's schemes in India 2026.
      </p>

      <h2 className="text-xl font-bold">Financial Empowerment Schemes for Women</h2>
      <div className="space-y-3">
        {[
          { name: "PM Mahila Shakti Kendra", benefit: "Community service centers empowering rural women in 115 districts", ministry: "Women & Child Development" },
          { name: "Pradhan Mantri Matru Vandana Yojana (PMMVY)", benefit: "₹5,000 cash incentive for first live birth (₹11,000 for 2nd birth if girl)", ministry: "Women & Child Development" },
          { name: "Mahila E-Haat", benefit: "Online platform for women entrepreneurs to sell products", ministry: "Women & Child Development" },
          { name: "Udyogini Scheme", benefit: "Collateral-free loans up to ₹3 lakh for women entrepreneurs at 0–4% interest", ministry: "Ministry of Finance" },
          { name: "Sukanya Samriddhi Yojana", benefit: "8.2% interest savings scheme for girl child education/marriage", ministry: "Finance Ministry" },
          { name: "Beti Bachao Beti Padhao", benefit: "Campaign for girl child welfare in 640+ districts", ministry: "WCD Ministry" },
        ].map((scheme) => (
          <div key={scheme.name} className="p-4 bg-pink-50 border border-pink-200 rounded-xl">
            <h3 className="font-bold text-pink-800">{scheme.name}</h3>
            <p className="text-sm text-muted-foreground mt-1">{scheme.benefit}</p>
            <Badge variant="outline" className="mt-2 border-pink-300 text-pink-700 text-xs">{scheme.ministry}</Badge>
          </div>
        ))}
      </div>

      <AdSense slot="women_schemes_inline" />

      <h2 className="text-xl font-bold">Health Schemes for Women</h2>
      <div className="space-y-2">
        {[
          { name: "Janani Suraksha Yojana (JSY)", benefit: "Cash incentive ₹600–1,400 for institutional delivery" },
          { name: "Pradhan Mantri Surakshit Matritva Abhiyan", benefit: "Free antenatal checkup on 9th of every month" },
          { name: "Mission Indradhanush", benefit: "Free vaccination for pregnant women and children" },
          { name: "PM Jan Arogya Yojana (Ayushman Bharat)", benefit: "₹5 lakh health coverage — family includes women" },
          { name: "Anaemia Mukt Bharat", benefit: "Iron folic acid supplement for adolescent girls and pregnant women" },
        ].map((scheme) => (
          <div key={scheme.name} className="flex justify-between items-center p-3 bg-red-50 border border-red-200 rounded-xl">
            <div>
              <h3 className="font-bold text-sm text-red-800">{scheme.name}</h3>
              <p className="text-xs text-muted-foreground">{scheme.benefit}</p>
            </div>
          </div>
        ))}
      </div>

      <h2 className="text-xl font-bold">Education & Employment Schemes</h2>
      <div className="space-y-2">
        {[
          { name: "PM USHA (Higher Education for Women)", benefit: "Scholarship for girl students in higher education" },
          { name: "NRLM / Mahila SHG Scheme", benefit: "Self Help Groups with ₹1.5 lakh revolving fund support" },
          { name: "Aajeevika – DAY-NRLM", benefit: "Livelihood training and ₹15,000 capital support for rural women" },
          { name: "PM Kaushal Vikas Yojana (Women)", benefit: "Free skill training for women in 300+ courses" },
        ].map((scheme) => (
          <div key={scheme.name} className="flex justify-between items-center p-3 bg-purple-50 border border-purple-200 rounded-xl">
            <div>
              <h3 className="font-bold text-sm text-purple-800">{scheme.name}</h3>
              <p className="text-xs text-muted-foreground">{scheme.benefit}</p>
            </div>
          </div>
        ))}
      </div>

      <FaqSection faqs={[
        { q: "Which is the best scheme for women in India in 2026?", a: "PM Matru Vandana Yojana (₹11,000 cash), Sukanya Samriddhi Yojana (8.2% savings), Udyogini (0% loan for entrepreneurs), and JSY (delivery cash incentive) are the most impactful women's schemes in 2026." },
        { q: "How to apply for women government schemes?", a: "Visit myscheme.gov.in to find all eligible schemes. Most can be applied at Anganwadi centers, CSC centers, bank branches, or online through the respective ministry portals." },
        { q: "Is there a unified portal for women schemes?", a: "Yes. WCD Ministry's portal wcd.nic.in and myscheme.gov.in list all women-specific schemes. Some states have dedicated portals like Maharashtra's Mahaswayam for women." },
      ]} />

      <InternalLinks links={[
        { label: "Farmer Schemes", href: "/seo/farmer-schemes-india" },
        { label: "PM Yojana List", href: "/seo/pm-yojana-list" },
        { label: "All Schemes", href: "/schemes" },
        { label: "Latest Govt Jobs", href: "/seo/latest-govt-jobs-2026" },
        { label: "Age Calculator", href: "/tools/age-calculator" },
      ]} />
    </div>
  );
}

// ─── Farmer Schemes India ─────────────────────────────────────────────────────

export function FarmerSchemesIndia() {
  return (
    <div className="space-y-6">
      <p className="text-muted-foreground leading-relaxed">
        India's central and state governments run over 50 dedicated schemes for farmers in 2026. From direct income support under PM Kisan to crop insurance under PMFBY, from subsidized credit under KCC to equipment subsidies, these schemes collectively benefit over 14 crore farmers annually. Here is the complete guide to all farmer government schemes in India 2026.
      </p>

      <div className="grid md:grid-cols-3 gap-4">
        <div className="bg-green-50 border border-green-200 rounded-xl p-4 text-center">
          <div className="text-3xl font-black text-green-700">50+</div>
          <p className="text-sm text-muted-foreground mt-1">Active Farmer Schemes</p>
        </div>
        <div className="bg-orange-50 border border-orange-200 rounded-xl p-4 text-center">
          <div className="text-3xl font-black text-orange-600">14 Cr</div>
          <p className="text-sm text-muted-foreground mt-1">Farmers Benefited</p>
        </div>
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 text-center">
          <div className="text-3xl font-black text-blue-700">₹2.5L Cr</div>
          <p className="text-sm text-muted-foreground mt-1">Annual Agriculture Budget</p>
        </div>
      </div>

      <h2 className="text-xl font-bold">Complete List of Farmer Schemes 2026</h2>

      {[
        {
          category: "Income Support", color: "green",
          schemes: [
            { name: "PM Kisan Samman Nidhi", benefit: "₹6,000/year in 3 installments", link: "/seo/pm-kisan-yojana" },
            { name: "PM Kisan Maan Dhan Yojana", benefit: "₹3,000/month pension for farmers aged 60+" },
            { name: "MGNREGA for Farmers", benefit: "100 days employment for agricultural workers" },
          ]
        },
        {
          category: "Credit & Insurance", color: "blue",
          schemes: [
            { name: "Kisan Credit Card (KCC)", benefit: "₹3 lakh credit at 4% interest", link: "/seo/kisan-credit-card" },
            { name: "PM Fasal Bima Yojana", benefit: "Crop insurance at 1.5–2% premium", link: "/seo/crop-insurance-scheme" },
            { name: "Agri Infrastructure Fund", benefit: "₹1 lakh crore credit for agri infrastructure" },
          ]
        },
        {
          category: "Equipment & Technology", color: "orange",
          schemes: [
            { name: "PM Kisan Tractor Yojana", benefit: "20–50% subsidy on tractors", link: "/seo/tractor-subsidy-scheme" },
            { name: "Sub-Mission on Agricultural Mechanization", benefit: "25–50% subsidy on farm machinery" },
            { name: "Digital Agriculture Mission", benefit: "Digital IDs, drones, and smart farming tech" },
          ]
        },
      ].map((cat) => (
        <div key={cat.category}>
          <h3 className={`text-lg font-bold text-${cat.color}-700 mb-2 flex items-center gap-2`}>
            <span className={`w-3 h-3 rounded-full bg-${cat.color}-500`} /> {cat.category}
          </h3>
          <div className="space-y-2">
            {cat.schemes.map((scheme) => (
              <div key={scheme.name} className={`flex justify-between items-center p-3 bg-${cat.color}-50 border border-${cat.color}-200 rounded-xl`}>
                <div>
                  <h4 className="font-bold text-sm">{scheme.name}</h4>
                  <p className="text-xs text-muted-foreground">{scheme.benefit}</p>
                </div>
                {scheme.link
                  ? <Link href={scheme.link}><Badge variant="outline" className={`border-${cat.color}-400 text-${cat.color}-700 cursor-pointer`}>Details</Badge></Link>
                  : <Badge variant="outline" className="border-gray-300">Active</Badge>}
              </div>
            ))}
          </div>
        </div>
      ))}

      <AdSense slot="farmer_schemes_inline" />

      <FaqSection faqs={[
        { q: "How many government schemes are available for farmers in 2026?", a: "Over 50 central government schemes and 100+ state-level schemes are active for farmers in 2026. The major ones include PM Kisan, PMFBY, KCC, PM Kisan Tractor Yojana, and PM Krishi Sinchai Yojana." },
        { q: "Which farmer scheme gives maximum benefit?", a: "PM Kisan gives ₹6,000/year direct cash. KCC provides ₹3L credit at 4%. PMFBY provides crop insurance. Tractor Yojana gives 50% subsidy. Combined, these schemes can benefit farmers by ₹50,000–₹2 lakh per year." },
        { q: "How to check all farmer schemes I am eligible for?", a: "Visit myscheme.gov.in, select 'Farmer' as occupation, and fill your details. The portal shows all central and state schemes you qualify for along with application links." },
      ]} />

      <InternalLinks links={[
        { label: "PM Kisan Yojana", href: "/seo/pm-kisan-yojana" },
        { label: "Kisan Credit Card", href: "/seo/kisan-credit-card" },
        { label: "Crop Insurance", href: "/seo/crop-insurance-scheme" },
        { label: "Tractor Subsidy", href: "/seo/tractor-subsidy-scheme" },
        { label: "Women Schemes", href: "/seo/women-schemes-india" },
      ]} />
    </div>
  );
}
