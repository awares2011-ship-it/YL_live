import { Link } from "wouter";
import { Advertisement } from "./Advertisement";
import { useI18n } from "@/lib/i18n";

export function Footer() {
  const { t } = useI18n();

  return (
    <footer className="bg-accent text-accent-foreground mt-16 py-12 border-t-4 border-primary">
      <div className="container mx-auto px-4">
        <Advertisement />
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8 mt-8">
          <div className="col-span-1 md:col-span-2">
            <Link href="/" className="flex items-center space-x-2 group mb-4">
              <div className="flex flex-col gap-0.5 mr-2">
                <div className="w-4 h-1.5 bg-[#FF9933] rounded-sm" />
                <div className="w-4 h-1.5 bg-white rounded-sm" />
                <div className="w-4 h-1.5 bg-[#138808] rounded-sm" />
              </div>
              <span className="font-extrabold text-2xl tracking-tight">
                <span className="text-primary">gov</span><span className="text-secondary">Jobs</span><span className="text-accent-foreground">Info</span>
              </span>
            </Link>
            <p className="text-accent-foreground/70 text-sm max-w-sm font-medium leading-relaxed mb-4">
              {t.siteTagline}
            </p>
          </div>

          <div>
            <h3 className="font-bold text-lg mb-4">{t.quickLinks}</h3>
            <ul className="space-y-2 text-sm font-medium text-accent-foreground/80">
              <li><Link href="/" className="hover:text-primary transition-colors">{t.home}</Link></li>
              <li><Link href="/jobs" className="hover:text-primary transition-colors">{t.latestGovtJobs}</Link></li>
              <li><Link href="/schemes" className="hover:text-primary transition-colors">{t.schemes}</Link></li>
              <li><Link href="/blogs" className="hover:text-primary transition-colors">{t.newsUpdates}</Link></li>
              <li><Link href="/tools" className="hover:text-primary transition-colors">{t.calculatorsTools}</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-bold text-lg mb-4">{t.popularCategories}</h3>
            <ul className="space-y-2 text-sm font-medium text-accent-foreground/80">
              <li><Link href="/jobs/ssc" className="hover:text-primary transition-colors">{t.sscJobs}</Link></li>
              <li><Link href="/jobs/railway" className="hover:text-primary transition-colors">{t.railwayJobs}</Link></li>
              <li><Link href="/jobs/bank" className="hover:text-primary transition-colors">{t.bankJobs}</Link></li>
              <li><Link href="/schemes/kisan" className="hover:text-primary transition-colors">{t.pmKisanYojana}</Link></li>
            </ul>
          </div>
        </div>

        <div className="bg-accent-foreground/5 rounded-lg p-4 mb-8 text-xs text-accent-foreground/60 font-medium text-center border border-accent-foreground/10">
          <p><strong className="text-accent-foreground">{t.disclaimer}:</strong> {t.disclaimerText}</p>
        </div>

        <div className="flex flex-col md:flex-row justify-between items-center text-xs text-accent-foreground/50 pt-6 border-t border-accent-foreground/10">
          <p>© {new Date().getFullYear()} govJobsInfo. {t.allRightsReserved}</p>
          <div className="flex space-x-4 mt-4 md:mt-0">
            <span className="hover:text-accent-foreground cursor-pointer">Privacy Policy</span>
            <span className="hover:text-accent-foreground cursor-pointer">Terms of Service</span>
            <span className="hover:text-accent-foreground cursor-pointer">Contact Us</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
