import { Link } from "wouter";
import { Blog } from "@workspace/api-client-react";
import { Badge } from "./ui/badge";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "./ui/card";
import { CalendarDays, UserCircle2 } from "lucide-react";
import { format } from "date-fns";

export function BlogCard({ blog }: { blog: Blog }) {
  return (
    <Card className="flex flex-col h-full hover-elevate transition-shadow border-border hover:border-accent/50 group">
      <CardHeader className="pb-3">
        <div className="mb-2">
          <Badge variant="outline" className="bg-accent/10 text-accent hover:bg-accent/20 font-semibold uppercase tracking-wider text-xs border-accent/20">
            {blog.category}
          </Badge>
        </div>
        <Link href={`/blogs/${blog.id}`}>
          <CardTitle className="text-lg md:text-xl font-bold text-foreground group-hover:text-accent transition-colors line-clamp-2 leading-tight">
            {blog.title}
          </CardTitle>
        </Link>
      </CardHeader>
      <CardContent className="flex-1 text-sm text-muted-foreground">
        <p className="line-clamp-3">{blog.excerpt}</p>
      </CardContent>
      <CardFooter className="pt-4 border-t border-border/50 flex items-center justify-between text-xs text-muted-foreground font-medium">
        <div className="flex items-center">
          <UserCircle2 className="w-4 h-4 mr-1.5" />
          <span className="truncate max-w-[100px]">{blog.author}</span>
        </div>
        <div className="flex items-center">
          <CalendarDays className="w-4 h-4 mr-1.5" />
          <span>{format(new Date(blog.createdAt), "MMM d, yyyy")}</span>
        </div>
      </CardFooter>
    </Card>
  );
}
