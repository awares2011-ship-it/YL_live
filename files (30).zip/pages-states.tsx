import { Link } from "wouter";
import { Badge } from "@/components/ui/badge";
import AdSense from "@/components/adsense";
import { InternalLinks, FaqSection } from "./pages-extra";

// ─── Shared job card renderer ─────────────────────────────────────────────────

function JobCard({ name, dept, vacancies, salary, color = "blue" }: {
  name: string; dept: string; vacancies: string; salary: string; color?: string;
}) {
  const colors: Record<string, string> = {
    blue: "border-blue-200 bg-blue-50",
    green: "border-green-200 bg-green-50",
    orange: "border-orange-200 bg-orange-50",
    purple: "border-purple-200 bg-purple-50",
    red: "border-red-200 bg-red-50",
    yellow: "border-yellow-200 bg-yellow-50",
    teal: "border-teal-200 bg-teal-50",
  };
  const badgeColors: Record<string, string> = {
    blue: "bg-blue-600", green: "bg-green-600", orange: "bg-orange-500",
    purple: "bg-purple-600", red: "bg-red-600", yellow: "bg-yellow-500",
    teal: "bg-teal-600",
  };
  return (
    <div className={`p-4 border rounded-xl ${colors[color] || colors.blue}`}>
      <div className="flex justify-between items-start gap-2">
        <div>
          <h3 className="font-bold">{name}</h3>
          <p className="text-sm text-muted-foreground">{dept}</p>
        </div>
        <Badge className={`${badgeColors[color] || badgeColors.blue} text-white shrink-0`}>{vacancies}</Badge>
      </div>
      <p className="text-sm mt-2">Salary: <b className="text-orange-600">₹{salary}</b>/month</p>
    </div>
  );
}

// ─── Punjab Jobs ──────────────────────────────────────────────────────────────

export function PunjabJobs() {
  return (
    <div className="space-y-6">
      <p className="text-muted-foreground leading-relaxed">
        Punjab, known as the 'Granary of India', has a strong government job market in 2026. Punjab Public Service Commission (PPSC), Punjab Police, Punjab Education Department, and various PSUs offer thousands of government vacancies for Punjab residents. In 2026, over 25,000 government jobs are available across various state departments in Punjab.
      </p>

      <div className="grid md:grid-cols-3 gap-4">
        <div className="bg-orange-50 border border-orange-200 rounded-xl p-4 text-center">
          <div className="text-3xl font-black text-orange-700">25,000+</div>
          <p className="text-sm text-muted-foreground mt-1">2026 Vacancies</p>
        </div>
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 text-center">
          <div className="text-3xl font-black text-blue-700">PPSC</div>
          <p className="text-sm text-muted-foreground mt-1">Main Recruiter</p>
        </div>
        <div className="bg-green-50 border border-green-200 rounded-xl p-4 text-center">
          <div className="text-3xl font-black text-green-700">Punjabi</div>
          <p className="text-sm text-muted-foreground mt-1">Language Required</p>
        </div>
      </div>

      <h2 className="text-xl font-bold">Top Punjab Government Jobs 2026</h2>
      <div className="space-y-3">
        <JobCard name="Punjab Police Sub Inspector" dept="Punjab Police" vacancies="700+" salary="35,400–1,12,400" color="blue" />
        <JobCard name="PPSC PCS 2026" dept="Punjab Public Service Commission" vacancies="150" salary="44,900–1,42,400" color="orange" />
        <JobCard name="Punjab Constable" dept="Punjab Police" vacancies="1,746" salary="21,700–69,100" color="blue" />
        <JobCard name="Punjab Teacher (JBT/ETT)" dept="Punjab Education Dept" vacancies="8,393" salary="29,200–92,300" color="green" />
        <JobCard name="PSPCL Lineman/JE" dept="Punjab State Power Corporation" vacancies="2,000+" salary="19,900–63,200" color="yellow" />
        <JobCard name="Punjab HSSC Clerk" dept="Punjab Govt Various Depts" vacancies="1,152" salary="18,000–56,900" color="purple" />
      </div>

      <AdSense slot="punjab_jobs_inline" />

      <h2 className="text-xl font-bold">How to Apply for Punjab Government Jobs</h2>
      <div className="space-y-2">
        {[
          "Visit Punjab Govt job portal: punjabgovjobs.in or ppsc.gov.in",
          "Register with valid email and mobile number",
          "Fill application form in English and Punjabi",
          "Upload documents: Aadhaar, educational certificates, caste certificate",
          "Pay application fee via net banking/UPI",
          "Punjabi language proficiency (Gurmukhi script) is mandatory for most posts",
        ].map((step, i) => (
          <div key={i} className="flex gap-3 items-start p-2 bg-orange-50 border border-orange-100 rounded-xl">
            <span className="w-6 h-6 rounded-full bg-orange-500 text-white flex items-center justify-center font-bold text-xs shrink-0">{i + 1}</span>
            <p className="text-sm text-muted-foreground">{step}</p>
          </div>
        ))}
      </div>

      <FaqSection faqs={[
        { q: "Is Punjabi language knowledge necessary for Punjab govt jobs?", a: "Yes, for most Punjab state government posts, Punjabi language (Gurmukhi script, reading and writing) is mandatory. PPSC exam includes a Punjabi language paper of 100 marks." },
        { q: "What is the PPSC PCS exam?", a: "Punjab Public Service Commission (PCS) exam is Punjab's premier civil services exam for posts like PCS Officer, DSP, Tehsildar. Conducted in 3 stages: Preliminary, Main Exam, Interview." },
        { q: "How to apply for Punjab Police Constable?", a: "Visit punjabpolice.gov.in or the official Punjab Police recruitment portal. Complete online application with documents. Physical and written tests are conducted." },
      ]} />

      <InternalLinks links={[
        { label: "Maharashtra Jobs", href: "/seo/maharashtra-govt-jobs" },
        { label: "UP Jobs", href: "/seo/up-govt-jobs" },
        { label: "Bihar Jobs", href: "/seo/bihar-govt-jobs" },
        { label: "Latest Govt Jobs 2026", href: "/seo/latest-govt-jobs-2026" },
        { label: "Age Calculator", href: "/tools/age-calculator" },
      ]} />
    </div>
  );
}

// ─── Rajasthan Jobs ───────────────────────────────────────────────────────────

export function RajasthanJobs() {
  return (
    <div className="space-y-6">
      <p className="text-muted-foreground leading-relaxed">
        Rajasthan, India's largest state by area, has one of the most active state government recruitment drives in 2026. Rajasthan Public Service Commission (RPSC), Rajasthan Police, REET for teachers, and Rajasthan SSC (RSMSSB) release mega recruitment notifications every year. In 2026, over 75,000 government vacancies are available across Rajasthan.
      </p>

      <div className="grid md:grid-cols-3 gap-4">
        <div className="bg-orange-50 border border-orange-200 rounded-xl p-4 text-center">
          <div className="text-2xl font-black text-orange-700">75,000+</div>
          <p className="text-sm text-muted-foreground mt-1">2026 Vacancies</p>
        </div>
        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4 text-center">
          <div className="text-2xl font-black text-yellow-700">RPSC</div>
          <p className="text-sm text-muted-foreground mt-1">Main Recruiter</p>
        </div>
        <div className="bg-green-50 border border-green-200 rounded-xl p-4 text-center">
          <div className="text-2xl font-black text-green-700">REET</div>
          <p className="text-sm text-muted-foreground mt-1">Teacher Exam</p>
        </div>
      </div>

      <h2 className="text-xl font-bold">Top Rajasthan Government Jobs 2026</h2>
      <div className="space-y-3">
        <JobCard name="RPSC RAS 2026" dept="Rajasthan Public Service Commission" vacancies="905" salary="56,100–1,77,500" color="orange" />
        <JobCard name="Rajasthan Police Constable" dept="Rajasthan Police" vacancies="13,000+" salary="21,700–69,100" color="blue" />
        <JobCard name="REET Level 1 & 2 Teacher" dept="BSER Rajasthan" vacancies="48,000" salary="29,200–92,300" color="green" />
        <JobCard name="RSMSSB Patwari" dept="Rajasthan SSC" vacancies="4,207" salary="20,800–66,800" color="yellow" />
        <JobCard name="RSEB JE/AEN" dept="Rajasthan Energy Dept" vacancies="3,200" salary="33,800–1,06,800" color="purple" />
        <JobCard name="Rajasthan Gramin Dak Sevak" dept="India Post Rajasthan" vacancies="2,679" salary="10,000–29,000" color="teal" />
      </div>

      <AdSense slot="rajasthan_jobs_inline" />

      <h2 className="text-xl font-bold">Rajasthan Job Exam Calendar 2026</h2>
      <div className="space-y-2">
        {[
          { exam: "RPSC RAS Preliminary", month: "February 2026", posts: "905" },
          { exam: "Rajasthan Police Constable", month: "March–April 2026", posts: "13,000+" },
          { exam: "REET Level 1 (Primary)", month: "April 2026", posts: "24,000" },
          { exam: "REET Level 2 (Secondary)", month: "May 2026", posts: "24,000" },
          { exam: "RSMSSB Patwari", month: "June 2026", posts: "4,207" },
        ].map((item) => (
          <div key={item.exam} className="flex justify-between items-center p-3 bg-orange-50 border border-orange-200 rounded-xl">
            <div>
              <h3 className="font-bold text-sm">{item.exam}</h3>
              <p className="text-xs text-muted-foreground">{item.month}</p>
            </div>
            <Badge className="bg-orange-500 text-white">{item.posts}</Badge>
          </div>
        ))}
      </div>

      <FaqSection faqs={[
        { q: "How to apply for RPSC RAS exam 2026?", a: "Visit rpsc.rajasthan.gov.in and register. Apply online when notification is active. RPSC RAS has 3 stages: Preliminary (Objective), Main (Subjective), Interview. Minimum qualification is graduation." },
        { q: "What is REET exam for teachers in Rajasthan?", a: "REET (Rajasthan Eligibility Exam for Teachers) is conducted by BSER for teacher posts. Level 1 is for Classes 1–5 (12th pass), Level 2 for Classes 6–8 (Graduate + B.Ed)." },
        { q: "Is Hindi knowledge required for Rajasthan government jobs?", a: "Yes, Hindi language proficiency (Devanagari script) is required for most Rajasthan state government posts. RPSC exam papers are in Hindi and English both." },
      ]} />

      <InternalLinks links={[
        { label: "UP Jobs", href: "/seo/up-govt-jobs" },
        { label: "Maharashtra Jobs", href: "/seo/maharashtra-govt-jobs" },
        { label: "Latest Govt Jobs 2026", href: "/seo/latest-govt-jobs-2026" },
        { label: "10th Pass Jobs", href: "/seo/10th-pass-govt-jobs" },
        { label: "Age Calculator", href: "/tools/age-calculator" },
      ]} />
    </div>
  );
}

// ─── Gujarat Jobs ─────────────────────────────────────────────────────────────

export function GujaratJobs() {
  return (
    <div className="space-y-6">
      <p className="text-muted-foreground leading-relaxed">
        Gujarat, India's industrial powerhouse, offers diverse government job opportunities in 2026. Gujarat Public Service Commission (GPSC), Gujarat Police, GSSSB (Gujarat Subordinate Service Selection Board), and various PSUs and government departments recruit thousands annually. With a strong economy, Gujarat government jobs come with excellent pay, benefits, and career stability.
      </p>

      <h2 className="text-xl font-bold">Top Gujarat Government Jobs 2026</h2>
      <div className="space-y-3">
        <JobCard name="GPSC Class 1/2 Officer" dept="Gujarat Public Service Commission" vacancies="800" salary="44,900–1,42,400" color="orange" />
        <JobCard name="Gujarat Police Constable" dept="LRD Gujarat Police" vacancies="12,000+" salary="21,700–69,100" color="blue" />
        <JobCard name="GSSSB Bin Sachivalay Clerk" dept="Subordinate Service Selection Board" vacancies="3,000+" salary="19,900–63,200" color="green" />
        <JobCard name="Gujarat GAIL/GSECL JE" dept="Gujarat Govt Energy PSUs" vacancies="500" salary="35,400–1,12,400" color="purple" />
        <JobCard name="Gujarat Teacher TAT" dept="Education Dept Gujarat" vacancies="6,500" salary="29,200–92,300" color="teal" />
        <JobCard name="GWSSB Junior Engineer" dept="Gujarat Water Supply Board" vacancies="700" salary="38,090–1,20,540" color="yellow" />
      </div>

      <AdSense slot="gujarat_jobs_inline" />

      <h2 className="text-xl font-bold">Gujarat Government Job Portals</h2>
      <div className="space-y-2">
        {[
          { name: "GPSC", url: "gpsc.gujarat.gov.in", role: "Class 1 & 2 Officers" },
          { name: "GSSSB", url: "gsssb.gujarat.gov.in", role: "Class 3 & 4 Posts" },
          { name: "LRD (Police)", url: "lrdgujarat.gujarat.gov.in", role: "Constable & SI Posts" },
          { name: "Ojas Portal", url: "ojas.gujarat.gov.in", role: "All Gujarat Recruitment" },
          { name: "GSSRTC", url: "gsrtc.in", role: "Driver & Conductor Posts" },
        ].map((portal) => (
          <div key={portal.name} className="flex justify-between items-center p-3 bg-orange-50 border border-orange-200 rounded-xl">
            <div>
              <h3 className="font-bold text-sm">{portal.name}</h3>
              <p className="text-xs text-muted-foreground">{portal.role}</p>
            </div>
            <Badge variant="outline" className="border-orange-400 text-orange-700 text-xs">{portal.url}</Badge>
          </div>
        ))}
      </div>

      <FaqSection faqs={[
        { q: "Is Gujarati language required for Gujarat government jobs?", a: "Yes, proficiency in Gujarati language (reading, writing, and speaking) is required for state government posts in Gujarat. GPSC exam includes a Gujarati language paper." },
        { q: "What is Ojas portal for Gujarat jobs?", a: "Ojas (ojas.gujarat.gov.in) is the central government recruitment portal of Gujarat. All government job notifications, applications, admit cards and results for Gujarat state are available on Ojas." },
        { q: "How to apply for Gujarat Police Constable 2026?", a: "LRD (Lokrakshak Recruitment Board) conducts Gujarat Police Constable exam. Apply at lrdgujarat.gujarat.gov.in. Selection includes Physical Test, Written Exam and Document Verification." },
      ]} />

      <InternalLinks links={[
        { label: "Maharashtra Jobs", href: "/seo/maharashtra-govt-jobs" },
        { label: "Rajasthan Jobs", href: "/seo/rajasthan-govt-jobs" },
        { label: "Latest Govt Jobs 2026", href: "/seo/latest-govt-jobs-2026" },
        { label: "12th Pass Jobs", href: "/seo/12th-pass-govt-jobs" },
        { label: "Age Calculator", href: "/tools/age-calculator" },
      ]} />
    </div>
  );
}

// ─── Tamil Nadu Jobs ──────────────────────────────────────────────────────────

export function TamilNaduJobs() {
  return (
    <div className="space-y-6">
      <p className="text-muted-foreground leading-relaxed">
        Tamil Nadu is one of India's most developed states with a very active government job market. Tamil Nadu Public Service Commission (TNPSC), Tamil Nadu Police, TANGEDCO, and various state government boards release major recruitment notifications in 2026. The state offers jobs from clerical level to IAS cadre, with competitive salaries under Tamil Nadu pay scales.
      </p>

      <h2 className="text-xl font-bold">Top Tamil Nadu Government Jobs 2026</h2>
      <div className="space-y-3">
        <JobCard name="TNPSC Group 1 Services" dept="Tamil Nadu Public Service Commission" vacancies="69" salary="56,100–1,77,500" color="red" />
        <JobCard name="TNPSC Group 2 (Interview Posts)" dept="TNPSC" vacancies="1,199" salary="38,600–1,22,800" color="orange" />
        <JobCard name="TNPSC Group 4 (Clerical)" dept="TNPSC" vacancies="4,000+" salary="19,500–62,000" color="green" />
        <JobCard name="Tamil Nadu Police Constable" dept="TNUSRB" vacancies="6,700" salary="21,700–69,100" color="blue" />
        <JobCard name="TANGEDCO (Electricity Board)" dept="TN Power Sector" vacancies="3,000+" salary="25,500–81,100" color="yellow" />
        <JobCard name="TN Teacher (TRB)" dept="Teacher Recruitment Board" vacancies="8,000+" salary="35,400–1,12,400" color="purple" />
      </div>

      <AdSense slot="tamilnadu_jobs_inline" />

      <h2 className="text-xl font-bold">TNPSC Exams – Complete Guide</h2>
      <div className="space-y-2">
        {[
          { group: "Group 1", desc: "DSP, Deputy Collector, BDO posts", qual: "Degree", stage: "3 stages" },
          { group: "Group 2 (Interview)", desc: "Sub-Registrar, HR Officer", qual: "Degree", stage: "3 stages" },
          { group: "Group 2A (No Interview)", desc: "Junior Analyst, Draughtsman", qual: "Diploma/Degree", stage: "Written only" },
          { group: "Group 4", desc: "VAO, Junior Assistants, Typist", qual: "10th/12th", stage: "Written + Certificate" },
          { group: "CCSE (CSCS)", desc: "Combined Civil Services", qual: "Degree", stage: "2 stages" },
        ].map((g) => (
          <div key={g.group} className="p-3 bg-red-50 border border-red-200 rounded-xl">
            <div className="flex justify-between items-center">
              <h3 className="font-bold text-sm text-red-800">{g.group}</h3>
              <Badge variant="outline" className="border-red-300 text-red-700 text-xs">{g.stage}</Badge>
            </div>
            <p className="text-xs text-muted-foreground mt-1">{g.desc} | Qual: {g.qual}</p>
          </div>
        ))}
      </div>

      <FaqSection faqs={[
        { q: "Is Tamil language mandatory for TNPSC exams?", a: "Yes, Tamil language (reading and writing) is compulsory for all TNPSC exams. There is a General Tamil/General English paper carrying 100 marks. Minimum pass mark is 40." },
        { q: "How to apply for TNPSC Group 4 2026?", a: "Visit tnpscexams.in and register with Aadhaar and email. Apply during the notification period. TNPSC Group 4 exam is conducted for VAO, Junior Assistant, Typist, and Steno-Typist posts." },
        { q: "What is the TNPSC Group 1 age limit?", a: "TNPSC Group 1 age limit: 21–32 years (General), up to 37 for BC/BCM, up to 38 for MBC/DNC, up to 35 for SC/ST. Government employees have extended age limit up to 40." },
      ]} />

      <InternalLinks links={[
        { label: "Karnataka Jobs", href: "/seo/karnataka-govt-jobs" },
        { label: "Latest Govt Jobs 2026", href: "/seo/latest-govt-jobs-2026" },
        { label: "Graduate Jobs", href: "/seo/graduate-govt-jobs" },
        { label: "12th Pass Jobs", href: "/seo/12th-pass-govt-jobs" },
        { label: "Age Calculator", href: "/tools/age-calculator" },
      ]} />
    </div>
  );
}

// ─── Karnataka Jobs ───────────────────────────────────────────────────────────

export function KarnatakaJobs() {
  return (
    <div className="space-y-6">
      <p className="text-muted-foreground leading-relaxed">
        Karnataka, home to Bengaluru (India's IT capital), has a booming government job market in 2026. Karnataka Public Service Commission (KPSC), Karnataka Police, BESCOM, HESCOM, and various Zilla Panchayat departments recruit thousands annually. Karnataka government jobs are highly competitive with lakhs of applicants for each notification.
      </p>

      <h2 className="text-xl font-bold">Top Karnataka Government Jobs 2026</h2>
      <div className="space-y-3">
        <JobCard name="KPSC Gazetted Probationer" dept="Karnataka PSC" vacancies="545" salary="56,100–1,77,500" color="orange" />
        <JobCard name="Karnataka Police Constable" dept="Karnataka State Police" vacancies="4,000+" salary="21,700–69,100" color="blue" />
        <JobCard name="KPSC FDA/SDA" dept="First/Second Division Assistants" vacancies="3,000+" salary="21,400–67,000" color="green" />
        <JobCard name="BESCOM JE / AE" dept="Bangalore Electricity Supply Company" vacancies="1,500" salary="35,400–1,12,400" color="purple" />
        <JobCard name="Karnataka Teacher (TET/DEd)" dept="DSERT Karnataka" vacancies="15,000+" salary="29,200–92,300" color="teal" />
        <JobCard name="KSRTC Conductor/Driver" dept="Karnataka State Road Transport" vacancies="5,000" salary="16,000–36,000" color="yellow" />
      </div>

      <AdSense slot="karnataka_jobs_inline" />

      <h2 className="text-xl font-bold">Important Karnataka Job Portals 2026</h2>
      <div className="space-y-2">
        {[
          { name: "KPSC Official Portal", url: "kpsc.kar.nic.in", role: "All KPSC Recruitment" },
          { name: "Bangaluru One / Karnataka One", url: "karunadu.karnataka.gov.in", role: "State Services Portal" },
          { name: "KSP (Police)", url: "ksp.karnataka.gov.in", role: "Police Recruitment" },
          { name: "Sakala Portal", url: "sakala.karnataka.gov.in", role: "Govt Service Delivery" },
        ].map((portal) => (
          <div key={portal.name} className="flex justify-between items-center p-3 bg-orange-50 border border-orange-200 rounded-xl">
            <div>
              <h3 className="font-bold text-sm">{portal.name}</h3>
              <p className="text-xs text-muted-foreground">{portal.role}</p>
            </div>
            <Badge variant="outline" className="border-orange-400 text-orange-700 text-xs">{portal.url}</Badge>
          </div>
        ))}
      </div>

      <FaqSection faqs={[
        { q: "Is Kannada language required for Karnataka govt jobs?", a: "Yes, knowledge of Kannada (reading, writing, speaking) is mandatory for state government jobs in Karnataka. KPSC exam includes a Kannada language paper. Some posts require Kannada medium education up to SSLC level." },
        { q: "What is KPSC FDA SDA exam?", a: "FDA (First Division Assistant) and SDA (Second Division Assistant) are clerical posts in Karnataka government departments. KPSC conducts this exam separately. FDA requires graduate qualification, SDA requires 12th pass." },
        { q: "How many attempts are there for KPSC Gazetted Probationer?", a: "KPSC GP (IAS equivalent at state level) has no attempt limit but has age limit: 21-35 years (General), up to 38 for OBC, up to 40 for SC/ST. You can appear until you cross the age limit." },
      ]} />

      <InternalLinks links={[
        { label: "Tamil Nadu Jobs", href: "/seo/tamilnadu-govt-jobs" },
        { label: "Maharashtra Jobs", href: "/seo/maharashtra-govt-jobs" },
        { label: "Latest Govt Jobs 2026", href: "/seo/latest-govt-jobs-2026" },
        { label: "Graduate Jobs", href: "/seo/graduate-govt-jobs" },
        { label: "Age Calculator", href: "/tools/age-calculator" },
      ]} />
    </div>
  );
}

// ─── Delhi Jobs ───────────────────────────────────────────────────────────────

export function DelhiJobs() {
  return (
    <div className="space-y-6">
      <p className="text-muted-foreground leading-relaxed">
        Delhi — the National Capital Territory — offers unique government job opportunities both at the central government and Delhi state level. DSSSB (Delhi Subordinate Services Selection Board), Delhi Police, Delhi Metro (DMRC), MCD, and dozens of central government ministries headquartered in Delhi recruit thousands annually. Delhi-based central government jobs are especially prized for their prestige and pay.
      </p>

      <h2 className="text-xl font-bold">Top Delhi Government Jobs 2026</h2>
      <div className="space-y-3">
        <JobCard name="DSSSB PRT/TGT/PGT Teacher" dept="Delhi Subordinate Services Selection Board" vacancies="7,236" salary="35,400–1,12,400" color="red" />
        <JobCard name="Delhi Police Constable" dept="Delhi Police" vacancies="5,846" salary="21,700–69,100" color="blue" />
        <JobCard name="DMRC JE/CRA" dept="Delhi Metro Rail Corporation" vacancies="1,200" salary="35,400–1,12,400" color="teal" />
        <JobCard name="DSSSB Patwari / Accounts Asst" dept="DSSSB Various Depts" vacancies="3,000" salary="25,500–81,100" color="green" />
        <JobCard name="MCD Multi Tasking Staff" dept="Municipal Corporation of Delhi" vacancies="2,500" salary="18,000–56,900" color="yellow" />
        <JobCard name="Delhi Jal Board JE" dept="Delhi Jal Board" vacancies="500" salary="35,400–1,12,400" color="purple" />
      </div>

      <AdSense slot="delhi_jobs_inline" />

      <h2 className="text-xl font-bold">Central Government Jobs in Delhi 2026</h2>
      <div className="space-y-2">
        {[
          "SSC CGL posts in Delhi Ministries/Departments",
          "UPSC Civil Services – IAS/IPS/IFS posting in Delhi cadre",
          "RBI / SEBI / IRDA / NABARD HQ Delhi offices",
          "LIC AAO / SBI PO Delhi region postings",
          "Ministry Secretariat Assistants via SSC CHSL",
          "Intelligence Bureau (IB) ACIO recruitment",
        ].map((item, i) => (
          <div key={i} className="flex items-center gap-2 p-2 bg-red-50 border border-red-200 rounded-xl text-sm">
            <span className="text-red-600 font-bold">→</span>
            <span>{item}</span>
          </div>
        ))}
      </div>

      <FaqSection faqs={[
        { q: "What is DSSSB and how to apply?", a: "Delhi Subordinate Services Selection Board (DSSSB) recruits for various posts in Delhi state government departments including teachers, clerks, Patwari, and technical posts. Apply at dsssb.delhi.gov.in." },
        { q: "Is Delhi domicile required for DSSSB jobs?", a: "Yes, some DSSSB posts require Delhi domicile. Candidates must have been living in Delhi for a minimum period (usually 3 years). Check specific notification for domicile requirements." },
        { q: "How to apply for DMRC 2026?", a: "DMRC (Delhi Metro Rail Corporation) recruitment is available at delhimetrorail.com. DMRC hires JE, CRA, Maintainer, SC/TO posts. Written exam followed by medical and document verification." },
      ]} />

      <InternalLinks links={[
        { label: "Latest Govt Jobs 2026", href: "/seo/latest-govt-jobs-2026" },
        { label: "SSC Jobs 2026", href: "/seo/ssc-jobs-2026" },
        { label: "Graduate Jobs", href: "/seo/graduate-govt-jobs" },
        { label: "Maharashtra Jobs", href: "/seo/maharashtra-govt-jobs" },
        { label: "Age Calculator", href: "/tools/age-calculator" },
      ]} />
    </div>
  );
}
