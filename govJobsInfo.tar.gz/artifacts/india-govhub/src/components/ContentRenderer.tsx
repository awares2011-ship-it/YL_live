import React from 'react';

export function ContentRenderer({ content }: { content: string }) {
  if (!content) return null;

  const renderContent = () => {
    const blocks = content.split('\n\n').filter(block => block.trim() !== '');
    
    return blocks.map((block, index) => {
      // Headers
      if (block.startsWith('### ')) {
        return <h3 key={index} className="text-xl font-bold text-accent mt-6 mb-3">{block.substring(4)}</h3>;
      }
      if (block.startsWith('## ')) {
        return <h2 key={index} className="text-2xl font-bold text-accent mt-8 mb-4 border-b border-border pb-2">{block.substring(3)}</h2>;
      }
      if (block.startsWith('# ')) {
        return <h1 key={index} className="text-3xl font-extrabold text-foreground mt-8 mb-4">{block.substring(2)}</h1>;
      }

      // Lists
      if (block.startsWith('- ')) {
        const items = block.split('\n').filter(line => line.startsWith('- '));
        return (
          <ul key={index} className="list-disc pl-5 my-4 space-y-2">
            {items.map((item, i) => {
              let text = item.substring(2);
              text = text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
              return <li key={i} dangerouslySetInnerHTML={{ __html: text }} className="text-foreground/80" />;
            })}
          </ul>
        );
      }

      // Tables
      if (block.includes('|') && block.includes('---')) {
        const lines = block.split('\n');
        const headers = lines[0].split('|').filter(Boolean).map(h => h.trim());
        const rows = lines.slice(2).map(line => line.split('|').filter(Boolean).map(cell => cell.trim()));
        
        return (
          <div key={index} className="overflow-x-auto my-6 rounded-md border border-border">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-muted">
                  {headers.map((header, i) => (
                    <th key={i} className="py-3 px-4 font-bold text-sm text-foreground border-b border-border">{header}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.map((row, i) => (
                  <tr key={i} className="border-b border-border last:border-0 hover:bg-muted/50">
                    {row.map((cell, j) => {
                      let text = cell.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
                      return <td key={j} className="py-3 px-4 text-sm text-foreground/80" dangerouslySetInnerHTML={{ __html: text }} />;
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );
      }

      // Paragraphs with bold formatting
      let formattedText = block.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
      return <p key={index} dangerouslySetInnerHTML={{ __html: formattedText }} className="my-4 text-foreground/80 leading-relaxed" />;
    });
  };

  return <div className="prose-custom max-w-none">{renderContent()}</div>;
}
