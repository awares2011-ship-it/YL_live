import { Link } from "wouter";
import { Badge } from "@/components/ui/badge";
import AdSense from "@/components/adsense";
import { TrendingUp, Briefcase, Leaf, FileText, Wrench, MapPin, ArrowRight } from "lucide-react";

const SEO_HUB_SECTIONS = [
  {
    id: "govt-jobs",
    title: "Government Jobs 2026",
    icon: <Briefcase className="w-5 h-5" />,
    color: "orange",
    pages: [
      { slug: "latest-govt-jobs-2026", label: "🔥 Latest Govt Jobs 2026", badge: "HOT", vacancies: "5 Lakh+" },
      { slug: "10th-pass-govt-jobs", label: "10th Pass Govt Jobs", badge: "NEW", vacancies: "1.5 Lakh+" },
      { slug: "12th-pass-govt-jobs", label: "12th Pass Govt Jobs", badge: null, vacancies: "50,000+" },
      { slug: "graduate-govt-jobs", label: "Graduate Govt Jobs", badge: null, vacancies: "2 Lakh+" },
      { slug: "railway-jobs-2026", label: "🚆 Railway Jobs 2026", badge: "HOT", vacancies: "1.25 Lakh+" },
      { slug: "bank-jobs-2026", label: "🏦 Bank Jobs 2026", badge: null, vacancies: "25,000+" },
      { slug: "ssc-jobs-2026", label: "SSC Jobs 2026", badge: "HOT", vacancies: "73,000+" },
    ],
  },
  {
    id: "state-jobs",
    title: "State Government Jobs",
    icon: <MapPin className="w-5 h-5" />,
    color: "blue",
    pages: [
      { slug: "up-govt-jobs", label: "UP Govt Jobs 2026", badge: "HOT", vacancies: "1.5 Lakh+" },
      { slug: "bihar-govt-jobs", label: "Bihar Govt Jobs 2026", badge: "NEW", vacancies: "2 Lakh+" },
      { slug: "maharashtra-govt-jobs", label: "Maharashtra Jobs", badge: null, vacancies: "50,000+" },
      { slug: "rajasthan-govt-jobs", label: "Rajasthan Govt Jobs", badge: "HOT", vacancies: "75,000+" },
      { slug: "gujarat-govt-jobs", label: "Gujarat Govt Jobs", badge: null, vacancies: "30,000+" },
      { slug: "punjab-govt-jobs", label: "Punjab Govt Jobs", badge: null, vacancies: "25,000+" },
      { slug: "tamilnadu-govt-jobs", label: "Tamil Nadu Jobs", badge: null, vacancies: "40,000+" },
      { slug: "karnataka-govt-jobs", label: "Karnataka Jobs", badge: null, vacancies: "35,000+" },
      { slug: "delhi-govt-jobs", label: "Delhi Govt Jobs", badge: "NEW", vacancies: "20,000+" },
    ],
  },
  {
    id: "kisan",
    title: "Kisan Yojana & Schemes",
    icon: <Leaf className="w-5 h-5" />,
    color: "green",
    pages: [
      { slug: "pm-kisan-yojana", label: "🌾 PM Kisan Yojana", badge: "HOT", vacancies: "11 Cr Farmers" },
      { slug: "pm-kisan-status-check", label: "PM Kisan Status Check", badge: "TRENDING", vacancies: "Check Now" },
      { slug: "kisan-credit-card", label: "Kisan Credit Card", badge: "NEW", vacancies: "₹3L at 4%" },
      { slug: "crop-insurance-scheme", label: "Crop Insurance PMFBY", badge: null, vacancies: "5.5 Cr" },
      { slug: "tractor-subsidy-scheme", label: "Tractor Subsidy 50%", badge: "NEW", vacancies: "28 States" },
    ],
  },
  {
    id: "schemes",
    title: "Central Government Schemes",
    icon: <FileText className="w-5 h-5" />,
    color: "purple",
    pages: [
      { slug: "pm-yojana-list", label: "📋 PM Yojana List 2026", badge: "HOT", vacancies: "100+ Schemes" },
      { slug: "women-schemes-india", label: "👩 Women Schemes India", badge: "NEW", vacancies: "50+ Schemes" },
      { slug: "farmer-schemes-india", label: "🌾 Farmer Schemes India", badge: null, vacancies: "50+ Schemes" },
    ],
  },
  {
    id: "tools",
    title: "Free Online Tools",
    icon: <Wrench className="w-5 h-5" />,
    color: "teal",
    pages: [
      { slug: "emi-calculator", label: "💰 EMI Calculator", badge: null, vacancies: "Home/Car Loan" },
      { slug: "age-calculator", label: "📅 Age Calculator", badge: "TRENDING", vacancies: "Exam Eligibility" },
      { slug: "image-compressor", label: "🖼️ Image Compressor", badge: null, vacancies: "Govt Forms" },
    ],
  },
];

const BADGE_STYLES: Record<string, string> = {
  HOT: "bg-red-500 text-white",
  NEW: "bg-green-500 text-white",
  TRENDING: "bg-orange-500 text-white",
};

const SECTION_COLORS: Record<string, { bg: string; border: string; text: string; header: string }> = {
  orange: { bg: "bg-orange-50", border: "border-orange-200", text: "text-orange-700", header: "bg-orange-500" },
  blue: { bg: "bg-blue-50", border: "border-blue-200", text: "text-blue-700", header: "bg-blue-600" },
  green: { bg: "bg-green-50", border: "border-green-200", text: "text-green-700", header: "bg-green-600" },
  purple: { bg: "bg-purple-50", border: "border-purple-200", text: "text-purple-700", header: "bg-purple-600" },
  teal: { bg: "bg-teal-50", border: "border-teal-200", text: "text-teal-700", header: "bg-teal-600" },
};

export default function SeoHub() {
  return (
    <div className="max-w-5xl mx-auto">
      {/* Page Title */}
      <div className="text-center mb-8">
        <Badge className="bg-red-500 text-white mb-3 text-sm px-4 py-1">🔥 SEO Resource Hub</Badge>
        <h1 className="text-3xl md:text-4xl font-extrabold mb-3">
          India GovHub – Complete Guide to Sarkari Naukri & Yojana
        </h1>
        <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
          Your one-stop destination for government jobs, PM Kisan updates, central schemes, and free tools. Updated daily.
        </p>
        <div className="flex flex-wrap justify-center gap-3 mt-4">
          <span className="bg-orange-100 text-orange-700 px-3 py-1 rounded-full text-sm font-bold">27+ SEO Pages</span>
          <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-bold">9 State Pages</span>
          <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-bold">5 Kisan Pages</span>
          <span className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-sm font-bold">Updated Daily</span>
        </div>
      </div>

      <AdSense slot="seo_hub_top" style={{ height: 90 }} />

      {/* Trending Today */}
      <div className="mb-8 p-4 bg-gradient-to-r from-orange-50 to-red-50 border border-orange-200 rounded-2xl">
        <h2 className="font-extrabold text-lg mb-3 flex items-center gap-2 text-orange-800">
          <TrendingUp className="w-5 h-5" /> Trending Today
        </h2>
        <div className="flex flex-wrap gap-2">
          {[
            { label: "🚆 Railway Group D Result", href: "/trending" },
            { label: "🌾 PM Kisan 17th Installment", href: "/seo/pm-kisan-status-check" },
            { label: "🏦 SBI Clerk 2026", href: "/seo/bank-jobs-2026" },
            { label: "👮 UP Police Constable", href: "/seo/up-govt-jobs" },
            { label: "📋 New Yojana Launched", href: "/seo/pm-yojana-list" },
            { label: "🎓 SSC CGL 2026 Notification", href: "/seo/ssc-jobs-2026" },
          ].map((t) => (
            <Link key={t.href} href={t.href}>
              <span className="inline-block bg-white border border-orange-300 text-orange-700 px-3 py-1.5 rounded-full text-sm font-semibold hover:bg-orange-100 transition-colors cursor-pointer">
                {t.label}
              </span>
            </Link>
          ))}
        </div>
      </div>

      {/* Section Grid */}
      <div className="space-y-8">
        {SEO_HUB_SECTIONS.map((section) => {
          const c = SECTION_COLORS[section.color] || SECTION_COLORS.orange;
          return (
            <div key={section.id} className={`border rounded-2xl overflow-hidden ${c.border}`}>
              {/* Section Header */}
              <div className={`${c.header} text-white px-5 py-3 flex items-center gap-2`}>
                {section.icon}
                <h2 className="font-extrabold text-lg">{section.title}</h2>
              </div>

              {/* Pages Grid */}
              <div className={`${c.bg} p-4 grid md:grid-cols-2 lg:grid-cols-3 gap-3`}>
                {section.pages.map((page) => (
                  <Link key={page.slug} href={`/seo/${page.slug}`}>
                    <div className={`bg-white border ${c.border} rounded-xl p-3 hover:shadow-md transition-all hover:-translate-y-0.5 cursor-pointer group`}>
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <span className={`font-bold text-sm ${c.text} group-hover:underline`}>{page.label}</span>
                        {page.badge && (
                          <Badge className={`${BADGE_STYLES[page.badge]} text-[10px] px-1.5 py-0 shrink-0`}>
                            {page.badge}
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-muted-foreground">{page.vacancies}</span>
                        <ArrowRight className={`w-3 h-3 ${c.text} opacity-0 group-hover:opacity-100 transition-opacity`} />
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      <AdSense slot="seo_hub_middle" />

      {/* "People Also Read" Section */}
      <div className="mt-8 p-5 bg-gray-50 border border-border rounded-2xl">
        <h2 className="font-extrabold text-lg mb-4">📚 People Also Read</h2>
        <div className="grid md:grid-cols-2 gap-3">
          {[
            { href: "/seo/latest-govt-jobs-2026", title: "Latest Govt Jobs 2026", desc: "5 Lakh+ vacancies across all departments" },
            { href: "/seo/pm-kisan-yojana", title: "PM Kisan Yojana 2026", desc: "₹6,000/year benefit for 11 crore farmers" },
            { href: "/seo/railway-jobs-2026", title: "Railway Jobs 2026", desc: "1.25 Lakh+ vacancies – 10th/12th pass eligible" },
            { href: "/seo/pm-yojana-list", title: "PM Yojana List 2026", desc: "Complete list of 100+ active government schemes" },
            { href: "/seo/graduate-govt-jobs", title: "Graduate Govt Jobs 2026", desc: "UPSC, SSC CGL, Bank PO – salary up to ₹2.5L" },
            { href: "/seo/kisan-credit-card", title: "Kisan Credit Card 2026", desc: "₹3 lakh at just 4% interest for farmers" },
          ].map((item) => (
            <Link key={item.href} href={item.href}>
              <div className="flex items-start gap-3 p-3 bg-white border border-border rounded-xl hover:shadow-sm transition-shadow cursor-pointer">
                <ArrowRight className="w-4 h-4 text-orange-500 shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-bold text-sm">{item.title}</h3>
                  <p className="text-xs text-muted-foreground">{item.desc}</p>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>

      <AdSense slot="seo_hub_bottom" />
    </div>
  );
}
