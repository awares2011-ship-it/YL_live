export function Advertisement() {
  return (
    <div className="w-full h-[100px] bg-muted border border-dashed border-border flex flex-col items-center justify-center text-muted-foreground text-sm rounded-md my-6 hover:bg-muted/80 transition-colors">
      <span className="uppercase tracking-widest text-[10px] font-bold opacity-50 mb-1">Advertisement</span>
      <span className="font-medium text-muted-foreground/70">Google AdSense Placeholder</span>
    </div>
  );
}
