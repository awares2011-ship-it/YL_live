import { Link } from "wouter";
import { Job } from "@workspace/api-client-react";
import { Badge } from "./ui/badge";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "./ui/card";
import { MapPin, Building2, Calendar, IndianRupee, Users } from "lucide-react";

export function JobCard({ job }: { job: Job }) {
  return (
    <Card className="flex flex-col h-full hover-elevate transition-shadow border-border hover:border-primary/50 group">
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start mb-2 gap-2">
          <Badge variant="outline" className="bg-primary/10 text-primary hover:bg-primary/20 font-semibold uppercase tracking-wider text-xs">
            {job.category}
          </Badge>
          <div className="flex gap-1 flex-wrap justify-end">
            {job.isTrending && <Badge variant="destructive" className="font-bold">🔥 Trending</Badge>}
            {job.isNew && <Badge className="bg-secondary hover:bg-secondary/90 font-bold">🆕 New</Badge>}
          </div>
        </div>
        <Link href={`/jobs/${job.id}`}>
          <CardTitle className="text-lg md:text-xl font-bold text-foreground group-hover:text-primary transition-colors line-clamp-2">
            {job.title}
          </CardTitle>
        </Link>
        <div className="flex items-center text-muted-foreground mt-2 font-medium">
          <Building2 className="w-4 h-4 mr-1.5 shrink-0" />
          <span className="truncate">{job.organization}</span>
        </div>
      </CardHeader>
      <CardContent className="flex-1 space-y-3 text-sm">
        <div className="grid grid-cols-2 gap-3">
          <div className="flex items-center text-muted-foreground">
            <Users className="w-4 h-4 mr-2 shrink-0 text-primary" />
            <span className="font-medium text-foreground">{job.totalPosts} Posts</span>
          </div>
          <div className="flex items-center text-muted-foreground">
            <MapPin className="w-4 h-4 mr-2 shrink-0 text-primary" />
            <span className="truncate">{job.state}</span>
          </div>
          <div className="flex items-center text-muted-foreground col-span-2">
            <IndianRupee className="w-4 h-4 mr-2 shrink-0 text-primary" />
            <span className="truncate font-medium">{job.salary}</span>
          </div>
        </div>
      </CardContent>
      <CardFooter className="pt-0 flex items-center justify-between border-t border-border/50 mt-4">
        <div className="flex items-center text-sm font-medium mt-4 text-destructive">
          <Calendar className="w-4 h-4 mr-1.5 shrink-0" />
          <span>Last Date: {job.lastDate}</span>
        </div>
      </CardFooter>
    </Card>
  );
}
