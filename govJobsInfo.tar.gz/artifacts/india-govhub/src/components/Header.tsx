import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Menu, X, Globe, ChevronDown } from "lucide-react";
import { Button } from "./ui/button";
import { useI18n, languages } from "@/lib/i18n";

export function Header() {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isLangOpen, setIsLangOpen] = useState(false);
  const { t, language, setLanguage } = useI18n();

  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location]);

  useEffect(() => {
    const close = () => setIsLangOpen(false);
    document.addEventListener("click", close);
    return () => document.removeEventListener("click", close);
  }, []);

  const navLinks = [
    { href: "/", label: t.home },
    { href: "/jobs", label: t.govtJobs },
    { href: "/schemes", label: t.kisanYojana },
    { href: "/blogs", label: t.blogs },
    { href: "/tools", label: t.tools },
  ];

  const currentLang = languages.find((l) => l.code === language);

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 shadow-sm">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between gap-2">
        {/* Logo */}
        <Link href="/" className="flex items-center space-x-2 group shrink-0">
          <div className="flex flex-col gap-0.5 mr-1">
            <div className="w-4 h-1.5 bg-[#FF9933] rounded-sm group-hover:scale-110 transition-transform origin-left" />
            <div className="w-4 h-1.5 bg-white border border-border/50 rounded-sm group-hover:scale-110 transition-transform origin-left delay-75" />
            <div className="w-4 h-1.5 bg-[#138808] rounded-sm group-hover:scale-110 transition-transform origin-left delay-150" />
          </div>
          <span className="font-extrabold text-lg md:text-xl tracking-tight">
            <span className="text-primary">gov</span><span className="text-secondary">Jobs</span><span className="text-foreground">Info</span>
          </span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center space-x-1">
          {navLinks.map((link) => {
            const isActive = location === link.href || (link.href !== "/" && location.startsWith(link.href));
            return (
              <Link
                key={link.href}
                href={link.href}
                className={`px-3 py-2 rounded-md text-sm font-bold transition-colors hover:bg-muted ${
                  isActive ? "text-primary bg-primary/5" : "text-foreground/80 hover:text-foreground"
                }`}
              >
                {link.label}
              </Link>
            );
          })}
        </nav>

        {/* Language Switcher */}
        <div className="relative" onClick={(e) => e.stopPropagation()}>
          <button
            onClick={() => setIsLangOpen(!isLangOpen)}
            className="flex items-center gap-1 px-2 py-1.5 rounded-md text-sm font-semibold border border-border hover:bg-muted transition-colors"
            data-testid="button-language-switcher"
          >
            <Globe className="w-4 h-4 text-primary" />
            <span className="hidden sm:inline">{currentLang?.native}</span>
            <ChevronDown className="w-3 h-3 text-muted-foreground" />
          </button>
          {isLangOpen && (
            <div className="absolute right-0 top-full mt-1 bg-card border border-border rounded-lg shadow-lg py-1 min-w-[140px] z-50">
              {languages.map((lang) => (
                <button
                  key={lang.code}
                  onClick={() => { setLanguage(lang.code); setIsLangOpen(false); }}
                  className={`w-full text-left px-4 py-2 text-sm hover:bg-muted transition-colors flex items-center justify-between ${
                    language === lang.code ? "text-primary font-bold" : "text-foreground"
                  }`}
                  data-testid={`button-lang-${lang.code}`}
                >
                  <span>{lang.native}</span>
                  {language === lang.code && <span className="text-primary text-xs">✓</span>}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Mobile Menu Toggle */}
        <Button
          variant="ghost"
          size="icon"
          className="md:hidden"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          data-testid="button-mobile-menu"
        >
          {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </Button>
      </div>

      {/* Mobile Nav */}
      {isMobileMenuOpen && (
        <div className="md:hidden border-t border-border bg-background py-4 px-4 space-y-2 shadow-lg absolute w-full left-0">
          {navLinks.map((link) => {
            const isActive = location === link.href || (link.href !== "/" && location.startsWith(link.href));
            return (
              <Link
                key={link.href}
                href={link.href}
                className={`block px-4 py-3 rounded-md text-base font-bold transition-colors ${
                  isActive
                    ? "text-primary bg-primary/5 border-l-4 border-primary"
                    : "text-foreground/80 hover:text-foreground hover:bg-muted"
                }`}
              >
                {link.label}
              </Link>
            );
          })}
          <div className="pt-2 border-t border-border">
            <p className="text-xs text-muted-foreground px-4 mb-2 font-semibold uppercase">Language</p>
            <div className="grid grid-cols-3 gap-2 px-2">
              {languages.map((lang) => (
                <button
                  key={lang.code}
                  onClick={() => { setLanguage(lang.code); setIsMobileMenuOpen(false); }}
                  className={`py-2 px-1 rounded text-sm font-semibold transition-colors text-center ${
                    language === lang.code
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted text-foreground hover:bg-muted/80"
                  }`}
                >
                  {lang.native}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
