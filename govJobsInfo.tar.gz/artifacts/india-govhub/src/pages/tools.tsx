import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Advertisement } from "@/components/Advertisement";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calculator, Calendar as CalendarIcon, IndianRupee } from "lucide-react";
import { differenceInYears, differenceInMonths, differenceInDays } from "date-fns";

export default function ToolsPage() {
  useEffect(() => {
    document.title = "Calculators & Tools | govJobsInfo";
  }, []);

  // EMI State
  const [loanAmount, setLoanAmount] = useState<string>("500000");
  const [interestRate, setInterestRate] = useState<string>("8.5");
  const [tenureYears, setTenureYears] = useState<string>("5");
  const [emiResult, setEmiResult] = useState<{ emi: number; totalInterest: number; totalPayment: number } | null>(null);

  // Age State
  const [dob, setDob] = useState<string>("");
  const [targetDate, setTargetDate] = useState<string>(new Date().toISOString().split("T")[0]);
  const [ageResult, setAgeResult] = useState<{ years: number; months: number; days: number } | null>(null);

  // Calculate EMI
  useEffect(() => {
    const p = parseFloat(loanAmount);
    const r = parseFloat(interestRate) / 12 / 100;
    const n = parseFloat(tenureYears) * 12;

    if (p > 0 && r > 0 && n > 0) {
      const emi = (p * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
      const totalPayment = emi * n;
      const totalInterest = totalPayment - p;
      setEmiResult({ emi, totalInterest, totalPayment });
    } else {
      setEmiResult(null);
    }
  }, [loanAmount, interestRate, tenureYears]);

  // Calculate Age
  useEffect(() => {
    if (dob && targetDate) {
      const birthDate = new Date(dob);
      const toDate = new Date(targetDate);
      
      if (toDate >= birthDate) {
        const years = differenceInYears(toDate, birthDate);
        
        // Add years to birthdate to get remaining months
        const dateAfterYears = new Date(birthDate);
        dateAfterYears.setFullYear(dateAfterYears.getFullYear() + years);
        const months = differenceInMonths(toDate, dateAfterYears);
        
        // Add months to get remaining days
        const dateAfterMonths = new Date(dateAfterYears);
        dateAfterMonths.setMonth(dateAfterMonths.getMonth() + months);
        const days = differenceInDays(toDate, dateAfterMonths);
        
        setAgeResult({ years, months, days });
      } else {
        setAgeResult(null);
      }
    } else {
      setAgeResult(null);
    }
  }, [dob, targetDate]);

  return (
    <div className="container mx-auto px-4 py-8 max-w-5xl">
      <div className="mb-8">
        <div className="flex items-center text-sm text-muted-foreground mb-4">
          <Link href="/" className="hover:text-primary">Home</Link>
          <span className="mx-2">›</span>
          <span className="text-foreground font-medium">Tools</span>
        </div>
        <h1 className="text-3xl md:text-4xl font-extrabold text-foreground mb-2 flex items-center">
          <Calculator className="w-8 h-8 mr-3 text-accent" />
          Calculators & Tools
        </h1>
        <p className="text-muted-foreground font-medium text-lg">Free online tools for job applicants and general public.</p>
      </div>

      <Advertisement />

      <div className="mt-8">
        <Tabs defaultValue="age" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-8 h-12">
            <TabsTrigger value="age" className="text-base font-bold data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              <CalendarIcon className="w-5 h-5 mr-2" /> Age Calculator
            </TabsTrigger>
            <TabsTrigger value="emi" className="text-base font-bold data-[state=active]:bg-secondary data-[state=active]:text-secondary-foreground">
              <IndianRupee className="w-5 h-5 mr-2" /> EMI Calculator
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="age">
            <Card className="border-border">
              <CardHeader className="bg-muted/30 border-b border-border">
                <CardTitle className="text-2xl text-primary flex items-center">
                  <CalendarIcon className="w-6 h-6 mr-2" />
                  Age Calculator
                </CardTitle>
                <p className="text-muted-foreground">Calculate your exact age for job applications based on notification cut-off dates.</p>
              </CardHeader>
              <CardContent className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <Label htmlFor="dob" className="text-base font-bold">Date of Birth</Label>
                      <Input 
                        id="dob" 
                        type="date" 
                        value={dob}
                        onChange={(e) => setDob(e.target.value)}
                        className="h-12 text-lg"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="targetDate" className="text-base font-bold">Age at Date (Cut-off Date)</Label>
                      <Input 
                        id="targetDate" 
                        type="date" 
                        value={targetDate}
                        onChange={(e) => setTargetDate(e.target.value)}
                        className="h-12 text-lg"
                      />
                    </div>
                  </div>
                  
                  <div className="bg-muted rounded-xl p-6 flex flex-col justify-center items-center text-center border border-border h-full min-h-[250px]">
                    <h3 className="text-lg font-bold text-muted-foreground mb-4 uppercase tracking-wider">Your Exact Age Is</h3>
                    {ageResult ? (
                      <div className="flex justify-center gap-4 w-full">
                        <div className="flex flex-col items-center bg-background p-4 rounded-lg shadow-sm border border-border flex-1">
                          <span className="text-4xl font-black text-primary mb-1">{ageResult.years}</span>
                          <span className="text-sm font-semibold text-muted-foreground uppercase">Years</span>
                        </div>
                        <div className="flex flex-col items-center bg-background p-4 rounded-lg shadow-sm border border-border flex-1">
                          <span className="text-4xl font-black text-primary mb-1">{ageResult.months}</span>
                          <span className="text-sm font-semibold text-muted-foreground uppercase">Months</span>
                        </div>
                        <div className="flex flex-col items-center bg-background p-4 rounded-lg shadow-sm border border-border flex-1">
                          <span className="text-4xl font-black text-primary mb-1">{ageResult.days}</span>
                          <span className="text-sm font-semibold text-muted-foreground uppercase">Days</span>
                        </div>
                      </div>
                    ) : (
                      <div className="text-muted-foreground/50 flex flex-col items-center">
                        <CalendarIcon className="w-12 h-12 mb-3" />
                        <p>Enter dates to calculate your age</p>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="emi">
            <Card className="border-border">
              <CardHeader className="bg-muted/30 border-b border-border">
                <CardTitle className="text-2xl text-secondary flex items-center">
                  <IndianRupee className="w-6 h-6 mr-2" />
                  EMI Calculator
                </CardTitle>
                <p className="text-muted-foreground">Calculate monthly installments for Home, Car, or Personal loans.</p>
              </CardHeader>
              <CardContent className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <Label htmlFor="loanAmount" className="text-base font-bold flex justify-between">
                        <span>Loan Amount (₹)</span>
                        <span className="text-secondary">{parseFloat(loanAmount || "0").toLocaleString('en-IN')}</span>
                      </Label>
                      <Input 
                        id="loanAmount" 
                        type="number" 
                        min="10000"
                        value={loanAmount}
                        onChange={(e) => setLoanAmount(e.target.value)}
                        className="h-12 text-lg"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="interestRate" className="text-base font-bold flex justify-between">
                        <span>Interest Rate (% p.a.)</span>
                        <span className="text-secondary">{interestRate}%</span>
                      </Label>
                      <Input 
                        id="interestRate" 
                        type="number" 
                        min="1"
                        step="0.1"
                        value={interestRate}
                        onChange={(e) => setInterestRate(e.target.value)}
                        className="h-12 text-lg"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="tenureYears" className="text-base font-bold flex justify-between">
                        <span>Loan Tenure (Years)</span>
                        <span className="text-secondary">{tenureYears} Years</span>
                      </Label>
                      <Input 
                        id="tenureYears" 
                        type="number" 
                        min="1"
                        max="30"
                        value={tenureYears}
                        onChange={(e) => setTenureYears(e.target.value)}
                        className="h-12 text-lg"
                      />
                    </div>
                  </div>
                  
                  <div className="bg-muted rounded-xl p-6 flex flex-col justify-center items-center text-center border border-border h-full min-h-[300px]">
                    <h3 className="text-lg font-bold text-muted-foreground mb-6 uppercase tracking-wider">Loan Summary</h3>
                    {emiResult ? (
                      <div className="w-full space-y-6">
                        <div className="bg-background p-6 rounded-xl shadow-sm border-l-4 border-secondary border-t border-r border-b text-center">
                          <p className="text-sm font-bold text-muted-foreground uppercase tracking-widest mb-2">Monthly EMI</p>
                          <p className="text-4xl font-black text-secondary">
                            ₹ {Math.round(emiResult.emi).toLocaleString('en-IN')}
                          </p>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <div className="bg-background p-4 rounded-lg shadow-sm border border-border">
                            <p className="text-xs font-bold text-muted-foreground mb-1 uppercase">Total Interest</p>
                            <p className="text-xl font-black text-foreground">₹ {Math.round(emiResult.totalInterest).toLocaleString('en-IN')}</p>
                          </div>
                          <div className="bg-background p-4 rounded-lg shadow-sm border border-border">
                            <p className="text-xs font-bold text-muted-foreground mb-1 uppercase">Total Payment</p>
                            <p className="text-xl font-black text-foreground">₹ {Math.round(emiResult.totalPayment).toLocaleString('en-IN')}</p>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="text-muted-foreground/50 flex flex-col items-center">
                        <Calculator className="w-12 h-12 mb-3" />
                        <p>Enter loan details to calculate EMI</p>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
      
      <Advertisement />
    </div>
  );
}
