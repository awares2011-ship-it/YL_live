import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Suspense, lazy } from "react";
import NotFound from "@/pages/not-found";
import Layout from "@/components/layout";

const Home = lazy(() => import("@/pages/home"));
const JobsList = lazy(() => import("@/pages/jobs/index"));
const JobDetail = lazy(() => import("@/pages/jobs/detail"));
const SchemesList = lazy(() => import("@/pages/schemes/index"));
const SchemeDetail = lazy(() => import("@/pages/schemes/detail"));
const BlogsList = lazy(() => import("@/pages/blogs/index"));
const BlogDetail = lazy(() => import("@/pages/blogs/detail"));
const EmiCalculator = lazy(() => import("@/pages/tools/emi-calculator"));
const AgeCalculator = lazy(() => import("@/pages/tools/age-calculator"));
const Trending = lazy(() => import("@/pages/trending"));
const SeoPage = lazy(() => import("@/pages/seo/index"));
const SeoHub = lazy(() => import("@/pages/seo/hub"));

const queryClient = new QueryClient();

function Router() {
  return (
    <Layout>
      <Suspense fallback={<div className="p-8 text-center text-muted-foreground animate-pulse">Loading...</div>}>
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/jobs" component={JobsList} />
          <Route path="/jobs/:id" component={JobDetail} />
          <Route path="/schemes" component={SchemesList} />
          <Route path="/schemes/:id" component={SchemeDetail} />
          <Route path="/blogs" component={BlogsList} />
          <Route path="/blogs/:id" component={BlogDetail} />
          <Route path="/tools/emi-calculator" component={EmiCalculator} />
          <Route path="/tools/age-calculator" component={AgeCalculator} />
          <Route path="/trending" component={Trending} />
          <Route path="/seo" component={SeoHub} />
          <Route path="/seo/:slug" component={SeoPage} />
          <Route component={NotFound} />
        </Switch>
      </Suspense>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
