/**
 * GovJobs & Yojna Info — search.js
 * Live search with debounce
 * Developed by Breakout Trade
 */

document.addEventListener('DOMContentLoaded', () => {
  initSearch();
});

function initSearch() {
  const inputs = document.querySelectorAll('.search-input');
  inputs.forEach(input => {
    const resultsContainer = input.closest('.search-wrap')?.querySelector('#search-results-container')
      || document.getElementById('search-results-container');

    if (!resultsContainer) return;

    const debouncedSearch = debounce(async (q) => {
      if (!q || q.length < 2) {
        resultsContainer.classList.remove('visible');
        return;
      }
      await performSearch(q, resultsContainer);
    }, 300);

    input.addEventListener('input', (e) => {
      debouncedSearch(e.target.value.trim());
    });

    input.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        resultsContainer.classList.remove('visible');
        input.value = '';
      }
      if (e.key === 'Enter' && input.value.trim().length >= 2) {
        navigateToSearch(input.value.trim());
      }
    });

    // Close on outside click
    document.addEventListener('click', (e) => {
      if (!input.contains(e.target) && !resultsContainer.contains(e.target)) {
        resultsContainer.classList.remove('visible');
      }
    });
  });

  // Homepage hero search
  const heroSearch = document.getElementById('hero-search-input');
  const heroBtn = document.getElementById('hero-search-btn');
  if (heroSearch && heroBtn) {
    heroBtn.addEventListener('click', () => {
      navigateToSearch(heroSearch.value.trim());
    });
    heroSearch.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') navigateToSearch(heroSearch.value.trim());
    });
  }
}

async function performSearch(query, resultsContainer) {
  if (!resultsContainer) return;
  resultsContainer.innerHTML = `<div style="padding:16px;text-align:center;"><span class="loading-spinner"></span></div>`;
  resultsContainer.classList.add('visible');

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 6000);
    const url = `/api/search?q=${encodeURIComponent(query)}&lang=${GovApp?.currentLang || 'en'}`;
    const res = await fetch(url, { signal: controller.signal });
    clearTimeout(timeout);

    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    const items = Array.isArray(data.results) ? data.results.slice(0, 6) : [];

    if (typeof gtag !== 'undefined') {
      gtag('event', 'search_performed', { query, results_count: items.length });
    }

    if (items.length === 0) {
      resultsContainer.innerHTML = `
        <div class="search-result-item" style="text-align:center;color:var(--text-3);">
          No results found for "<strong>${escapeHtml(query)}</strong>"
        </div>
      `;
      return;
    }

    resultsContainer.innerHTML = items.map(item => `
      <div class="search-result-item" onclick="openSearchResult('${encodeURIComponent(item.link || '#')}', '${encodeURIComponent(item.title || '')}', '${item.type || 'job'}')">
        <div class="search-result-title">${escapeHtml(item.title || '')}</div>
        <div class="search-result-meta">
          <span class="badge badge-${item.type || 'job'}" style="font-size:0.65rem;padding:1px 5px">${capitalize(item.type || 'job')}</span>
          ${item.source ? ` · ${escapeHtml(item.source)}` : ''}
          ${item.pubDate ? ` · ${formatDate(item.pubDate)}` : ''}
        </div>
      </div>
    `).join('') + `
      <div class="search-result-item" style="text-align:center;border-top:2px solid var(--border);">
        <a href="/search?q=${encodeURIComponent(query)}" style="font-size:0.82rem;color:var(--saffron);font-weight:600;">
          View all results for "${escapeHtml(query)}" →
        </a>
      </div>
    `;
  } catch (e) {
    resultsContainer.innerHTML = `
      <div class="search-result-item" style="color:var(--red);font-size:0.82rem;">
        Search failed. Please try again.
      </div>
    `;
  }
}

function openSearchResult(encodedLink, encodedTitle, type) {
  const link = decodeURIComponent(encodedLink);
  const title = decodeURIComponent(encodedTitle);

  try {
    if (typeof gtag !== 'undefined') {
      gtag('event', 'official_link_clicked', { title, type, source: 'search' });
    }
  } catch(e) {}

  if (link && link !== '#') {
    window.open(link, '_blank', 'noopener');
  }

  // Close results
  document.querySelectorAll('#search-results-container').forEach(c => c.classList.remove('visible'));
}

function navigateToSearch(query) {
  if (!query || query.length < 2) return;
  window.location.href = `/search?q=${encodeURIComponent(query)}`;
}

function capitalize(str) {
  if (!str) return '';
  return str.charAt(0).toUpperCase() + str.slice(1);
}

window.openSearchResult = openSearchResult;
window.performSearch = performSearch;
