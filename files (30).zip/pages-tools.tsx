import { Link } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import AdSense from "@/components/adsense";
import { Calculator, Clock, Image as ImageIcon, FileText, CheckCircle } from "lucide-react";
import { InternalLinks, FaqSection } from "./pages-extra";

// ─── Graduate Jobs (already in pages-extra) ────────────────────────────────

// ─── SEO Tool Pages ───────────────────────────────────────────────────────────

export function EmiCalculatorSeoPage() {
  return (
    <div className="space-y-6">
      <p className="text-muted-foreground leading-relaxed">
        An EMI (Equated Monthly Installment) calculator helps you calculate the exact monthly payment for home loans, car loans, personal loans, and Kisan Credit Card loans. Use our free online EMI calculator to plan your loan repayment, compare interest rates, and make informed financial decisions in 2026.
      </p>

      <div className="bg-blue-600 text-white rounded-2xl p-6 text-center">
        <Calculator className="w-12 h-12 mx-auto mb-3 text-blue-200" />
        <h2 className="text-2xl font-black mb-2">Free EMI Calculator</h2>
        <p className="text-blue-200 mb-4">Calculate home loan, car loan & personal loan EMI instantly</p>
        <Link href="/tools/emi-calculator">
          <Button className="bg-white text-blue-600 hover:bg-blue-50 font-bold px-8">
            Open EMI Calculator →
          </Button>
        </Link>
      </div>

      <h2 className="text-xl font-bold">EMI Formula – How It's Calculated</h2>
      <div className="bg-gray-50 border border-border rounded-xl p-4">
        <p className="font-mono text-center text-lg font-bold text-gray-800">
          EMI = P × r × (1+r)^n / ((1+r)^n - 1)
        </p>
        <div className="mt-3 grid md:grid-cols-3 gap-3 text-sm text-muted-foreground text-center">
          <div><b className="text-gray-800">P</b> = Principal Loan Amount</div>
          <div><b className="text-gray-800">r</b> = Monthly Interest Rate</div>
          <div><b className="text-gray-800">n</b> = Number of Months (Tenure)</div>
        </div>
      </div>

      <h2 className="text-xl font-bold">Common Loan EMI Examples (2026)</h2>
      <div className="overflow-x-auto">
        <table className="w-full text-sm border-collapse">
          <thead>
            <tr className="bg-blue-50">
              <th className="p-3 text-left border border-border font-bold">Loan Type</th>
              <th className="p-3 text-left border border-border font-bold">Amount</th>
              <th className="p-3 text-left border border-border font-bold">Rate</th>
              <th className="p-3 text-left border border-border font-bold">Tenure</th>
              <th className="p-3 text-left border border-border font-bold">EMI</th>
            </tr>
          </thead>
          <tbody>
            {[
              { type: "Home Loan (SBI)", amount: "₹30 Lakh", rate: "8.5%", tenure: "20 Years", emi: "₹26,035" },
              { type: "Car Loan", amount: "₹8 Lakh", rate: "9.0%", tenure: "5 Years", emi: "₹16,607" },
              { type: "Personal Loan", amount: "₹3 Lakh", rate: "12.0%", tenure: "3 Years", emi: "₹9,964" },
              { type: "Education Loan", amount: "₹5 Lakh", rate: "8.0%", tenure: "7 Years", emi: "₹7,761" },
              { type: "KCC Farm Loan", amount: "₹1.5 Lakh", rate: "4.0%", tenure: "1 Year", emi: "₹12,810" },
            ].map((row, i) => (
              <tr key={i} className={i % 2 === 0 ? "bg-white" : "bg-gray-50"}>
                <td className="p-3 border border-border">{row.type}</td>
                <td className="p-3 border border-border">{row.amount}</td>
                <td className="p-3 border border-border">{row.rate}</td>
                <td className="p-3 border border-border">{row.tenure}</td>
                <td className="p-3 border border-border font-bold text-blue-600">{row.emi}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <AdSense slot="emi_calculator_seo_inline" />

      <h2 className="text-xl font-bold">Home Loan Interest Rates 2026 – All Banks</h2>
      <div className="space-y-2">
        {[
          { bank: "State Bank of India (SBI)", rate: "8.50%–10.15%", type: "Floating" },
          { bank: "HDFC Bank", rate: "8.70%–9.95%", type: "Floating" },
          { bank: "ICICI Bank", rate: "8.75%–10.05%", type: "Floating" },
          { bank: "Bank of Baroda", rate: "8.40%–10.60%", type: "Floating" },
          { bank: "Punjab National Bank", rate: "8.40%–10.25%", type: "Floating" },
          { bank: "LIC Housing Finance", rate: "8.50%–10.75%", type: "Floating" },
        ].map((bank) => (
          <div key={bank.bank} className="flex justify-between items-center p-3 bg-white border border-border rounded-xl">
            <span className="font-bold text-sm">{bank.bank}</span>
            <div className="flex gap-2">
              <Badge className="bg-blue-600 text-white text-xs">{bank.rate}</Badge>
              <Badge variant="outline" className="text-xs">{bank.type}</Badge>
            </div>
          </div>
        ))}
      </div>

      <FaqSection faqs={[
        { q: "What is EMI?", a: "EMI (Equated Monthly Installment) is the fixed amount you pay every month to repay your loan. It includes both the principal and interest components calculated over the loan tenure." },
        { q: "How to reduce home loan EMI?", a: "You can reduce EMI by: making a higher down payment, choosing a longer repayment tenure, negotiating a lower interest rate with your bank, or making part-prepayments periodically." },
        { q: "What is the current SBI home loan interest rate?", a: "SBI home loan interest rates in 2026 range from 8.50% to 10.15% per annum (floating rate) depending on loan amount and CIBIL score. Check sbi.co.in for current rates." },
        { q: "Is EMI fixed for the entire loan tenure?", a: "For fixed-rate loans, EMI remains constant. For floating-rate loans (most common in India), EMI may change when RBI revises repo rate. You can choose to adjust tenure instead of EMI." },
      ]} />

      <InternalLinks links={[
        { label: "Use EMI Calculator", href: "/tools/emi-calculator" },
        { label: "Age Calculator", href: "/tools/age-calculator" },
        { label: "Kisan Credit Card", href: "/seo/kisan-credit-card" },
        { label: "Latest Govt Jobs", href: "/seo/latest-govt-jobs-2026" },
        { label: "All Schemes", href: "/schemes" },
      ]} />
    </div>
  );
}

export function AgeCalculatorSeoPage() {
  return (
    <div className="space-y-6">
      <p className="text-muted-foreground leading-relaxed">
        Age calculator helps you calculate your exact age in years, months, and days from your date of birth. For government job applications, knowing your exact age is critical — even one day's difference can make you eligible or ineligible for a government exam. Use our precise age calculator to verify your eligibility for SSC, Railways, Banking, UPSC, and state government jobs.
      </p>

      <div className="bg-orange-500 text-white rounded-2xl p-6 text-center">
        <Clock className="w-12 h-12 mx-auto mb-3 text-orange-200" />
        <h2 className="text-2xl font-black mb-2">Free Age Calculator</h2>
        <p className="text-orange-200 mb-4">Check exact age for government exam eligibility</p>
        <Link href="/tools/age-calculator">
          <Button className="bg-white text-orange-600 hover:bg-orange-50 font-bold px-8">
            Calculate Your Age →
          </Button>
        </Link>
      </div>

      <h2 className="text-xl font-bold">Age Limit for Government Jobs 2026</h2>
      <div className="overflow-x-auto">
        <table className="w-full text-sm border-collapse">
          <thead>
            <tr className="bg-orange-50">
              <th className="p-3 text-left border border-border font-bold">Exam</th>
              <th className="p-3 text-left border border-border font-bold">Min Age</th>
              <th className="p-3 text-left border border-border font-bold">Max Age (General)</th>
              <th className="p-3 text-left border border-border font-bold">OBC Relaxation</th>
              <th className="p-3 text-left border border-border font-bold">SC/ST</th>
            </tr>
          </thead>
          <tbody>
            {[
              { exam: "UPSC CSE (IAS)", min: "21", max: "32", obc: "+3 Years", scst: "+5 Years" },
              { exam: "SSC CGL", min: "18", max: "27–30", obc: "+3 Years", scst: "+5 Years" },
              { exam: "IBPS PO", min: "20", max: "30", obc: "+3 Years", scst: "+5 Years" },
              { exam: "Railway Group D", min: "18", max: "33", obc: "+3 Years", scst: "+5 Years" },
              { exam: "UP Police Constable", min: "18", max: "22–25", obc: "+3 Years", scst: "+5 Years" },
              { exam: "Indian Army Agniveer", min: "17.5", max: "23", obc: "No Relaxation", scst: "No Relaxation" },
            ].map((row, i) => (
              <tr key={i} className={i % 2 === 0 ? "bg-white" : "bg-orange-50/50"}>
                <td className="p-3 border border-border font-bold">{row.exam}</td>
                <td className="p-3 border border-border">{row.min}</td>
                <td className="p-3 border border-border font-bold text-orange-600">{row.max}</td>
                <td className="p-3 border border-border text-blue-600">{row.obc}</td>
                <td className="p-3 border border-border text-green-600">{row.scst}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <AdSense slot="age_calculator_seo_inline" />

      <h2 className="text-xl font-bold">Age Relaxation Rules for Government Jobs</h2>
      <div className="space-y-2">
        {[
          { cat: "OBC (Non-Creamy Layer)", relax: "+3 Years", color: "blue" },
          { cat: "SC / ST", relax: "+5 Years", color: "green" },
          { cat: "PwD (General)", relax: "+10 Years", color: "purple" },
          { cat: "PwD (OBC)", relax: "+13 Years", color: "purple" },
          { cat: "PwD (SC/ST)", relax: "+15 Years", color: "purple" },
          { cat: "Ex-Servicemen (ESM)", relax: "+3 Years after military service", color: "orange" },
          { cat: "Widows / Divorced Women", relax: "+5–9 Years (varies by exam)", color: "pink" },
          { cat: "J&K Domicile (1980–1989)", relax: "+5 Years for Central Govt Jobs", color: "yellow" },
        ].map((item) => (
          <div key={item.cat} className="flex justify-between items-center p-3 bg-white border border-border rounded-xl">
            <span className="text-sm font-medium">{item.cat}</span>
            <Badge className="bg-orange-500 text-white">{item.relax}</Badge>
          </div>
        ))}
      </div>

      <FaqSection faqs={[
        { q: "How is age calculated for government exam eligibility?", a: "Age is calculated as on the last date of application (closing date). If last date is April 30, 2026, your age is calculated as of April 30, 2026. Use our age calculator by entering your DOB and the exam closing date." },
        { q: "What if I am overage by just a few days?", a: "Unfortunately, there is no grace period. Even if you are over the age limit by one day, you are ineligible. Always verify your age carefully against the official notification using our age calculator." },
        { q: "Is age limit same for all states?", a: "No. State government jobs often have different age limits. For example, UP Police has age limit 18-22 for general, while Bihar Police goes up to 25. Always check the official state notification." },
      ]} />

      <InternalLinks links={[
        { label: "Use Age Calculator", href: "/tools/age-calculator" },
        { label: "EMI Calculator", href: "/tools/emi-calculator" },
        { label: "Latest Govt Jobs 2026", href: "/seo/latest-govt-jobs-2026" },
        { label: "10th Pass Jobs", href: "/seo/10th-pass-govt-jobs" },
        { label: "Graduate Jobs", href: "/seo/graduate-govt-jobs" },
      ]} />
    </div>
  );
}

export function ImageCompressorSeoPage() {
  return (
    <div className="space-y-6">
      <p className="text-muted-foreground leading-relaxed">
        When applying for government jobs online, most portals have strict size limits for photo and signature uploads — typically 10KB to 100KB for photos and 5KB to 20KB for signatures. Our free online image compressor helps you reduce image file size without losing quality, making it perfect for government job applications on SSC, IBPS, RRB, and state PSC portals.
      </p>

      <div className="bg-gray-800 text-white rounded-2xl p-6 text-center">
        <ImageIcon className="w-12 h-12 mx-auto mb-3 text-gray-400" />
        <h2 className="text-2xl font-black mb-2">Free Image Compressor</h2>
        <p className="text-gray-400 mb-4">Compress photos for government job applications instantly</p>
        <Badge className="bg-yellow-500 text-black font-bold px-4 py-1">Coming Soon – Use for Free!</Badge>
      </div>

      <h2 className="text-xl font-bold">Photo Size Requirements for Government Exams</h2>
      <div className="overflow-x-auto">
        <table className="w-full text-sm border-collapse">
          <thead>
            <tr className="bg-gray-50">
              <th className="p-3 text-left border border-border font-bold">Portal/Exam</th>
              <th className="p-3 text-left border border-border font-bold">Photo Size</th>
              <th className="p-3 text-left border border-border font-bold">Signature</th>
              <th className="p-3 text-left border border-border font-bold">Format</th>
            </tr>
          </thead>
          <tbody>
            {[
              { exam: "SSC (CGL/CHSL/MTS)", photo: "10–50 KB", sig: "5–20 KB", format: "JPG/JPEG" },
              { exam: "IBPS (PO/Clerk/SO)", photo: "20–50 KB", sig: "10–20 KB", format: "JPG" },
              { exam: "SBI (PO/Clerk)", photo: "50–100 KB", sig: "20–50 KB", format: "JPG" },
              { exam: "RRB (Group D/NTPC)", photo: "20–50 KB", sig: "10–40 KB", format: "JPG/PNG" },
              { exam: "UPSC CSE", photo: "40–100 KB", sig: "20–50 KB", format: "JPG" },
              { exam: "UP Police", photo: "10–40 KB", sig: "5–20 KB", format: "JPG" },
            ].map((row, i) => (
              <tr key={i} className={i % 2 === 0 ? "bg-white" : "bg-gray-50"}>
                <td className="p-3 border border-border font-bold">{row.exam}</td>
                <td className="p-3 border border-border text-green-600 font-bold">{row.photo}</td>
                <td className="p-3 border border-border text-blue-600">{row.sig}</td>
                <td className="p-3 border border-border">{row.format}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <h2 className="text-xl font-bold">How to Compress Photo for Govt Job Application</h2>
      <div className="space-y-3">
        {[
          { step: "Take passport size photo (35mm × 45mm) with white/light background", icon: "📷" },
          { step: "Scan or photograph with phone camera at good lighting", icon: "📱" },
          { step: "Use our image compressor or MS Paint to reduce file size", icon: "🖥️" },
          { step: "Save as JPG with quality setting 60–80% to meet size limits", icon: "💾" },
          { step: "Verify final file size before uploading to the exam portal", icon: "✅" },
        ].map((item, i) => (
          <div key={i} className="flex items-start gap-3 p-3 bg-gray-50 border border-border rounded-xl">
            <span className="text-2xl">{item.icon}</span>
            <p className="text-sm text-muted-foreground mt-1">{item.step}</p>
          </div>
        ))}
      </div>

      <AdSense slot="image_compressor_inline" />

      <FaqSection faqs={[
        { q: "What photo size is required for SSC CGL?", a: "SSC CGL requires passport size photo in JPG format, file size between 10KB and 50KB, and dimensions 35mm × 45mm. Background should be white/off-white. Spectacles are not allowed." },
        { q: "Can I use a selfie for government job applications?", a: "No, selfies are not accepted. You need a professional passport size photo taken against a plain white background. The face should clearly visible with no shadows." },
        { q: "How to compress image below 20KB without losing quality?", a: "Use image editing tools like MS Paint (save as JPG with lower quality), or online tools like TinyPNG, Squoosh, or our compressor. Set JPEG quality to 60–70% to achieve small file sizes." },
        { q: "What if my photo exceeds the size limit during upload?", a: "Your application will not be accepted or will show an error. Reduce your photo size using our image compressor tool and retry. Never force-resize as it may distort the image." },
      ]} />

      <InternalLinks links={[
        { label: "Age Calculator", href: "/tools/age-calculator" },
        { label: "EMI Calculator", href: "/tools/emi-calculator" },
        { label: "Latest Govt Jobs", href: "/seo/latest-govt-jobs-2026" },
        { label: "SSC Jobs 2026", href: "/seo/ssc-jobs-2026" },
        { label: "Bank Jobs 2026", href: "/seo/bank-jobs-2026" },
      ]} />
    </div>
  );
}
