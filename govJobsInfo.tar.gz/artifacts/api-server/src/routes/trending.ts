import { Router } from "express";
import { db } from "@workspace/db";
import { jobsTable, schemesTable, blogsTable } from "@workspace/db";
import { desc, sql } from "drizzle-orm";

const router = Router();

router.get("/trending", async (_req, res) => {
  const [trendingJobs, trendingSchemes] = await Promise.all([
    db.select({ id: jobsTable.id, title: jobsTable.title, viewCount: jobsTable.viewCount, isTrending: jobsTable.isTrending, isNew: jobsTable.isNew }).from(jobsTable).orderBy(desc(jobsTable.viewCount)).limit(5),
    db.select({ id: schemesTable.id, title: schemesTable.title, viewCount: schemesTable.viewCount, isTrending: schemesTable.isTrending, isNew: schemesTable.isNew }).from(schemesTable).orderBy(desc(schemesTable.viewCount)).limit(5),
  ]);

  const items = [
    ...trendingJobs.map(j => ({
      id: j.id,
      type: "job",
      title: j.title,
      viewCount: j.viewCount,
      badge: j.isTrending ? "Trending" : j.isNew ? "New" : "Hot",
    })),
    ...trendingSchemes.map(s => ({
      id: s.id,
      type: "scheme",
      title: s.title,
      viewCount: s.viewCount,
      badge: s.isTrending ? "Trending" : s.isNew ? "New" : "Hot",
    })),
  ].sort((a, b) => b.viewCount - a.viewCount).slice(0, 8);

  return res.json({ items });
});

router.get("/summary", async (_req, res) => {
  const [jobCount, schemeCount, blogCount, newJobs, newSchemes, trendingCount] = await Promise.all([
    db.select({ count: sql<number>`count(*)` }).from(jobsTable),
    db.select({ count: sql<number>`count(*)` }).from(schemesTable),
    db.select({ count: sql<number>`count(*)` }).from(blogsTable),
    db.select({ count: sql<number>`count(*)` }).from(jobsTable).where(sql`is_new = true`),
    db.select({ count: sql<number>`count(*)` }).from(schemesTable).where(sql`is_new = true`),
    db.select({ count: sql<number>`count(*)` }).from(jobsTable).where(sql`is_trending = true`),
  ]);

  return res.json({
    totalJobs: Number(jobCount[0]?.count ?? 0),
    totalSchemes: Number(schemeCount[0]?.count ?? 0),
    totalBlogs: Number(blogCount[0]?.count ?? 0),
    newJobsToday: Number(newJobs[0]?.count ?? 0),
    newSchemesToday: Number(newSchemes[0]?.count ?? 0),
    trendingCount: Number(trendingCount[0]?.count ?? 0),
  });
});

export default router;
